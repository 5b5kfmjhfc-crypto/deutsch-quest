DEUTSCH QUEST v275 — GRAMMAR B1 STAGE 2

Baseline: Deutsch Quest v274 Grammar B1 Stage 1
Stage: Linguistic Deep Audit & Correction

All 27 B1 lesson records were individually reviewed and corrected. The review covered morphology/case, verb forms and auxiliaries, clause order, tense and modal constructions, preposition government, register/usage restrictions, examples/translations and common learner errors. Each B1 lesson now has a structured reference explanation, examples, at least three common mistakes, at least three additional examples, a practice hint and an internal audit status.

A1 and A2 grammar records were compared against v274 and are unchanged. The 36 MP3 assets and all non-grammar content/assets were preserved from the v274 archive.

Testing: Chromium Playwright page.set_content at 375, 390, 768 and 1280 px; all 27 B1 lesson cards rendered; A1/A2 regression navigation; lesson completion XP; B1 practice remains intentionally unlabelled/disabled until Stage 3 develops and validates its question bank; 3 inline JS blocks pass Node syntax check; zero runtime and console errors.

Limitations: Internal linguistic/editorial audit, not independent native-speaker proofreading, official Goethe certification, iPhone Safari, screen-reader or hardware microphone testing. Stage 3 remains responsible for pedagogical development and B1 practice.
