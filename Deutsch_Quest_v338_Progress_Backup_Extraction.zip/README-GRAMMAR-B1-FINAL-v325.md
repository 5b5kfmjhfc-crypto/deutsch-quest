# Deutsch Quest B1 – Grammar Stage 3 Final Verification (v325)

## Release decision
All 27 B1 grammar lessons and all 81 dedicated B1 focused questions were reopened from the v324 application source, reviewed, corrected where needed, and re-audited.

## Corrections
1. Corrected the separable/inseparable prefix explanation: `anrufen → anzurufen`; `besuchen → zu besuchen`.
2. Rewrote the comma guidance for infinitive groups to distinguish mandatory, optional and non-permitted comma placement.
3. Corrected the genitive spelling explanation for personal names: `Annas Auto`, `Max' Auto`.
4. Added the impersonal passive distinction: `Hier wird getanzt`.
5. Added a complete weak/mixed/strong adjective-ending matrix for all cases and genders/numbers.
6. Added a dative-reflexive example: `Ich mache mir Sorgen um meine Schwester`.
7. Expanded N-declension tables to show singular and plural case forms, including dative plural `den Studenten`.
8. Clarified one `ohne ... zu` explanation and disambiguated two N-declension questions.

## Pedagogical enrichment
Added 27 individual production challenges (one per B1 grammar lesson), each with success criteria. These are learner self-checks and are not official Goethe exam tasks.

## QA
30/30 structural/content checks passed. The dedicated B1 practice bank remains 81 questions across 27 topics (three each). A1/A2 records, vocabulary, listening, reading, writing, speaking and exam-simulation assets were preserved.

## Scope limits
This is an internal editorial and pedagogical audit, not independent native-speaker certification. Physical-device testing is still pending. The Goethe B1 exam does not publish a mandatory exhaustive grammar checklist.
