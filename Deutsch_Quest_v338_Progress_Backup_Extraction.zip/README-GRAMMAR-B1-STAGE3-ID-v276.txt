DEUTSCH QUEST — GRAMMAR B1 STAGE 3 (v276)

Baseline: v275 Grammar B1 Stage 2
Scope: Pedagogical Development & Practice

What changed
- Added 81 dedicated B1 practice questions: 3 for each of the 27 B1 grammar topics.
- Each question has 3 distinct options, a keyed correct answer, an English explanation, and an explicit B1/stage tag.
- Focused-practice buttons are now enabled for all 27 B1 lessons and show the available question count.
- Existing question bank entries, A1/A2 grammar records, media, modules, and assets were preserved.

QA
- Chromium headless / Playwright: all 27 focused practice entry points tested.
- All 81 correct-answer paths passed; 0 page errors and 0 console errors.
- Responsive widths tested: 375, 390, 768, 1280 px; no horizontal overflow.
- All 3 inline JavaScript blocks pass node --check.
- A1 (39) and A2 (35 internal records) were compared to v275 and remain identical at parsed-record level.

Limitations
- Three MCQs per topic are an initial focused practice bank; open-ended production, listening and adaptive practice are not part of this stage.
- This is internal editorial QA, not independent native-speaker proofreading or official Goethe certification.
- iPhone Safari, screen-reader, and physical-device tests were not performed.

See QA-REPORT-GRAMMAR-B1-STAGE3-v276.json and GRAMMAR-B1-STAGE3-CORRECTION-LEDGER-v276.json for details.
