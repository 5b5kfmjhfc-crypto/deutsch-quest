from playwright.sync_api import sync_playwright
from pathlib import Path
import json, hashlib, zipfile
html=Path('/mnt/data/dq_v273_stage4/dq_v272_build/index.html').read_text(encoding='utf-8')
results=[]; page_errors=[]; console_errors=[]
def check(name,ok,detail=None): results.append({'test':name,'status':'PASS' if ok else 'FAIL','detail':detail})
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844})
 page.on('pageerror',lambda e:page_errors.append(str(e)))
 page.on('console',lambda m:console_errors.append(m.text) if m.type=='error' else None)
 page.set_content(html,wait_until='domcontentloaded',timeout=30000);page.wait_for_timeout(500)
 check('initial_application_mount',page.locator('#workspace').count()==1)
 counts=page.evaluate('''()=>({nouns:NOUNS.filter(x=>x.level==='B1').length,verbs:VERBS.filter(x=>x[4]==='B1').length,adjectives:ADJECTIVES.filter(x=>x[3]==='B1').length,adverbs:ADVERBS.filter(x=>x.level==='B1').length,prepositions:PREPOSITIONS.filter(x=>x.level==='B1').length,phrases:PHRASES.filter(x=>x.level==='B1').length,families:WORD_FAMILIES.filter(x=>x.level==='B1').length,all:(()=>{const c=allCards();return {total:c.length,unique:new Set(c.map(x=>x.id)).size,b1:c.filter(x=>x.level==='B1').length}})()})''')
 check('b1_lexical_inventory_counts',counts['nouns']==304 and counts['verbs']==86 and counts['adjectives']==61 and counts['adverbs']==36 and counts['prepositions']==13 and counts['phrases']==219 and counts['families']==15,counts)
 check('review_catalog_unique_ids',counts['all']['total']==counts['all']['unique'] and counts['all']['b1']==734,counts['all'])
 # B1 vocabulary categories and overview
 page.locator('[data-module="Vocabulary"]').click();page.locator('[data-vlevel="B1"]').click();page.wait_for_timeout(80)
 t=page.locator('#workspace').inner_text();check('b1_overview_and_goethe_scope','719 lexical records' in t and 'v273 · Stage 4' in t and '663 entries have not all been individually crosswalked' in t)
 for cat in ['Nouns','Verbs','Adjectives','Phrases','Adverbs & function words','Prepositions','Word Families']:
  page.locator('[data-vtype]').filter(has_text=cat).first.click();page.wait_for_timeout(30)
  txt=page.locator('#workspace').inner_text();check('category_'+cat,'words shown' in txt or '0 words shown' in txt,txt[:90])
 print('start workout',flush=True)
 # B1 Workout modes across lexical classes
 page.locator('[data-module="Vocabulary Workout"]').click();page.locator('[data-vwl="B1"]').click();page.wait_for_timeout(50)
 # mixed meaning at index 45 selects a verb record; add-to-review must preserve Verbs category
 page.evaluate('(n)=>{vocabWorkoutIndex=n;vocabWorkoutChoice=-1;vocabWorkoutTyped="";vocabWorkoutChecked=false;render()}',47)
 txt=page.locator('#workspace').inner_text();check('b1_mixed_meaning_verb','Meaning recall' in txt and '(Verbs)' in txt,txt[:300])
 page.locator('#vwReview').click();page.locator('[data-module="Review"]').click();page.wait_for_timeout(50)
 txt=page.locator('#workspace').inner_text();check('verb_review_category_preserved','B1 · Verbs' in txt and 'Recall the meaning' in txt,txt[:180])
 print('verb ok',flush=True)
 # Preposition coverage via B1 mixed recall (index 141)
 page.locator('[data-module="Vocabulary Workout"]').click();page.locator('[data-vwl="B1"]').click()
 page.evaluate('(n)=>{vocabWorkoutIndex=n;vocabWorkoutChoice=-1;vocabWorkoutTyped="";vocabWorkoutChecked=false;render()}',285)
 txt=page.locator('#workspace').inner_text();check('b1_mixed_meaning_preposition','(Prepositions)' in txt,txt[:300])
 page.locator('#vwReview').click();page.locator('[data-module="Review"]').click();page.wait_for_timeout(50)
 txt=page.locator('#workspace').inner_text()
 # Earlier due verb is first in catalog order; rate it once to expose the newly added preposition card.
 if 'B1 · Verbs' in txt:
  page.locator('#reviewreveal').click();page.locator('[data-rate="Good"]').click();page.wait_for_timeout(40);txt=page.locator('#workspace').inner_text()
 check('preposition_review_category_preserved','B1 · Prepositions' in txt,txt[:180])
 print('prep ok',flush=True)
 # Context discrimination covers adverbs/function words as well as the other B1 classes
 page.locator('[data-module="Vocabulary Workout"]').click();page.locator('[data-vwl="B1"]').click()
 page.evaluate('(n)=>{vocabWorkoutIndex=n;vocabWorkoutChoice=-1;vocabWorkoutTyped="";vocabWorkoutChecked=false;render()}',65)
 txt=page.locator('#workspace').inner_text();check('b1_mixed_context_adverb','Word in context' in txt and '(Adverbs & function words)' in txt,txt[:300])
 # Typed recall mode on adjective, exact answer and scoring
 page.locator('[data-module="Vocabulary Workout"]').click();page.locator('[data-vwl="B1"]').click()
 page.evaluate('(n)=>{vocabWorkoutIndex=n;vocabWorkoutChoice=-1;vocabWorkoutTyped="";vocabWorkoutChecked=false;render()}',134)
 target=page.evaluate("()=>ADJECTIVES.filter(x=>x[3]==='B1')[51][0]")
 page.locator('#vwTyped').fill(target);page.locator('#vwCheck').click();txt=page.locator('#workspace').inner_text()
 check('b1_typed_recall_correct_answer', 'Correct! +5 XP' in txt,{'target':target,'feedback':txt[-180:]})
 print('typed ok',flush=True)
 # Word-family recognition mode and Review identity
 page.locator('[data-module="Vocabulary Workout"]').click();page.locator('[data-vwl="B1"]').click()
 page.evaluate('(n)=>{vocabWorkoutIndex=n;vocabWorkoutChoice=-1;vocabWorkoutTyped="";vocabWorkoutChecked=false;render()}',16)
 txt=page.locator('#workspace').inner_text();check('b1_word_family_recognition_mode','Word-family recognition' in txt and 'Which word belongs to the word family' in txt,txt[:300])
 page.locator('#vwReview').click();page.locator('[data-module="Review"]').click();page.wait_for_timeout(40)
 txt=page.locator('#workspace').inner_text()
 if 'B1 · Verbs' in txt or 'B1 · Prepositions' in txt or 'B1 · Adjectives' in txt:
  page.locator('#reviewreveal').click();page.locator('[data-rate="Good"]').click();page.wait_for_timeout(30);txt=page.locator('#workspace').inner_text()
 check('word_family_review_category_preserved','B1 · Word Families' in txt,txt[:180])
 print('family ok',flush=True)
 # A1/A2 workout regression smoke
 page.locator('[data-module="Vocabulary Workout"]').click()
 for level in ['A1','A2']:
  page.locator(f'[data-vwl="{level}"]').click();page.wait_for_timeout(30)
  txt=page.locator('#workspace').inner_text();check(f'{level}_workout_still_loads',level in txt and 'VOCABULARY WORKOUT' in txt)
 print('levels ok',flush=True)
 # Responsive B1 Vocabulary
 for width in [375,390,768,1280]:
  page.set_viewport_size({'width':width,'height':900});page.locator('[data-module="Vocabulary"]').click();page.locator('[data-vlevel="B1"]').click();page.wait_for_timeout(40)
  overflow=page.evaluate('document.documentElement.scrollWidth>document.documentElement.clientWidth')
  check(f'responsive_no_overflow_{width}',not overflow)
 browser.close()
check('zero_javascript_runtime_errors',len(page_errors)==0,page_errors)
check('zero_console_errors',len(console_errors)==0,console_errors)
report={'release':'v273','stage':'Stage 4 · Application Integration & Final Deep QA','test_environment':'Chromium headless via Playwright page.set_content; widths 375, 390, 768, 1280 px','results':results,'summary':{'passed':sum(x['status']=='PASS' for x in results),'failed':sum(x['status']=='FAIL' for x in results),'page_errors':page_errors,'console_errors':console_errors},'inventory':counts}
Path('/mnt/data/dq_v273_stage4/QA-REPORT-B1-VOCAB-STAGE4-FINAL-v273.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
