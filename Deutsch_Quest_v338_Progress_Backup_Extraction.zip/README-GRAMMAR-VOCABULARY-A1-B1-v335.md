# Deutsch Quest v335 — Grammar & Vocabulary A1–B1 Deep Audit

## Release decision
Static/source audit completed against the exact integrated v334 archive. The audit re-derived live bank counts and checked record fields, same-level exact duplicates, grammar coverage, focused practice answer integrity, noun metadata and JavaScript syntax. No new confirmed language error justified rewriting content in this pass; prior stage corrections are retained.

## Important reconciliation
- The initial `GRAMMAR` array contains 39 A1, 35 A2 legacy/base and 27 B1 records. The 23 canonical A2 records are appended dynamically and must be counted separately.
- A1 modal lesson title is legacy; the actual lesson content includes `sollen` and six-person forms. It was not renamed to protect progress identity.
- Vocabulary is distributed across several banks and different data shapes. Use the category-by-level inventory in the QA report, not a single array total.

## QA boundary
This is internal source/editorial QA, not an independent native-speaker sign-off or fresh dictionary lookup of every entry. Physical-device acceptance remains separate.
