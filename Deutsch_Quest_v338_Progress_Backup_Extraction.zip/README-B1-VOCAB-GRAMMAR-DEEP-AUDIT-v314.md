# Deutsch Quest v314 — B1 Vocabulary & Grammar Deep Audit

## Scope
This release follows v313 and performs:
- A source-derived inventory and structural re-audit of every B1 vocabulary bank.
- An official Goethe B1 Wortliste text crosswalk for B1 verb lemmas/base lemmas.
- A fresh internal linguistic review of all 27 B1 grammar lessons.
- Direct corrections to confirmed teaching issues.

## Vocabulary results
| Bank | Records |
|---|---:|
| Nouns | 304 |
| Verbs | 86 |
| Adjectives | 61 |
| Adverbs/function words | 36 |
| Prepositions | 13 |
| Phrases | 219 |
| Word families | 15 |

All 86 B1 verbs have six present-tense forms and principal-part metadata (Präteritum, Partizip II and auxiliary). All 304 B1 noun records have lemma, English meaning, plural, example and topic. Duplicate checks passed within the audited banks.

### Goethe crosswalk
- Existing record-level noun metadata identifies 47 exact matches in the official Goethe B1 Wortliste.
- 253 nouns are topic-aligned/supplementary and are not individually confirmed as exact Goethe list items.
- 59 of 86 B1 verb lemmas/base lemmas were located in official PDF text searches.
- 27 verbs were not located by the selected exact searches and remain explicitly unconfirmed/supplementary. A failed text search is not proof of absence, because inflection, reflexive variants, compounds and PDF text extraction can affect matching.
- Individual exact crosswalks for all adjectives, adverbs, prepositions, phrases and word-family members are not claimed in this release.

The official Goethe foreword states that the B1 lexical inventory comprises approximately 2,400 lexical units and describes the Wortliste as a reference overview, not as a self-study exercise book.

## Grammar results
All 27 B1 lessons were reviewed for rule accuracy, morphology, syntax, word order, case government, examples, translations, common errors and scope distinctions.

Six confirmed improvements were made:
1. Futur I: a Futur-II example was removed and replaced with a genuine Futur-I example.
2. Passive: explicit contrast among Vorgangspassiv, Zustandspassiv and passive Perfekt.
3. N-declension: complete Name/Herr paradigms and the genitive -ns distinction.
4. Adjective declension: substantivised adjectives after etwas/nichts.
5. Genitive prepositions: more natural cancellation example.
6. Reflexive verb lesson: improved English gloss.

## QA
- 18/18 targeted checks passed.
- 3/3 inline JavaScript scripts passed `node --check`.
- ZIP integrity verified after packaging.

## Limitations
This is an internal linguistic/editorial audit, not a native-speaker certification. A complete exact Goethe-list crosswalk for every vocabulary bank is not claimed. No physical iPhone Safari or Android Chrome acceptance test was performed.

## Official reference
Goethe-Zertifikat B1 Wortliste (2016): https://www.goethe.de/pro/relaunch/prf/id/Goethe-Zertifikat_B1_Wortliste.pdf
