# Deutsch Quest v332 — Hören B1 Deep Content Audit

## Release decision
**PASS — static content and source QA.** Physical-device acceptance and independent human/native-speaker review remain separate gates.

## Baseline
- Application: Deutsch Quest v331.1 A1 Audio Playback Hotfix
- Current Hören B1 exam bank: v320
- Recording scripts and audio assets: v281–v282

## Deep audit and correction
One ambiguity was found in Teil 3, Aufgabe 21. The previous statement claimed Tobias had no possibility of attending the study group, although the dialogue says the group meets on Friday, Tobias normally works late, and his colleague suggests a possible schedule adjustment. The item therefore tested an inference about feasibility rather than a direct listening fact.

The statement is now:
- **Die Lerngruppe trifft sich am Freitag.**
- Answer: **Richtig**
- Evidence: **sie trifft sich am Freitag**

The bank, answer key and embedded app data were updated together. The recording was not changed.

## Re-audit results
- 30/30 sequential unique questions
- 30/30 answer-key entries aligned with part, audio ID, answer and evidence
- 30/30 evidence excerpts present in the corresponding transcript
- 30/30 valid option sets and answer values
- 8/8 unique audio IDs mapped to existing MP3 files
- 8/8 recording scripts match the bank transcripts exactly
- 8/8 MP3 files match manifest byte sizes and SHA-256 hashes
- 8/8 MP3 files pass ffprobe and full ffmpeg decoding
- All 8 files are MP3, 24 kHz, mono, 48 kbps
- 3/3 inline JavaScript blocks and service worker syntax checked

## Goethe format cross-check
The public Goethe B1 model set specifies four parts, 30 items, 40 minutes and a 10/5/7/8 item distribution, with replay limits 2/1/1/2. The v320/v332 structure matches these requirements.

## Preservation
- All 30 questions retained; none added or removed.
- All 8 MP3 files and 8 recording scripts retained byte-for-byte.
- No progress keys or learner-state namespaces changed.
- No changes to A1, A2, or other B1 modules.

## Limitations
Audio files were technically decoded and matched to the exact source scripts. This is not a human transcription/listening certification. Native-speaker review and physical iPhone Safari / Android Chrome acceptance remain pending. Deutsch Quest tasks and recordings are original practice materials, not official Goethe examination content.
