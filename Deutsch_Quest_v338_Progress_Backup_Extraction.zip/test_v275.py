from playwright.sync_api import sync_playwright
import json, re
p='/mnt/data/grammar_b1_stage2/Deutsch_Quest_v275_Grammar_B1_Stage2.html'
html=open(p,encoding='utf-8').read()
results=[]; errors=[]; console=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':390,'height':844})
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('console',lambda m:console.append(m.text) if m.type=='error' else None)
 page.set_content(html,wait_until='domcontentloaded',timeout=120000)
 page.wait_for_timeout(800)
 results.append(['initial_mount',bool(page.locator('#workspace').count())])
 page.locator('[data-nav="Grammar"]').click(); page.wait_for_timeout(200)
 results.append(['grammar_nav', 'GRAMMAR WORKSHOP' in page.locator('#workspace').inner_text()])
 page.locator('[data-gl="B1"]').click(); page.wait_for_timeout(200)
 text=page.locator('#workspace').inner_text()
 results.append(['b1_overview', '27 consolidated topics' in text and 'individual linguistic review' in text])
 # test every lesson card click using title details summaries
 cards=page.locator('#workspace details.grammar-lesson')
 n=cards.count(); results.append(['b1_lesson_cards',n>=27])
 # find all visible summaries with title and open each in turn; first 27 lesson cards may be after other details. Use matching exact titles from embedded data extracted externally.
 titles=json.load(open('/mnt/data/grammar_b1_stage2/B1_grammar_dump.json',encoding='utf8'))
 # get actual titles from source by parsing app global
 page.evaluate('window.__auditTitles = GRAMMAR.filter(g=>g.level==="B1").map(g=>g.title)')
 js_titles=page.evaluate('window.__auditTitles')
 ok=0
 for title in js_titles:
  summ=page.locator('#workspace details.grammar-lesson > summary').filter(has_text=title)
  if summ.count():
   detail=summ.first.locator('xpath=..')
   detail.evaluate('(e)=>e.open=true')
   txt=detail.inner_text()
   if 'CORE IDEA' in txt and 'STRUCTURE SNAPSHOT' in txt and 'WATCH OUT' in txt and 'TRY IT YOURSELF' in txt:
    ok+=1
   detail.evaluate('(e)=>e.open=false')
 results.append(['b1_lesson_render',ok==27,ok])
 results.append(['all_linguistic_fields_in_data',page.evaluate('GRAMMAR.filter(g=>g.level==="B1").every(g=>g.commonMistakes?.length>=3 && g.deepExamples?.length>=3 && g.linguisticAuditStatus)')])
 # completion action remains functional; B1 focused practice remains intentionally disabled until Stage 3 builds verified questions
 first=page.locator('#workspace details.grammar-lesson').nth(1)
 first.evaluate('(e)=>e.open=true')
 before=page.locator('#xp').inner_text()
 done=first.locator('[data-done]').first
 done.click(); page.wait_for_timeout(100)
 after=page.locator('#xp').inner_text()
 results.append(['b1_lesson_completion_xp', int(after)-int(before)==20])
 results.append(['b1_practice_not_mislabelled', page.locator('#workspace details.grammar-lesson').nth(1).locator('button:disabled',has_text='Dedicated B1 practice').count()==1])
 # ensure A1 A2 still reachable and counts
 page.locator('[data-gl="A1"]').click(); page.wait_for_timeout(100)
 results.append(['a1_regression', '39 A1 lessons' in page.locator('#workspace').inner_text() or '39 lessons' in page.locator('#workspace').inner_text()])
 page.locator('[data-gl="A2"]').click(); page.wait_for_timeout(100)
 results.append(['a2_regression', '23 A2 lessons' in page.locator('#workspace').inner_text()])
 for w in [375,390,768,1280]:
  page.set_viewport_size({'width':w,'height':844}); page.wait_for_timeout(50)
  ov=page.evaluate('document.documentElement.scrollWidth > document.documentElement.clientWidth')
  results.append([f'no_overflow_{w}',not ov])
 b.close()
print(json.dumps({'results':results,'page_errors':errors,'console_errors':console},ensure_ascii=False,indent=2))
