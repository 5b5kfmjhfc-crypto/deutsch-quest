# Deutsch Quest v311 — A1–A2 Final Content Freeze Audit

## Decision
A1 and A2 content is ready to be treated as **content-frozen** for the current curriculum scope after v311. Source/static QA passed. Browser runtime and physical-device acceptance remain separate release gates and are not claimed as complete.

## Critical corrections
1. **A2 canonical Grammar coverage:** the v310 whitelist contained 23 canonical titles, but only 12 matching learner-facing lesson records existed. Added the 11 missing canonical lessons with objectives, prerequisites, explanations, examples, common mistakes, A1 bridge links, four-skill transfer and mastery checks. The legacy lesson records were retained.
2. **A2 focused practice:** the earlier 328-question figure could not be reproduced from the v310 live title-linked bank. Recounting the source found 96 linked questions, with gaps across several canonical topics. Added 104 questions. The final canonical bank now contains **200 questions across 23 topics**, with **8–10 questions per topic**. All options, answer keys and explanations pass structural checks.
3. **Progression metadata:** updated the progression audit and learner-facing A2 metric to derive the count from the live canonical bank: 200. The intended curriculum split remains 20 A2 core topics and 3 A2 extensions.

## A1 inventory retained
- Grammar: 39 lessons (27 core + 12 practical extensions), 141 A1 Grammar Practice questions and 136 focused lesson questions.
- Vocabulary: 669 general A1 records, including 587 nouns; other separate banks include 203 verbs, 122 adjectives, 76 adverb/function-word entries, 15 prepositions, 526 phrases and 15 word-family groups. These banks overlap in function and should not be summed as unique words.
- Hören: 24 short-practice items, 10 Listening Intelligence passages, 15 mock tasks and 49 recorded MP3 tracks.
- Lesen: 24 practice items and 15 mock items. Schreiben: 20 tasks. Sprechen: 20 tasks.

## A2 inventory retained and reconciled
- Grammar: 23 canonical lessons (20 core + 3 extensions), 200 focused questions and 48 integrated mixed-quiz questions.
- Vocabulary: 901 lexical entries excluding 18 word-family groups: 354 nouns, 89 verbs, 38 adjectives, 26 adverbs/function words, 10 prepositions and 384 phrases.
- Hören: 49 dedicated passages, 2 additional core exercises, 36 fixed MP3 assets and 20 mock tasks.
- Lesen: 24 practice sets / 120 questions and a 20-question integrated mock.
- Schreiben: 10 toolkit units, 8 guided tasks, 8 independent tasks, 4 mock sets and 24 model answers checked.
- Sprechen: 8 toolkit units, 6 guided tasks, 8 independent tasks and 4 mock sets.

## Final QA
- All 23 A2 canonical lesson records present and unique.
- Every canonical lesson has explicit prerequisites and valid A1 foundation links.
- Every canonical topic has at least 8 focused questions; no duplicate question stems within a canonical topic.
- A1 skill answer keys and required writing/speaking fields pass.
- A1/A2 vocabulary required-field and duplicate checks pass for the audited general lexical bank.
- 3/3 inline JavaScript scripts pass `node --check`.
- Static DOM IDs are unique; all local asset references resolve.
- 93/93 MP3 assets decode successfully.

## Progress preservation
No existing lesson title was renamed, no existing saved-progress key was migrated or reset, and no completed A1/A2 skill bank or audio asset was removed. The 11 new canonical A2 lessons appear as new learning targets; their completion state starts independently.

## Acceptance boundary
This is a content/source-level freeze. Chromium browser navigation was blocked by the execution environment; no live browser interaction, physical iPhone Safari or Android Chrome test is claimed. No native-speaker certification of every item is claimed. The app remains an original study resource, not an official Goethe examination or certified CEFR assessment.
