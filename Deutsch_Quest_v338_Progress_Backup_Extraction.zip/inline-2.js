
const DQ_A2_LISTENING_STAGE6_AUDIO_AUDIT_V251 = {
 version:"v251",
 stage:6,
 status:"code-level audio audit and browser diagnostics implemented; physical device acceptance pending",
 checks:{
  speechSynthesisFeatureDetection:"Checks both speechSynthesis and SpeechSynthesisUtterance before playback.",
  germanVoiceFiltering:"Filters installed voices by German locale; prefers de-DE where available.",
  voiceSelection:"Supports automatic selection or an explicitly selected installed German voice.",
  asynchronousVoiceLoading:"Refresh retries voice enumeration while the browser populates its voice list; voiceschanged remains supported.",
  playbackCoordination:"Standard playback and direct audio actions cancel pending multi-speaker dialogue before starting, preventing delayed dialogue segments from resuming over a new clip; a dedicated stop action cancels active playback.",
  playbackFeedback:"Voice test reports start, completion and non-cancellation errors through an accessible live status region.",
  rateControl:"User speed preference is retained and clamped to a safe supported range.",
  textHandling:"Empty text is rejected; utterance language is explicitly set to de-DE.",
  crossModulePlayback:"Direct speech playback entry points cancel queued dialogue playback before starting another clip."
 },
 pronunciationCoverage:{
  testSentence:"Guten Morgen! Ich möchte zwölf Brötchen kaufen. Können Sie mir bitte helfen?",
  phoneticTargets:["ch in möchte","ö in möchte","ü in zwölf","ö in Brötchen","German sentence melody and question intonation"],
  limitation:"A TTS test sentence cannot certify native-speaker pronunciation, natural prosody or phoneme quality; human listening review is required."
 },
 deviceAcceptance:{
  required:"Open the updated HTML in iPhone Safari and test the voice list, test sentence, stop button, speed slider, and at least one A2 passage.",
  verify:["German voice is actually selected (not an unrelated default voice)","Audio starts after a direct tap","No overlapping or stuck playback","Stop cancels playback promptly","Speed changes are audible and persist after reopening","Umlauts and ch sounds are intelligible","Audio remains audible with the device's current silent/focus/audio routing settings"],
  status:"not yet tested on a physical iPhone or Safari"
 },
 knownLimitations:[
  "SpeechSynthesis is device/browser-generated audio, not a fixed recording; voice and prosody differ by device.",
  "The app cannot force installation of German iOS voices or guarantee an offline voice.",
  "Automated browser tests cannot judge human-perceived pronunciation quality."
 ]
};

const DQ_A2_LISTENING_STAGE5_QA_V250={"version":"v250","stage":5,"status":"Chromium mobile-emulation QA completed; Safari/iPhone not directly tested","testEnvironment":{"browser":"Chromium headless","viewportWidths":[390,375],"deviceScaleFactor":3,"mobileTouchEmulation":true},"checks":{"applicationBoot":"passed","examOverviewAndStart":"passed","Teil1RadioAnswerPersistence":"passed","Teil2MatchingSelectionPersistence":"passed","Teil2DuplicateOptionGuard":"passed","Teil4JaNeinSelection":"passed","manualSubmissionAndScoring":"passed","resultReviewAndTranscriptReveal":"passed","javascriptRuntimeErrors":"0 during tested flow","horizontalOverflow":"found and corrected in Teil 2 matching controls","liveTextToSpeech":"not tested; headless environment does not certify iOS speech synthesis"},"correction":{"issue":"At 375px mobile viewport, native select controls in Teil 2 expanded to 242px inside a narrower grid cell and caused 59px horizontal page overflow.","fix":"Applied width:100%, min-width:0, max-width:100%, and border-box sizing to matching selects and constrained their grid items."},"validation":{"fullExamTasks":20,"partDistribution":[5,5,5,5],"mobileHorizontalOverflowExpected":"none at 375px and 390px","jsSyntax":"passed"},"limitations":["Chromium mobile emulation is not Safari on a physical iPhone.","No actual device TTS voice or playback timing test was performed.","Storage persistence across browser restarts was not certified in this test environment."]};


DQ_A2_VERB_DEEP_AUDIT.version="v266"; DQ_A2_VERB_DEEP_AUDIT.count=89; DQ_A2_VERB_DEEP_AUDIT.coverage="all 89 unique A2 verb entries after duplicate reconciliation"; DQ_A2_VERB_DEEP_AUDIT.checks.push("late-added A2 verb paradigms individually rechecked in v266"); DQ_A2_VERB_DEEP_AUDIT.external_dictionary_certification="selective dictionary checks only; internal review for remaining records";
DQ_A2_ADJECTIVE_DEEP_AUDIT.version="v266"; DQ_A2_ADJECTIVE_DEEP_AUDIT.coverage="all 38 A2 adjective entries rechecked in final integration";
DQ_A2_ADVERB_DEEP_AUDIT.version="v266"; DQ_A2_ADVERB_DEEP_AUDIT.coverage="all 26 A2 adverbs/function words rechecked in final integration";

// Deutsch Quest v266 — completed Vocabulary A2 Stage 1 audit manifest.
const DQ_A2_STAGE1_FINAL_AUDIT = {
 version:"v266", status:"completed",
 method:"one integrated learner-facing stage; review batches used only as internal QA controls",
 counts:{nouns:354,verbs:89,adjectives:38,adverbsAndFunctionWords:26,prepositions:10,phrases:384,lexicalEntries:901,wordFamilyGroups:18,totalIncludingFamilyGroups:919},
 goetheCrosswalk:{coreListed:121,supplementaryChecked:780,pending:0},
 duplicatesMerged:{sameBankNouns:20,sameBankVerbs:10,sameBankPhrases:3,crossBankPhraseDuplicates:3,total:36},
 missingVerbParadigmsAdded:["sich entscheiden","stattfinden","bedeuten"],
 corrections:["die Einnahme: clarified financial plural and singular medication-intake sense","der Schwindel: improved example collocation","die Saat: improved example naturalness","überrascht: corrected superlative to am überraschtesten","zuständig: removed unnatural comparative paraphrase","auf dem Weg zu: made dative government explicit","same-bank duplicate entries merged while preserving variants in audit archive"],
 limitations:["internal linguistic/editorial review is not formal CEFR certification","not every lexical item has individual dictionary certification","selective external dictionary and official Goethe word-list checks are documented in the QA report"]
};

LESSON_PRACTICE.push({"title":"Modal verbs: können, müssen, wollen, dürfen, möchten","q":"Complete: Ihr ___ heute pünktlich sein. (sollen)","o":["sollt","sollen","soll"],"a":"sollt","why":"The subject ihr takes sollt. Sollen expresses an expectation or instruction."});
