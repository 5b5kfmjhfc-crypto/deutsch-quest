from pathlib import Path
import json,re
p=Path('/mnt/data/dq_v252_work/index.html')
s=p.read_text()
# Guard against accidental duplicate injection
if 'if(state.active==="Lesen A2 · Teil 2")' in s:
    raise SystemExit('Teil 2 already exists')
bank=[
{
"title":"Kaufhaus Stadtblick","topic":"Einkaufen · Abteilungen · Dienstleistungen",
"de":"Kaufhaus Stadtblick – Informationen für unsere Kunden\nErdgeschoss: Information, Kasse, Schmuck, Uhren, Parfümerie, Schreibwaren, Schlüsselservice und Blumen.\n1. Stock: Damenmode, Kindermode, Schuhe, Babyartikel und Spielwaren.\n2. Stock: Herrenmode, Sportkleidung, Haushaltswaren, Geschirr, Töpfe und Lampen.\n3. Stock: Computer, Handys, Kameras, Fernseher, CDs, DVDs und Videospiele.\n4. Stock: Bücher, Geschenke, Koffer, Café, Friseur und Kunden-WC.\nUnser Kundenservice hilft Ihnen gern am Informationsschalter im Erdgeschoss.",
"en":"Stadtblick Department Store – Information for customers. Ground floor: information, checkout, jewellery, watches, perfume, stationery, key service and flowers. 1st floor: women's and children's clothing, shoes, baby products and toys. 2nd floor: men's clothing, sportswear, household goods, dishes, pots and lamps. 3rd floor: computers, mobile phones, cameras, televisions, CDs, DVDs and video games. 4th floor: books, gifts, suitcases, café, hairdresser and customer toilets. Customer service is at the information desk on the ground floor.",
"vocab":[["das Erdgeschoss","ground floor"],["die Haushaltswaren (Pl.)","household goods"],["die Schreibwaren (Pl.)","stationery"],["der Schlüsselservice","key-cutting service"],["der Informationsschalter","information desk"]],
"questions":[
["Sie möchten einen Schlüssel nachmachen lassen. Wohin gehen Sie?",["Ins Erdgeschoss.","In den 2. Stock.","In den 4. Stock."],0,"The key service is listed on the ground floor.","Erdgeschoss: ... Schlüsselservice"],
["Sie suchen Schuhe für Ihr Kind. In welchen Stock gehen Sie?",["In den 3. Stock.","In den 1. Stock.","In den 2. Stock."],1,"Shoes and children's clothing are on the first floor.","1. Stock: Damenmode, Kindermode, Schuhe"],
["Sie brauchen eine neue Lampe für Ihr Wohnzimmer. Wo finden Sie sie?",["Im Erdgeschoss.","Im 4. Stock.","Im 2. Stock."],2,"Lamps are listed on the second floor.","2. Stock: ... Lampen"],
["Sie möchten ein neues Handy kaufen. Wohin gehen Sie?",["In den 3. Stock.","In den 1. Stock.","In den 4. Stock."],0,"Mobile phones are sold on the third floor.","3. Stock: Computer, Handys, Kameras"],
["Sie möchten nach dem Einkaufen einen Kaffee trinken und ein Buch kaufen. Welcher Stock passt?",["Der 2. Stock.","Der 4. Stock.","Das Erdgeschoss."],1,"Both the café and books are on the fourth floor.","4. Stock: Bücher ... Café"]
]},
{
"title":"Stadtbibliothek am Park","topic":"Bibliothek · Öffnungszeiten · Angebote",
"de":"Stadtbibliothek am Park – Öffnungszeiten und Angebote\nMontag: geschlossen.\nDienstag bis Freitag: 9–19 Uhr.\nSamstag: 10–14 Uhr. Sonntag: geschlossen.\nBücher und Zeitschriften können Sie an der Selbstbedienung zurückgeben. Der Rückgabeautomat am Eingang ist täglich von 7 bis 22 Uhr geöffnet.\nDienstag, 16 Uhr: Vorlesen für Kinder ab 5 Jahren, Kinderraum.\nMittwoch, 18 Uhr: Sprachcafé Deutsch, Gruppenraum 2.\nDonnerstag, 15 Uhr: Beratung zur Internetsuche, Computerraum.\nFür Lernplätze ist keine Anmeldung nötig. Für Gruppen ab fünf Personen reservieren Sie bitte vorher.",
"en":"City Library by the Park – opening hours and activities. Closed Monday. Tuesday to Friday 9 a.m.–7 p.m.; Saturday 10 a.m.–2 p.m.; closed Sunday. Books and magazines can be returned at the self-service machine. The return machine at the entrance is open daily from 7 a.m. to 10 p.m. Tuesday 4 p.m.: reading for children aged 5+, children's room. Wednesday 6 p.m.: German conversation café, group room 2. Thursday 3 p.m.: advice on internet searches, computer room. Study places do not require registration. Groups of five or more should reserve in advance.",
"vocab":[["die Selbstbedienung","self-service"],["der Rückgabeautomat","return machine"],["das Vorlesen","reading aloud"],["das Sprachcafé","conversation café"],["einen Platz reservieren","to reserve a place"]],
"questions":[
["Sie möchten am Montag Bücher ausleihen. Was müssen Sie wissen?",["Die Bibliothek öffnet um 9 Uhr.","Die Bibliothek ist geschlossen.","Sie können nur bis 14 Uhr bleiben."],1,"The library is closed on Monday.","Montag: geschlossen."],
["Sie möchten am Sonntag ein Buch zurückgeben. Wann ist das möglich?",["Von 7 bis 22 Uhr.","Von 10 bis 14 Uhr.","Das ist sonntags nicht möglich."],0,"The return machine is open daily, including Sunday, from 7 to 22.","Der Rückgabeautomat am Eingang ist täglich von 7 bis 22 Uhr geöffnet."],
["Ihre Tochter ist sechs Jahre alt. Sie möchte eine Geschichte hören. Wann passt das Angebot?",["Am Mittwoch um 18 Uhr.","Am Donnerstag um 15 Uhr.","Am Dienstag um 16 Uhr."],2,"The reading activity for children aged five and over is Tuesday at 16:00.","Dienstag, 16 Uhr: Vorlesen für Kinder ab 5 Jahren"],
["Sie möchten Deutsch sprechen üben. Wohin gehen Sie?",["Am Mittwoch in den Gruppenraum 2.","Am Dienstag in den Kinderraum.","Am Donnerstag in den Computerraum."],0,"The German conversation café takes place Wednesday in group room 2.","Mittwoch, 18 Uhr: Sprachcafé Deutsch, Gruppenraum 2."],
["Sie möchten mit sechs Freunden zusammen lernen. Was sollten Sie tun?",["Sie müssen einen Lernplatz bezahlen.","Sie sollten vorher reservieren.","Sie müssen am Montag kommen."],1,"Groups of five or more should reserve in advance.","Für Gruppen ab fünf Personen reservieren Sie bitte vorher."]
]},
{
"title":"Kulturhaus West – Wochenprogramm","topic":"Veranstaltungen · Kultur · Freizeit",
"de":"Kulturhaus West – Programm vom 12. bis 17. Mai\nMontag: geschlossen.\nDienstag, 19 Uhr: Filmabend im Saal 1. Eintritt 5 Euro.\nMittwoch, 17 Uhr: Malkurs für Anfänger im Atelier. Materialien sind im Preis enthalten.\nDonnerstag, 18 Uhr: Tanzkurs für Paare im Saal 2. Bitte Sportschuhe mitbringen.\nFreitag, 20 Uhr: Konzert mit der Band „Nordwind“ im großen Saal. Eintritt 12 Euro.\nSamstag, 11 Uhr: Theater für Kinder ab 6 Jahren im Saal 1. Eintritt 4 Euro.\nKarten bekommen Sie online oder an der Abendkasse. Für den Malkurs ist eine Anmeldung bis Dienstag nötig.",
"en":"Kulturhaus West – programme from 12 to 17 May. Closed Monday. Tuesday 7 p.m.: film evening in Hall 1, admission €5. Wednesday 5 p.m.: painting course for beginners in the studio; materials included. Thursday 6 p.m.: dance course for couples in Hall 2; bring sports shoes. Friday 8 p.m.: concert by the band Nordwind in the large hall, admission €12. Saturday 11 a.m.: theatre for children aged 6+, Hall 1, admission €4. Tickets online or at the box office. Registration for the painting course is required by Tuesday.",
"vocab":[["der Eintritt","admission / entrance fee"],["der Anfänger","beginner"],["das Atelier","studio"],["die Abendkasse","box office"],["sich anmelden","to register"]],
"questions":[
["Sie möchten einen Film sehen und nicht mehr als sechs Euro bezahlen. Was passt?",["Der Filmabend am Dienstag.","Das Konzert am Freitag.","Das Theater am Samstag."],0,"The film costs five euros, within the six-euro budget.","Dienstag, 19 Uhr: Filmabend ... Eintritt 5 Euro."],
["Sie haben noch nie gemalt und möchten es lernen. Welches Angebot ist richtig?",["Der Tanzkurs am Donnerstag.","Der Malkurs am Mittwoch.","Das Konzert am Freitag."],1,"The painting course is specifically for beginners.","Mittwoch, 17 Uhr: Malkurs für Anfänger"],
["Sie möchten mit Ihrem Partner tanzen. Was müssen Sie mitbringen?",["Malsachen.","Eine Eintrittskarte für 12 Euro.","Sportschuhe."],2,"The couples' dance course asks participants to bring sports shoes.","Tanzkurs für Paare ... Bitte Sportschuhe mitbringen."],
["Sie mögen Live-Musik und können erst am Freitagabend kommen. Wohin gehen Sie?",["Zum Konzert um 20 Uhr.","Zum Filmabend um 19 Uhr.","Zum Kindertheater um 11 Uhr."],0,"The live concert is on Friday at 20:00.","Freitag, 20 Uhr: Konzert mit der Band „Nordwind“"],
["Ihr sechsjähriges Kind möchte ins Theater. Wann können Sie gehen?",["Am Mittwoch um 17 Uhr.","Am Samstag um 11 Uhr.","Am Donnerstag um 18 Uhr."],1,"The children's theatre is for children aged six and over on Saturday.","Samstag, 11 Uhr: Theater für Kinder ab 6 Jahren"]
]},
{
"title":"Hauptbahnhof – Service und Reiseinformationen","topic":"Reisen · Bahnhof · Service",
"de":"Hauptbahnhof – Serviceinformationen\nReisezentrum: Montag bis Freitag 6–20 Uhr, Samstag und Sonntag 8–18 Uhr. Hier können Sie Fahrkarten kaufen und Sitzplätze reservieren.\nGepäckschließfächer: täglich 5–23 Uhr, neben Gleis ಂಗ.\nFundbüro: Montag bis Freitag 9–17 Uhr, im Servicegebäude am Nordausgang.\nFahrradparkhaus: rund um die Uhr geöffnet, Eingang Südseite.\nBäckerei: täglich 6–21 Uhr, gegenüber von Gleis 5.\nDie Toiletten befinden sich im Erdgeschoss neben dem Aufzug. Für Hilfe beim Einsteigen wenden Sie sich bitte mindestens 30 Minuten vor der Abfahrt an das Reisezentrum.",
"en":"Main Station – service information. Travel centre: Monday to Friday 6 a.m.–8 p.m.; Saturday and Sunday 8 a.m.–6 p.m. You can buy tickets and reserve seats there. Luggage lockers: daily 5 a.m.–11 p.m., next to platform 8. Lost property office: Monday to Friday 9 a.m.–5 p.m., in the service building at the north exit. Bicycle parking garage: open around the clock, south entrance. Bakery: daily 6 a.m.–9 p.m., opposite platform 5. Toilets are on the ground floor next to the lift. For boarding assistance, contact the travel centre at least 30 minutes before departure.",
"vocab":[["das Reisezentrum","travel centre"],["das Schließfach","locker"],["das Fundbüro","lost property office"],["rund um die Uhr","around the clock"],["der Nordausgang","north exit"]],
"questions":[
["Sie möchten am Sonntag eine Fahrkarte kaufen. Wohin gehen Sie?",["Zum Reisezentrum.","Zum Fundbüro.","Zur Bäckerei."],0,"Tickets are sold at the travel centre, which is open on Sunday.","Reisezentrum ... Samstag und Sonntag 8–18 Uhr. Hier können Sie Fahrkarten kaufen"],
["Sie kommen spät am Abend an und möchten Ihren Koffer einschließen. Was ist wichtig?",["Die Schließfächer schließen um 17 Uhr.","Die Schließfächer sind bis 23 Uhr geöffnet.","Die Schließfächer sind nur am Wochenende geöffnet."],1,"The lockers are open daily until 23:00.","Gepäckschließfächer: täglich 5–23 Uhr"],
["Sie haben gestern einen Schal im Zug vergessen. Wo fragen Sie?",["In der Bäckerei.","Im Fahrradparkhaus.","Im Fundbüro."],2,"Lost items are handled by the lost property office.","Fundbüro: Montag bis Freitag 9–17 Uhr"],
["Sie möchten Ihr Fahrrad sicher und auch nachts abstellen. Wohin fahren Sie?",["Zum Fahrradparkhaus am Südeingang.","Zum Reisezentrum.","Zum Nordausgang."],0,"The bicycle garage is open 24 hours and has a south entrance.","Fahrradparkhaus: rund um die Uhr geöffnet, Eingang Südseite."],
["Sie brauchen Hilfe beim Einsteigen in den Zug. Wann müssen Sie Bescheid sagen?",["Erst nach der Abfahrt.","Mindestens 30 Minuten vor der Abfahrt.","Am Vortag bis 17 Uhr."],1,"The notice says to contact the travel centre at least 30 minutes before departure.","mindestens 30 Minuten vor der Abfahrt an das Reisezentrum"]
]},
{
"title":"Sportzentrum Aktiv – Kursplan","topic":"Sport · Gesundheit · Kurszeiten",
"de":"Sportzentrum Aktiv – Kursplan\nMontag: 18 Uhr Yoga für Anfänger, Raum 2.\nDienstag: 17 Uhr Schwimmkurs für Kinder ab 7 Jahren, kleines Becken.\nMittwoch: 19 Uhr Badminton für Erwachsene, Halle 1. Schläger können ausgeliehen werden.\nDonnerstag: 18 Uhr Rückentraining, Raum 1. Bitte eine Matte mitbringen.\nFreitag: 16 Uhr Familien-Schwimmen, großes Becken. Kinder nur in Begleitung eines Erwachsenen.\nSamstag: 10 Uhr Laufgruppe, Treffpunkt am Haupteingang.\nEine Anmeldung ist online bis einen Tag vor dem Kurs möglich. Mitglieder zahlen keine zusätzliche Kursgebühr.",
"en":"Aktiv Sports Centre – course schedule. Monday 6 p.m.: beginner yoga, room 2. Tuesday 5 p.m.: swimming course for children aged 7+, small pool. Wednesday 7 p.m.: badminton for adults, Hall 1; rackets can be borrowed. Thursday 6 p.m.: back training, room 1; bring a mat. Friday 4 p.m.: family swimming, large pool; children only with an adult. Saturday 10 a.m.: running group, meeting at the main entrance. Register online up to one day before the course. Members pay no extra course fee.",
"vocab":[["der Schwimmkurs","swimming course"],["das Becken","pool"],["der Schläger","racket"],["die Matte","mat"],["in Begleitung","accompanied by"]],
"questions":[
["Sie sind Anfängerin und möchten Yoga machen. Wann ist der passende Kurs?",["Am Montag um 18 Uhr.","Am Mittwoch um 19 Uhr.","Am Samstag um 10 Uhr."],0,"Beginner yoga is scheduled for Monday at 18:00.","Montag: 18 Uhr Yoga für Anfänger"],
["Ihr achtjähriger Sohn möchte schwimmen lernen. Welcher Kurs passt?",["Das Familien-Schwimmen am Freitag.","Der Schwimmkurs am Dienstag.","Das Rückentraining am Donnerstag."],1,"The Tuesday swimming course is for children aged seven and over.","Dienstag: 17 Uhr Schwimmkurs für Kinder ab 7 Jahren"],
["Sie sind erwachsen und möchten Badminton spielen, haben aber keinen Schläger. Was können Sie tun?",["Sie können am Mittwoch einen Schläger ausleihen.","Sie müssen am Freitag einen Schläger kaufen.","Sie können nur am Samstag spielen."],0,"Rackets can be borrowed during the Wednesday adult badminton session.","Mittwoch: ... Badminton für Erwachsene ... Schläger können ausgeliehen werden."],
["Sie möchten etwas für Ihren Rücken tun. Was sollen Sie mitbringen?",["Badeanzug.","Laufschuhe.","Eine Matte."],2,"The back-training class asks participants to bring a mat.","Donnerstag: 18 Uhr Rückentraining ... Bitte eine Matte mitbringen."],
["Sie möchten am Freitag mit Ihrem Kind schwimmen gehen. Welche Regel gilt?",["Kinder dürfen nur mit einem Erwachsenen kommen.","Kinder müssen mindestens sieben Jahre alt sein.","Der Kurs findet im kleinen Becken statt."],0,"Children must be accompanied by an adult for family swimming.","Kinder nur in Begleitung eines Erwachsenen."]
]},
{
"title":"Bürgerhaus Sonnenhof – Informationen","topic":"Gemeinschaft · Beratung · Kurse",
"de":"Bürgerhaus Sonnenhof – Angebote im Juni\nBüro und Anmeldung: Montag bis Freitag 9–12 Uhr, Zimmer 1.\nDeutsch lernen: Dienstag und Donnerstag 17–18.30 Uhr, Raum 3. Kostenlos; bitte vorher anmelden.\nComputerhilfe: Mittwoch 10–12 Uhr, Raum 2. Bringen Sie wenn möglich Ihren Laptop mit.\nEltern-Kind-Treff: Freitag 9.30–11 Uhr, Spielzimmer. Für Kinder bis drei Jahre mit einer erwachsenen Begleitperson.\nReparatur-Café: Samstag 14–17 Uhr, Werkstatt. Kleine Haushaltsgeräte können gemeinsam repariert werden. Ersatzteile kosten extra.\nDer große Saal kann für private Feiern gemietet werden. Informationen dazu gibt es im Büro.",
"en":"Sonnenhof Community Centre – June activities. Office and registration: Monday to Friday 9 a.m.–noon, room 1. German classes: Tuesday and Thursday 5–6:30 p.m., room 3; free, registration required. Computer help: Wednesday 10 a.m.–noon, room 2; bring your laptop if possible. Parent-child group: Friday 9:30–11 a.m., playroom, for children up to age three with an adult. Repair café: Saturday 2–5 p.m., workshop; small household appliances can be repaired together; spare parts cost extra. The large hall can be rented for private parties; ask at the office.",
"vocab":[["die Anmeldung","registration"],["die Computerhilfe","computer assistance"],["die Begleitperson","accompanying person"],["das Haushaltsgerät","household appliance"],["Ersatzteile","spare parts"]],
"questions":[
["Sie möchten sich für einen Deutschkurs anmelden. Wann können Sie das Büro besuchen?",["Am Samstag um 15 Uhr.","Am Mittwoch um 11 Uhr.","Am Donnerstag um 18 Uhr."],1,"The office is open Wednesday from 9 to 12.","Büro und Anmeldung: Montag bis Freitag 9–12 Uhr"],
["Sie arbeiten tagsüber und möchten abends Deutsch lernen. Welches Angebot passt?",["Dienstag oder Donnerstag um 17 Uhr.","Mittwoch um 10 Uhr.","Freitag um 9.30 Uhr."],0,"German classes are offered Tuesday and Thursday evenings.","Deutsch lernen: Dienstag und Donnerstag 17–18.30 Uhr"],
["Ihr Laptop funktioniert nicht richtig. Wo können Sie Hilfe bekommen?",["Im Spielzimmer am Freitag.","In der Werkstatt am Samstag.","Bei der Computerhilfe am Mittwoch."],2,"Computer help takes place Wednesday in room 2.","Computerhilfe: Mittwoch 10–12 Uhr, Raum 2."],
["Sie haben ein zweijähriges Kind und möchten andere Eltern treffen. Wohin gehen Sie?",["Zum Eltern-Kind-Treff am Freitag.","Zum Deutschkurs am Dienstag.","Zum Reparatur-Café am Samstag."],0,"The parent-child group is for children up to three years old with an adult.","Eltern-Kind-Treff: Freitag ... Für Kinder bis drei Jahre"],
["Ihr Toaster ist kaputt. Sie möchten ihn vielleicht selbst reparieren. Was passt?",["Die Computerhilfe.","Das Reparatur-Café am Samstag.","Der Deutschkurs am Donnerstag."],1,"The repair café helps people repair small household appliances.","Reparatur-Café ... Kleine Haushaltsgeräte können gemeinsam repariert werden."]
]}
]
# validate content bank
assert len(bank)==6 and all(len(x['questions'])==5 for x in bank)
for si,x in enumerate(bank):
 for qi,q in enumerate(x['questions']):
  assert len(q[1])==3 and q[2] in (0,1,2), (si,qi)
# JS block
jsbank=json.dumps(bank,ensure_ascii=False,separators=(',',':'))
block=f'''if(state.active==="Lesen A2 · Teil 2"){{
 const bank={jsbank};
 const storageKey="dq-a2-lesen-teil2-v1";
 let run;try{{run=JSON.parse(dqStorageGet(storageKey,"{{}}"))||{{}}}}catch(e){{run={{}}}}
 run.index=Number.isInteger(run.index)?Math.max(0,Math.min(bank.length-1,run.index)):0;
 run.answers=run.answers&&typeof run.answers==="object"?run.answers:{{}};
 run.completed=run.completed&&typeof run.completed==="object"?run.completed:{{}};
 run.awarded=run.awarded&&typeof run.awarded==="object"?run.awarded:{{}};
 run.showTranslation=!!run.showTranslation;
 const persist=()=>dqStorageSet(storageKey,JSON.stringify(run));
 const idx=run.index,t=bank[idx],key="set"+idx,answers=run.answers[key]||{{}},done=!!run.completed[key];
 const countDone=Object.keys(run.completed).filter(k=>run.completed[k]&&Number.isFinite(run.completed[k].score)).length;
 const totalCorrect=Object.values(run.completed).reduce((n,x)=>n+(Number(x&&x.score)||0),0);
 const progress=Math.round(countDone/bank.length*100);
 const vocab=t.vocab.map((v,i)=>`<div class="mini-card"><b>${{escA2(v[0])}}</b><small class="muted">${{escA2(v[1])}}</small><button class="secondary" data-a2t2-vocab="${{i}}">🔊 Hear word</button></div>`).join("");
 const qs=t.questions.map((q,qi)=>{{const chosen=answers[qi];return `<div class="answer" style="margin:12px 0"><b>${{qi+1}}. ${{escA2(q[0])}}</b><div class="grid" style="grid-template-columns:1fr;gap:6px;margin-top:9px">${{q[1].map((o,oi)=>`<button class="secondary" style="text-align:left;white-space:normal;${{chosen===oi?(done?(oi===q[2]?"border:2px solid #27845b":"border:2px solid #c45a55"):"border:2px solid #397b9b"):""}}" data-a2t2-answer="${{qi}}" data-a2t2-option="${{oi}}" ${{done?"disabled":""}}>${{String.fromCharCode(97+oi)}}. ${{escA2(o)}}</button>`).join("")}}</div>${{done?`<div class="answer ${{chosen===q[2]?"good":"bad"}}" style="margin-top:8px"><b>${{chosen===q[2]?"Correct":"Not quite"}}</b> — ${{escA2(q[3])}}<p class="muted" style="margin:5px 0 0"><b>Information-board evidence:</b> ${{escA2(q[4])}}</p></div>`:""}}</div>`}}).join("");
 el.innerHTML=`<div class="lab-hero"><div class="lab-kicker">DEUTSCH QUEST · A2 LESEN · GOETHE-STYLE TRAINING</div><h2>Teil 2 · Informationstafeln verstehen</h2><p>Read an information board, department directory or weekly programme. Find the detail that answers each everyday situation. Choose one answer (a, b or c) for each question.</p><div class="lab-metrics"><span>6 original information boards</span><span>5 questions each</span><span>30 questions total</span><span>${{countDone}}/6 completed</span></div><div class="progress"><i style="width:${{progress}}%"></i></div></div>
 <div class="answer"><h3>Exam format · what you must do</h3><p><b>Official Goethe A2 format:</b> Teil 2 tests whether you can understand information boards, event programmes and similar public information. You read one board and answer five three-option multiple-choice questions (a, b or c). Teil 2 is one of four parts in the 30-minute Lesen module.</p><p class="muted">These six practice sets are original materials. They follow the task type and level, not copied official exam content.</p></div>
 <div class="answer"><h3>Reading strategy · 5 steps</h3><ol><li><b>Read the situation first:</b> identify exactly what the person needs.</li><li><b>Scan headings:</b> look for floors, days, times, rooms, prices and services.</li><li><b>Match the key detail:</b> compare the need with the relevant line on the board.</li><li><b>Check conditions:</b> notice words such as <i>nur, ab, bis, täglich, geschlossen</i> and <i>mit Anmeldung</i>.</li><li><b>Eliminate distractors:</b> reject options that match the topic but not the required time, age, place or condition.</li></ol><p><b>Important:</b> choose the option supported by the board, not the one that merely sounds possible.</p></div>
 <div class="answer"><div class="row" style="justify-content:space-between;align-items:center"><h3 style="margin:0">Practice information boards</h3><span class="pill">${{countDone}}/6 completed · ${{totalCorrect}}/30 correct so far</span></div><div class="grid">${{bank.map((x,i)=>`<button class="${{i===idx?"primary":"secondary"}}" data-a2t2-set="${{i}}">${{i+1}}. ${{escA2(x.title)}} ${{run.completed["set"+i]?"✓":""}}</button>`).join("")}}</div></div>
 <div class="answer"><div class="row" style="justify-content:space-between"><span class="pill">Board ${{idx+1}} of ${{bank.length}}</span><span class="pill">${{escA2(t.topic)}}</span></div><h2>${{escA2(t.title)}}</h2><div class="notice" style="margin:10px 0"><b>Informationstafel</b> · Read the complete notice before answering.</div><p style="font-size:14px;line-height:1.85;white-space:pre-line">${{escA2(t.de)}}</p><div class="actions"><button class="secondary" id="a2t2ShowTranslation">${{run.showTranslation?"Hide English translation":"Show English translation"}}</button></div><div id="a2t2Translation">${{run.showTranslation?`<div class="answer">${{escA2(t.en)}}</div>`:""}}</div></div>
 <div class="answer"><h3>Key vocabulary</h3><div class="grid">${{vocab}}</div></div>
 <div class="answer"><h3>Comprehension · choose a, b or c</h3><p class="muted">Answer all five questions, then submit once to see explanations and the exact information-board evidence. Your first completed result is saved.</p>${{qs}}${{!done?`<button class="primary" id="a2t2Submit" ${{Object.keys(answers).length===5?"":"disabled"}}>Check all 5 answers</button>`:`<div class="answer good"><b>Board completed · ${{run.completed[key].score}}/5 correct</b><p>${{run.completed[key].score===5?"Excellent! You located all five details.":"Review the evidence and continue to the next information board. Your first score remains saved."}}</p></div>`}}<div class="actions"><button class="secondary" id="a2t2Prev" ${{idx===0?"disabled":""}}>← Previous board</button><button class="primary" id="a2t2Next" ${{idx===bank.length-1?"disabled":""}}>Next board →</button></div></div>
 <div class="answer"><h3>Self-check · what to notice</h3><ul><li>Can you find a specific floor, room or service quickly?</li><li>Can you distinguish opening hours from the hours of a return machine or service?</li><li>Can you understand age limits, registration rules and required materials?</li><li>Can you match a person's exact need rather than just the general topic?</li></ul><p class="muted">Suggested method: read the board independently first; open the translation only after answering or when reviewing.</p></div>`;
 document.querySelectorAll("[data-a2t2-set]").forEach(b=>b.onclick=()=>{{run.index=Number(b.dataset.a2t2Set);run.showTranslation=false;persist();render()}});
 document.querySelectorAll("[data-a2t2-answer]").forEach(b=>b.onclick=()=>{{if(done)return;const qi=Number(b.dataset.a2t2Answer),oi=Number(b.dataset.a2t2Option);run.answers[key]=run.answers[key]||{{}};run.answers[key][qi]=oi;persist();render()}});
 document.querySelectorAll("[data-a2t2-vocab]").forEach(b=>b.onclick=()=>speak(t.vocab[Number(b.dataset.a2t2Vocab)][0]));
 const tr=document.querySelector("#a2t2ShowTranslation");if(tr)tr.onclick=()=>{{run.showTranslation=!run.showTranslation;persist();render()}};
 const submit=document.querySelector("#a2t2Submit");if(submit)submit.onclick=()=>{{const a=run.answers[key]||{{}};if(Object.keys(a).length!==5)return;const score=t.questions.reduce((n,q,i)=>n+(Number(a[i])===q[2]?1:0),0);run.completed[key]={{score,at:new Date().toISOString()}};if(!run.awarded[key]){{state.xp=(state.xp||0)+score*5;run.awarded[key]=true;}}persist();save();render()}};
 const prev=document.querySelector("#a2t2Prev");if(prev)prev.onclick=()=>{{run.index=Math.max(0,idx-1);run.showTranslation=false;persist();render()}};
 const next=document.querySelector("#a2t2Next");if(next)next.onclick=()=>{{run.index=Math.min(bank.length-1,idx+1);run.showTranslation=false;persist();render()}};
 return;
 }}
'''
# Insert immediately before Reading branch after Teil 1
marker='\n if(state.active==="Reading"){'
assert marker in s
s=s.replace(marker,'\n '+block+marker,1)
# Add module entry
old='["Lesen A2 · Teil 1","📰","A2 newspaper texts · 30 original questions · evidence-based feedback"],'
new=old+'["Lesen A2 · Teil 2","📋","A2 information boards · programmes · 30 original questions"],'
assert old in s
s=s.replace(old,new,1)
# Add to language skills group
old2='"Reading","Lesen A2 · Teil 1","Writing"'
new2='"Reading","Lesen A2 · Teil 1","Lesen A2 · Teil 2","Writing"'
assert old2 in s
s=s.replace(old2,new2,1)
p.write_text(s)
print('Wrote',p,'size',p.stat().st_size,'block',len(block),'bank',len(bank),'questions',sum(len(x['questions']) for x in bank))
