# Deutsch Quest v305 — A1 Hören Audio Integration

## Delivered
- 24 A1 short-practice MP3 tracks
- 10 A1 Listening Intelligence passage MP3 tracks
- 15 A1 Goethe-style Mock Hören MP3 tracks
- Stable asset IDs under `audio/a1/`
- Recorded playback fixed at 1.00×

## Behaviour preserved
- Existing questions, options, answer keys and explanations are retained.
- Mock transcripts remain hidden before answer review.
- Mock replay limits remain Teil 1 = 2, Teil 2 = 1, Teil 3 = 2.
- Existing progress storage and unrelated A2/B1 audio paths are retained.

## QA boundary
All 49 MP3 files were checked for archive presence, unique ID mapping, metadata and successful decoding. Filename/transcript mapping was checked against the v304 recording manifest and app data banks. This does **not** certify every spoken word: no ASR or independent human listening transcription was available. The app sets recorded playback to 1.00×, but the original export speed cannot be inferred from MP3 metadata. Headless browser smoke testing was blocked by the execution environment; live browser/iPhone/Android acceptance remains pending.

## Files
- `index.html` — integrated app
- `audio/a1/*.mp3` — 49 recordings
- `audio-manifest.json` — A1 and retained A2 asset inventory
- `QA-REPORT-A1-HOEREN-AUDIO-INTEGRATION-v305.json`
- `A1-HOEREN-AUDIO-CORRECTION-LEDGER-v305.json`
