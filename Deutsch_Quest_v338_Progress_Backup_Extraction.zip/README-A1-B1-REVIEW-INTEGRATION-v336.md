# Deutsch Quest v336 — A1–B1 Review & Integration

## Release decision
**PASS — static/source integration QA.** Built from the v335 application package. The active B1 Review & Integration data was reopened and re-audited; the standalone companion JSON was synchronized to the active embedded object.

## Scope
- A1/A2: reconciled to the existing v310/v311 cross-skill progression and final content-freeze lineage.
- B1: six existing Review & Integration units, 18 retrieval questions, six skill links per unit, 24 integration checkpoints and five unique audio assets.
- A1–B1: master progression map added as an audit/reference artifact. No new exam bank or canonical lesson IDs were created.

## Corrections
1. Added `B1-REVIEW-INTEGRATION-PRACTICE-v336.json` as an exact mirror of the active embedded review object. The historical v303 JSON remains unchanged.
2. Updated the active embedded review object's release metadata to v336 and recorded the v335 baseline plus v326 integration lineage.

## Preservation
- No existing module or top-level menu removed/added.
- `state.dqB1Review` and legacy `reviewDates` migration preserved.
- Existing B1 unit IDs, themes, quiz items, audio, reading, speaking and writing references retained.
- Existing A1/A2 modules and learning-state data retained.

## Important scope boundary
The app has a dedicated interactive B1 Review & Integration module. A1/A2 cross-skill pathways exist in the v310/v311 lineage and their existing skill modules, but this release does **not** claim a separate interactive A1/A2 Review module.

## QA boundary
All automated checks in the report passed, including 3/3 inline JavaScript syntax checks and decoding of all five unique referenced audio assets. Physical-device/browser runtime acceptance and independent native-speaker certification remain pending.
