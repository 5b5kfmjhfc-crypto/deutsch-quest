import os,json,zipfile,hashlib,re,pathlib,shutil
root=pathlib.Path('/mnt/data/lesen_stage4'); base=root/'dq_v277_build'; out=root/'teil1'
text_de='''Hallo Miriam,

endlich habe ich eine passende Wohnung gefunden! Eigentlich wollte ich schon Anfang Oktober umziehen, aber die Renovierung in der neuen Wohnung hat länger gedauert als geplant. Jetzt bekomme ich die Schlüssel am 18. Oktober und kann am folgenden Samstag einziehen. Die Wohnung liegt zwar etwas weiter von meinem Arbeitsplatz entfernt, aber dafür ist sie ruhiger und hat einen kleinen Balkon.

Mit dem Umzug möchte ich möglichst wenig Stress haben. Deshalb habe ich eine Umzugsfirma beauftragt. Die Mitarbeiter transportieren die großen Möbel und die schweren Kartons. Meine Bücher, Kleidung und andere persönliche Sachen packe ich selbst ein, weil ich dabei gleich aussortieren möchte. Die Firma kommt am Samstag um acht Uhr morgens; ich muss also vorher alles fertig vorbereitet haben.

Du hattest angeboten, mir zu helfen. Das wäre wirklich toll! Könntest du vielleicht am Freitagabend vorbeikommen? Dann können wir gemeinsam die letzten Kartons beschriften. Am Samstag brauche ich keine zusätzliche Hilfe beim Tragen, denn dafür ist die Firma zuständig. Es wäre aber praktisch, wenn du mein Fahrrad mit deinem Auto zur neuen Wohnung bringen könntest.

Ein weiteres Problem ist der Internetanschluss. Der Anbieter hat mir einen Termin für den Dienstag nach dem Umzug bestätigt. Bis dahin kann ich im Homeoffice notfalls die mobilen Daten meines Handys benutzen. Ich hoffe allerdings, dass die Einrichtung nicht länger dauert.

Wenn alles geschafft ist, möchte ich dich natürlich einladen. Am Umzugswochenende wird es wahrscheinlich zu chaotisch. Lass uns lieber in der Woche danach zusammen kochen. Ich melde mich, sobald ich mich ein bisschen eingerichtet habe.

Liebe Grüße
Lena'''
items=[
(1,'Lena kann wie ursprünglich geplant Anfang Oktober in die neue Wohnung ziehen.','Falsch','die Renovierung in der neuen Wohnung hat länger gedauert als geplant. Jetzt bekomme ich die Schlüssel am 18. Oktober','Awalnya Lena ingin pindah pada awal Oktober, tetapi renovasi terlambat. Ia baru menerima kunci pada 18 Oktober.','The renovation took longer than planned, so she will receive the keys later, on 18 October.'),
(2,'Lena hat eine Umzugsfirma engagiert, die sowohl Möbel als auch schwere Kartons transportiert.','Richtig','Die Mitarbeiter transportieren die großen Möbel und die schweren Kartons.','Pernyataan sesuai langsung dengan tugas perusahaan pindahan: mengangkut furnitur besar dan kardus berat.','The company is hired to transport both large furniture and heavy boxes.'),
(3,'Lena möchte alle ihre persönlichen Sachen von der Umzugsfirma einpacken lassen.','Falsch','Meine Bücher, Kleidung und andere persönliche Sachen packe ich selbst ein','Lena sendiri yang akan mengemas buku, pakaian, dan barang pribadi; perusahaan hanya mengangkutnya.','She will pack her books, clothes and other personal belongings herself.'),
(4,'Miriam soll Lena am Freitagabend beim Beschriften der Kartons helfen.','Richtig','Könntest du vielleicht am Freitagabend vorbeikommen? Dann können wir gemeinsam die letzten Kartons beschriften.','Lena meminta Miriam datang Jumat malam agar mereka bisa memberi label pada kardus terakhir bersama-sama.','Lena asks Miriam to come on Friday evening so they can label the remaining boxes together.'),
(5,'Am Samstag braucht Lena Hilfe beim Tragen der Möbel, weil die Umzugsfirma dafür nicht zuständig ist.','Falsch','Am Samstag brauche ich keine zusätzliche Hilfe beim Tragen, denn dafür ist die Firma zuständig.','Justru perusahaan pindahan yang bertanggung jawab membawa barang pada Sabtu; Lena tidak membutuhkan bantuan tambahan untuk mengangkatnya.','The moving company is responsible for carrying the items, so she does not need extra help with that.'),
(6,'Lena möchte Miriam erst nach dem Umzugswochenende zu sich einladen.','Richtig','Am Umzugswochenende wird es wahrscheinlich zu chaotisch. Lass uns lieber in der Woche danach zusammen kochen.','Lena menunda undangan sampai minggu setelah pindahan karena akhir pekan pindahan diperkirakan terlalu sibuk.','She prefers to invite Miriam in the following week because moving weekend will be too chaotic.')]
part={'part':1,'title':'Korrespondenz verstehen','title_en':'Understanding correspondence','format':'Richtig/Falsch','recommended_minutes':10,'stimulus':{'id':'lesen_b1_p1_umzug_lena','genre':'persönliche E-Mail','context':'Wohnungswechsel und Organisation eines Umzugs','author':'Lena','recipient':'Miriam','text_de':text_de,'word_count':len(re.findall(r"\b[\wÄÖÜäöüß'-]+\b",text_de)),'level':'B1','original':True},'instructions_de':'Lesen Sie die E-Mail. Sind die Aussagen richtig oder falsch? Kreuzen Sie an.','instructions_en':'Read the email. Are the statements true or false? Choose the correct answer.','items':[]}
for n,prompt,ans,evid,ri,en in items: part['items'].append({'number':n,'type':'true_false','prompt_de':prompt,'options':['Richtig','Falsch'],'answer':ans,'evidence_de':evid,'rationale_id':ri,'why_en':en})
bank={'metadata':{'title':'Deutsch Quest — Goethe B1 Lesen Original Practice Set 01','version':'v286-stage4-part1','language':'de-DE','level':'B1','original_content':True,'not_official_exam':'Original practice material aligned to the public Goethe-Zertifikat B1 Lesen task structure; not an official Goethe exam or certified mock.','duration_minutes':65,'total_items_in_full_exam':30,'production_status':'PART 1 COMPLETE; PARTS 2–5 NOT YET PRODUCED','source_blueprint':'LESEN-B1-GOETHE-EXAM-BLUEPRINT-v285.json'},'parts':[part]}
key={'version':'v286-stage4-part1','title':'Lesen B1 Original Practice Set 01 — Teil 1 Answer Key','items':[{'number':x['number'],'part':1,'stimulus_id':part['stimulus']['id'],'answer':x['answer'],'evidence_de':x['evidence_de'],'rationale_id':x['rationale_id'],'why_en':x['why_en']} for x in part['items']]}
for name,obj in [('LESEN-B1-STAGE4-EXAM-BANK-PART1-v286.json',bank),('LESEN-B1-STAGE4-ANSWER-KEY-PART1-v286.json',key)]: json.dump(obj,open(out/name,'w'),ensure_ascii=False,indent=2)
print('word_count',part['stimulus']['word_count'])
# Independent structural and evidence checks
assert len(part['items'])==6
assert [x['number'] for x in part['items']]==list(range(1,7))
assert sum(x['answer']=='Richtig' for x in part['items'])==3
assert sum(x['answer']=='Falsch' for x in part['items'])==3
assert 180 <= part['stimulus']['word_count'] <= 260
for x in part['items']:
 assert x['options']==['Richtig','Falsch'] and x['answer'] in x['options']
 assert x['evidence_de'] in text_de
 assert x['rationale_id'] and x['why_en']
# Exact baseline app file is copied byte-for-byte; no app integration in this stage.
report={
 'project':'Deutsch Quest','release':'Deutsch Quest v286','base_release':'Deutsch Quest v285',
 'stage':'Lesen B1 — Stage 4, Teil 1: Korrespondenz verstehen',
 'status':'part1_content_completed_and_validated; parts2_to5_pending',
 'scope':{'part1_items':6,'total_exam_items_when_complete':30,'part1_recommended_minutes':10,'stimulus_word_count':part['stimulus']['word_count'],'answer_distribution':{'Richtig':3,'Falsch':3},'app_html_modified':False,'A1_A2_modified':False,'Reading_Workshop_modified':False,'Hoeren_B1_modified':False},
 'checks':{'item_numbering':'PASS','item_count':'PASS','response_format':'PASS','answer_balance':'PASS','evidence_spans_exact_substrings':'PASS','rationales_present':'PASS','stimulus_word_count_target':'PASS','unique_best_answer_review':'PASS_MANUAL'},
 'item_review':[
 {'number':1,'key':'Falsch','decision':'PASS','reason':'The text explicitly postpones key handover until 18 October after renovation delay.'},
 {'number':2,'key':'Richtig','decision':'PASS','reason':'The company explicitly transports large furniture and heavy boxes.'},
 {'number':3,'key':'Falsch','decision':'PASS','reason':'The writer explicitly packs personal belongings herself.'},
 {'number':4,'key':'Richtig','decision':'PASS','reason':'The request and purpose for Friday evening are explicit.'},
 {'number':5,'key':'Falsch','decision':'PASS','reason':'The text explicitly says the company is responsible for carrying items.'},
 {'number':6,'key':'Richtig','decision':'PASS','reason':'The invitation is planned for the week after moving weekend.'}],
 'limitations':['Only Teil 1 has been produced in this incremental Stage 4 delivery.','No app UI/runtime integration or browser test was performed.','This is original preparation content, not an official Goethe exam or certified mock.']}
json.dump(report,open(out/'QA-REPORT-LESEN-B1-STAGE4-TEIL1-v286.json','w'),ensure_ascii=False,indent=2)
ledger={'version':'v286','scope':'Teil 1 only','changes':[{'id':'P1-01','change':'Created original B1 personal email about planning a move.','reason':'Implements the Stage 3 correspondence stimulus specification.'},{'id':'P1-02','change':'Created six Richtig/Falsch items with a 3:3 answer balance.','reason':'Implements blueprint item count and balanced key rule.'},{'id':'P1-03','change':'Added exact evidence spans and Indonesian/English rationales for each item.','reason':'Supports answer traceability and learner feedback.'}],'not_changed':['Existing app HTML/runtime','A1/A2 content','Existing Reading Workshop','A2 Lesen mock','Hören B1 assets','Parts 2–5 exam content']}
json.dump(ledger,open(out/'LESEN-B1-STAGE4-TEIL1-CORRECTION-LEDGER-v286.json','w'),ensure_ascii=False,indent=2)
open(out/'README-LESEN-B1-STAGE4-TEIL1-ID-v286.txt','w').write('Deutsch Quest v286 — Lesen B1 Stage 4, Teil 1\n\nTeil 1 is complete: one original personal email, six Richtig/Falsch items, answer key, evidence spans and learner rationales. Parts 2–5 are intentionally pending. This is not an official Goethe exam. App integration is deferred until content production and final QA are complete.\n')
# Build a complete archive preserving all v285 files and app unchanged.
archive=root/'Deutsch_Quest_v286_Lesen_B1_Stage4_Teil1_Korrespondenz.zip'
with zipfile.ZipFile('/mnt/data/Deutsch_Quest_v285_Lesen_B1_Stage3_Goethe_Exam_Blueprint.zip') as zin:
 files={n:zin.read(n) for n in zin.namelist()}
html_before=files['dq_v277_build/index.html']
for f in out.iterdir():
 if f.is_file() and f.name!='build.py': files['dq_v277_build/'+f.name]=f.read_bytes()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as zout:
 for n,b in files.items(): zout.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('dq_v277_build/index.html')==html_before
 loaded=json.loads(z.read('dq_v277_build/LESEN-B1-STAGE4-EXAM-BANK-PART1-v286.json'))
 assert len(loaded['parts'][0]['items'])==6
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
print('ARCHIVE',archive,'bytes',archive.stat().st_size,'sha256',sha)
print('ZIP integrity PASS; HTML byte-identical PASS; records',len(files))
