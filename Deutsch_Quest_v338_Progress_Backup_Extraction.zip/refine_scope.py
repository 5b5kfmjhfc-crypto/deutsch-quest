from pathlib import Path
import json
p=Path('/mnt/data/grammar_b1_stage1/Deutsch_Quest_v274_Grammar_B1_Stage1.html')
s=p.read_text(); st=s.index('const GRAMMAR = ')+len('const GRAMMAR = ');q=None;e=False;d=0
for j in range(st,len(s)):
 c=s[j]
 if q:
  if e:e=False
  elif c=='\\':e=True
  elif c==q:q=None
 else:
  if c in '\"\'`':q=c
  elif c=='[':d+=1
  elif c==']':
   d-=1
   if d==0:end=j+1;break
arr=json.loads(s[st:end])
scopes={
'Relative clauses: nominative, accusative and dative':'B1 core',
'Konjunktiv II: polite requests, wishes and hypothetical situations':'B1 core',
'Passive voice: present, past and perfect':'B1 core',
'Infinitive clauses with zu':'B1 core',
'Subordinate clauses: weil, dass and obwohl':'B1 core',
'Adjective declension: weak, mixed and strong endings':'B1 core',
'Indirect questions':'B1 core · A2 bridge',
'Genitive: possession and relationships':'B1 core',
'Cautious statements and expressions of uncertainty':'B1 extension',
'Präteritum: common verbs and modal verbs':'B1 core · A2 bridge',
'Plusquamperfekt: the earlier past':'B1 extension',
'Futur I: predictions, plans and assumptions':'B1 extension · A2 bridge',
'Temporal subordinate clauses':'B1 core · A2 bridge',
'Purpose clauses: damit and um ... zu':'B1 core · A2 bridge',
'Infinitive clauses with ohne ... zu and (an)statt ... zu':'B1 extension',
'Two-part conjunctions':'B1 extension · A2 bridge',
'Main-clause connectors and sentence adverbs':'B1 core · A2 bridge',
'Verbs with prepositions and da-/wo-compounds':'B1 core',
'Reflexive verbs with prepositions':'B1 extension',
'Passive voice with modal verbs':'B1 extension',
'Genitive prepositions':'B1 extension',
'N-declension: masculine nouns':'B1 extension',
'lassen + infinitive':'B1 extension',
'Relative clauses with prepositions and genitive forms':'B1 extension',
'Konjunktiv II in the past':'B1 extension',
'Je ... desto: proportional comparison':'B1 extension',
'Word order in complex sentences':'B1 core'
}
for x in arr:
 if x.get('level')!='B1':continue
 x['scope']=scopes[x['title']]
 if x['title']=='Infinitive clauses with zu':
  x['title']='Infinitive clauses: extended zu-patterns'
  x['rule']='Building on the basic A2 zu-infinitive pattern, B1 learners extend it to verbs, nouns and adjectives that govern an infinitive clause, and to purpose expressions. The infinitive is placed at the end; with separable verbs, zu appears between prefix and stem.'
  x['content']='A2 foundation: Ich habe vor, Deutsch zu lernen. · B1 extension: Es ist wichtig, regelmäßig zu üben. · Sie versucht, pünktlich anzukommen. · Modal verbs normally take a bare infinitive without zu.'
  x['tip']='This lesson extends rather than repeats the A2 introduction. Check whether the governing expression requires zu; do not add zu after an ordinary modal verb.'
 if x['title']=='Indirect questions':
  x['title']='Indirect questions: complex and formal contexts'
  x['rule']='Building on the A2 ob- and W-question patterns, B1 uses indirect questions in longer and more formal requests. The embedded clause remains subordinate, with the finite verb at the end.'
  x['content']='Könnten Sie mir sagen, wann der Zug abfährt? · Ich möchte wissen, ob die Unterlagen vollständig sind. · Wissen Sie, wo man sich anmelden kann?'
  x['tip']='The question word or ob introduces the embedded clause; do not invert subject and verb inside it. The main clause may be a polite question.'
 if x['title']=='Präteritum: common verbs and modal verbs':
  x['title']='Präteritum: expanding past narration'
  x['rule']='Building on the A2 forms of sein, haben and modal verbs, B1 extends Präteritum to frequent regular and strong verbs, especially in written narratives and reports.'
  x['content']='sein: war · haben: hatte · können: konnte · müssen: musste · machen: machte · gehen: ging · kommen: kam. Regular verbs form Präteritum with -te; strong verbs often change their stem.'
  x['tip']='A2 already introduces war, hatte and modal Präteritum. This lesson extends the system to common regular and strong verbs; learn frequent forms individually.'
 if x['title']=='Futur I: predictions, plans and assumptions':
  x['title']='Futur I: predictions and assumptions'
  x['rule']='Building on the A2 future expression with werden, B1 focuses on predictions and assumptions. Futur I is werden (conjugated) + infinitive at the end; present tense with a time expression remains common for fixed plans.'
  x['content']='ich werde lernen · du wirst arbeiten · Er wird schon zu Hause sein. Futur I can express a prediction or an assumption about the present/future.'
  x['example']='Morgen wird es wahrscheinlich regnen. / Er wird jetzt im Zug sein.'
  x['tip']='Do not use Futur I automatically for every future meaning. A planned event is often expressed with Präsens + a time phrase.'
 if x['title']=='Two-part conjunctions':
  x['title']='Extended two-part conjunctions'
  x['rule']='Building on A2 entweder ... oder and weder ... noch, B1 expands the range of correlative conjunctions. The paired elements should be grammatically parallel.'
  x['content']='A2 bridge: entweder ... oder · weder ... noch. B1 extension: sowohl ... als auch · nicht nur ... sondern auch · zwar ... aber.'
  x['tip']='Keep the paired elements parallel. Check whether the second element begins a new clause and apply its normal word-order rule.'
# Replace array and metadata scope counts
new=json.dumps(arr,ensure_ascii=False,indent=2)
s=s[:st]+new+s[end:]
# Metadata comes after array; replace old count strings in its object safely
s=s.replace('"b1_new_topics_added": 18,','"b1_new_topics_added": 18,\n  "b1_core_lessons": 14,\n  "b1_extension_lessons": 13,')
p.write_text(s)
# Update report
rp=Path('/mnt/data/grammar_b1_stage1/QA-REPORT-GRAMMAR-B1-STAGE1-v274.json');r=json.loads(rp.read_text())
# Re-extract B1 list
b=[x for x in arr if x.get('level')=='B1']
r['b1_final_titles']=[x['title'] for x in b]
r['final_inventory']['B1_core_progression']=sum('B1 core' in x.get('scope','') for x in b)
r['final_inventory']['B1_extensions']=sum('B1 extension' in x.get('scope','') for x in b)
r['scope_and_limits'].append('B1 core and extension labels are editorial prioritisation. Several B1 lessons deliberately build on A2 foundations rather than introducing the same structure as a new rule.')
rp.write_text(json.dumps(r,ensure_ascii=False,indent=2))
print('scoped',len(b),'core',r['final_inventory']['B1_core_progression'],'extension',r['final_inventory']['B1_extensions'])
