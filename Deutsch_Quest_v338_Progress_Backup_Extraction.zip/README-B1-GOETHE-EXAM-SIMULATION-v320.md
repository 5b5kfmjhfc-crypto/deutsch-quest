# Deutsch Quest — Goethe B1 Exam Simulation v320

## Purpose
v320 continues the existing Deutsch Quest application from the uploaded v319 archive. It audits, corrects and re-audits the four Goethe-Zertifikat B1 practice modules in the current app. The legacy app remains the baseline; Clean Rebuild is not started.

## Four separate modules
| Module | Official model structure | Deutsch Quest practice material |
|---|---|---|
| Lesen | 65 minutes · 5 parts · 30 items | One original 30-item mock set |
| Hören | approx. 40 minutes · 4 parts · 30 items | One original 30-item mock set · 8 MP3 files |
| Schreiben | 60 minutes · 3 tasks | 3 original mock sets × 3 tasks |
| Sprechen | approx. 15 minutes as a pair exam · 15 minutes preparation | 3 original mock sets × 3 parts · two Teil 2 topic choices |

The three written modules take approximately 165 minutes without breaks. The recommended order is Lesen → Hören → Schreiben, with at least 15 minutes between written modules. Speaking is normally a pair examination; the modules can also be taken individually.

Each module is assessed separately. The pass threshold is 60/100 for each module; there is no combined 400-point pass score.

## What v320 corrected and added
- Added a cross-skill **Goethe B1 Exam Simulation** dashboard in Test & track with direct links to all four timed module simulations.
- Lesen Teil 3 now enforces the official one-use rule for advertisements A–J. The no-match option `0` remains available.
- Lesen now displays the published 30-to-100 score conversion and the 60/100 threshold; 18/30 raw points convert to 60/100.
- Lesen Part 2 stimulus headings now use the actual `title_de` field.
- Lesen part tabs allow direct navigation between the five parts.
- Hören Teil 4 speaker-attribution options now display their speaker labels rather than object placeholders; answer review uses the same label mapping.
- Hören now blocks navigation away during an unfinished timed attempt and pauses current audio when changing parts.
- Hören result history now stores the converted reference score and threshold status.
- Schreiben's embedded app data now contains the same `word_count_policy` as its standalone source. The candidate UI clarifies that the reference count excludes greetings, sign-offs and sender names.
- Schreiben now displays the saved candidate responses and practice rubric after submission. It does not reveal model answers or automatically assign an official score.
- Lesen/Hören result screens return to the new cross-module exam dashboard.

## Source and assessment boundaries
All practice texts, questions, audio scripts and prompts are original Deutsch Quest material. They are aligned to the public Goethe B1 model structure, but they are not official Goethe exam papers and do not produce a certificate.

Reading and Listening use the published Goethe raw-to-result conversion as a reference. Writing and Speaking require human judgement; the in-app rubrics and score entry are learning aids and do not replace the complete official examiner descriptors or the official two-assessor procedure.

## MP3 status
No new recording is required for this stage. All 8 existing B1 Hören MP3 files are present and passed an `ffprobe` media probe. The app enforces the task replay pattern: Teil 1 twice, Teil 2 once, Teil 3 once and Teil 4 twice. The recordings use MP3, 24 kHz, mono, 48 kbps.

## Re-audit result
- 61/61 static and pure-function QA checks passed.
- All 3 inline JavaScript blocks passed `node --check`.
- All 205 JSON files in the extracted package parsed successfully.
- Reading and Listening each have 30 sequential items and answer keys matching all 30 answers.
- Listening evidence matches the transcript exactly for all 30 items.
- All 8 B1 Hören MP3 files are present and decodable.

## Remaining acceptance tests
A live browser run, actual localStorage persistence, iPhone Safari and Android Chrome layout/audio acceptance were not performed in this environment. Writing/Speaking performance and pronunciation still require a competent human reviewer; there is no automatic certified assessment or microphone-based pronunciation score. The speaking mock is a pair format and requires a practice partner; the app does not supply a live conversation partner.
