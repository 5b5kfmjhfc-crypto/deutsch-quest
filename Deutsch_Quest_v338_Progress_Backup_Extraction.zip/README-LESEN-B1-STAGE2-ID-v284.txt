DEUTSCH QUEST v284 — LESEN B1 STAGE 2
Linguistic & Pedagogical Deep QA

Three existing B1 reading passages were reviewed. The German passages and vocabulary lists were retained.
Grammar explanations were corrected and all nine comprehension questions were revised to include
paraphrase, interpretation and evidence-based inference. A1/A2 content and the A2 Lesen mock were
preserved. See QA-REPORT-LESEN-B1-STAGE2-LINGUISTIC-PEDAGOGICAL-DEEP-QA-v284.json.
