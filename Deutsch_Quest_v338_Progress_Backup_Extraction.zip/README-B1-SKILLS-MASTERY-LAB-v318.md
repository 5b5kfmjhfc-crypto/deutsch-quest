# Deutsch Quest B1 Skills Mastery Lab — v318

## Release status
**Integration: PASS. Targeted static QA: 30/30 PASS. JavaScript syntax: 3/3 PASS. Device acceptance: pending.**

This release is built from the exact v317 archive. The existing Hören, Sprechen, Schreiben, B1 Review, Vocabulary, Grammar, Lesen and A1/A2 content has been preserved. The new lab is an additional navigation module; it does not replace or rewrite the timed Goethe-style mock exams.

## New module: B1 Skills Mastery Lab

### 1. Hören Mastery & Error Analysis
- Uses all 30 existing B1 Hören questions and all 8 existing MP3 recordings.
- Listen first, answer, then inspect the exact transcript evidence and explanation.
- Transcript and English translation remain hidden until the learner opens them.
- Error categories include keyword traps, negation/contrast, time/number, cause/result, speaker position, partial match and missed detail.
- The timed exam simulation retains its original task-specific replay limits. The mastery lab is explicitly an untimed learning mode with replay available for focused practice.
- Wrong answers are logged only when the learner chooses “Save to error log”.

### 2. Sprechen Interactive Practice
- Selects from all 9 guided and 9 independent B1 tasks.
- Guided tasks include 19 curated partner-response branches.
- Learner speaks aloud first, then records brief notes/reflection in the app.
- Suggested response is hidden until the learner has attempted a response.
- Includes task success criteria and a 1–4 learner self-rating.
- Partner turns are pre-authored branches, not a live AI interlocutor. The app does not record microphone audio, transcribe speech or score pronunciation automatically.

### 3. Schreiben Correction & Improvement Lab
- Uses all 9 guided writing tasks from the existing source.
- Shows recipient, situation, register and required content points.
- Provides a live word count, draft saving, content-point checklist and self-review.
- The model answer is revealed only after the learner saves a draft.
- Includes a sentence-level correction log for original sentence, correction, reason and category.
- Existing 9 independent tasks and 3 full mock sets are preserved and remain available in their original modules.

### 4. B1 Exam Readiness Tracker
- Saves practice attempts and learner-classified errors in the app's existing local state on the current device.
- Tracks attempts and error counts by skill.
- Schedules error retrieval for days 1, 3, 7, 14 and 30.
- An error can be marked mastered only after two successful retrievals on separate dates, and the review date is enforced.
- This is a self-reported formative tracker, not a Goethe score or CEFR certification. No cloud sync is claimed.

## Cross-skill routine
Listen for meaning and evidence → respond to a partner and justify ideas → write a coherent response → record and revisit errors.

## Audit and preservation
- Exact v317 source archive reopened and integrity checked before editing.
- Hören: 30 unique sequential items; answer key and transcript evidence checked; 8 audio IDs match the manifest; all 8 MP3s decode and retain 24 kHz mono format.
- Sprechen: all 9 guided and 9 independent tasks checked; 19 guided interaction branches verified; all 3 mock sets retained.
- Schreiben: all 9 guided and 9 independent tasks checked; all 3 mock sets with 3 tasks each retained.
- New route, navigation entry, state persistence, error classification, delayed model reveal and spaced-review logic checked.
- 30/30 targeted static checks passed; 3/3 inline JavaScript blocks pass `node --check`.

## Boundaries
- The learning tasks are original Deutsch Quest materials; they are not official Goethe examination questions.
- Speaking and writing self-review are formative. Formal scoring requires competent human judgement.
- Browser/device acceptance is still required, especially iPhone Safari and Android Chrome.
