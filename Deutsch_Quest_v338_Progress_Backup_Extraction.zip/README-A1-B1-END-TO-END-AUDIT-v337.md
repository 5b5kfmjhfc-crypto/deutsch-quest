# Deutsch Quest v337 — Final End-to-End Audit A1–B1

## Release decision
**PASS — static source, structural, syntax and bundled-audio QA.** One confirmed PWA cache-version issue was corrected and re-audited.

## Correction
The service worker still used `shell-v331` and a v331 header in the v336 package. It was updated to `shell-v337`. The existing activation handler removes older `deutsch-quest-*` shell caches. No curriculum bank, lesson, task ID, progress key, or menu was changed.

## Re-audit
- 27/27 checks passed.
- 193 JSON files parsed with zero errors.
- 3/3 inline JavaScript blocks passed `node --check`.
- Service worker passed `node --check`.
- 93/93 bundled audio assets decoded with ffprobe.
- PWA manifest and 192/512 icons verified.
- Six-menu navigation preserved.
- B1 Review & Integration: six units, 18 retrieval questions, 24 checkpoints, 1/3/7/14/30-day retention schedule.
- ZIP integrity passed.

## Runtime and device boundaries
Chromium navigation was attempted but blocked by the execution environment (`ERR_BLOCKED_BY_ADMINISTRATOR`). Consequently this release does **not** claim browser interaction, real localStorage persistence, offline installation, or physical iPhone Safari/Android Chrome acceptance. Independent native-speaker review is also pending.

## Preservation
No curriculum banks rewritten; no progress keys renamed; no modules removed; no top-level menus added. Only existing source file modified: `sw.js`.
