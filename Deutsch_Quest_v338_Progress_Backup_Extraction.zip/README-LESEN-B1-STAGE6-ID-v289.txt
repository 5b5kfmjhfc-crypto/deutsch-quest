Deutsch Quest v289 — Final Stage: Lesen B1 Integration

Modul baru: Goethe B1 Lesen Exam
- 5 Teil, 30 soal, 65 menit.
- Terintegrasi ke menu Test & track.
- Timer berbasis deadline, auto-submit ketika waktu habis.
- Jawaban dan progres bagian disimpan pada localStorage agar dapat dilanjutkan setelah reload.
- Navigasi antarbagian dan pencegahan keluar dari ujian ketika attempt aktif.
- Jawaban, bukti tekstual, dan pembahasan bilingual baru tampil setelah submit.
- Skor mentah 30 poin dan riwayat maksimal 20 attempt.

Validasi statis JavaScript dan struktur data lulus. Pengujian interaksi browser nyata pada iPhone/Safari dan desktop belum dapat dilakukan dalam lingkungan ini; lihat QA report.
Materi ini merupakan latihan orisinal selaras format Goethe B1, bukan ujian resmi atau sertifikasi Goethe.
