from pathlib import Path
import re,json
p=Path('/mnt/data/grammar_b1_stage1/Deutsch_Quest_v274_Grammar_B1_Stage1.html')
s=p.read_text()
# Inject specific practice hints into every B1 lesson object (within the serialized GRAMMAR array).
start=s.index('const GRAMMAR = ')+len('const GRAMMAR = ')
q=None;esc=False;d=0
for j in range(start,len(s)):
 c=s[j]
 if q:
  if esc:esc=False
  elif c=='\\':esc=True
  elif c==q:q=None
 else:
  if c in '\"\'`':q=c
  elif c=='[':d+=1
  elif c==']':
   d-=1
   if d==0:end=j+1;break
arr=json.loads(s[start:end])
hints={
'Relative clauses: nominative, accusative and dative':'Combine two short sentences using a relative pronoun. Identify gender/number from the noun and case from the relative clause.',
'Konjunktiv II: polite requests, wishes and hypothetical situations':'Write one polite request, one wish and one unreal present situation using Konjunktiv II.',
'Passive voice: present, past and perfect':'Rewrite one active sentence in Präsens, Präteritum and Perfekt passive.',
'Infinitive clauses with zu':'Complete three sentences with zu + infinitive, including one separable verb.',
'Subordinate clauses: weil, dass and obwohl':'Write one sentence with each conjunction and place the finite verb correctly.',
'Adjective declension: weak, mixed and strong endings':'Build three noun phrases: one with a definite article, one with ein-word and one without an article; use different cases.',
'Indirect questions':'Turn one W-question and one yes/no question into indirect questions.',
'Genitive: possession and relationships':'Describe ownership using one masculine, one neuter and one feminine genitive noun phrase.',
'Cautious statements and expressions of uncertainty':'Give a cautious answer using soweit ich weiß or soweit ich mich erinnere.',
'Präteritum: common verbs and modal verbs':'Report a past experience using war, hatte and one modal verb in Präteritum.',
'Plusquamperfekt: the earlier past':'Write two past events and show which one happened first using Plusquamperfekt.',
'Futur I: predictions, plans and assumptions':'Make one prediction and one intention with werden + infinitive; compare with a present-tense plan.',
'Temporal subordinate clauses':'Connect two actions with bevor, nachdem or während; use als or wenn for a past event.',
'Purpose clauses: damit and um ... zu':'Write one purpose clause with the same subject and one with different subjects.',
'Infinitive clauses with ohne ... zu and (an)statt ... zu':'Write one sentence with ohne ... zu and one with (an)statt ... zu.',
'Two-part conjunctions':'Connect parallel ideas using sowohl ... als auch and nicht nur ... sondern auch.',
'Main-clause connectors and sentence adverbs':'Connect two main clauses with deshalb and trotzdem; check verb-second order.',
'Verbs with prepositions and da-/wo-compounds':'Write a question with wo(r)- and answer with da(r)- using a verb-preposition pattern.',
'Reflexive verbs with prepositions':'Write two sentences using reflexive pronouns and the correct preposition + case.',
'Passive voice with modal verbs':'Transform an instruction into a passive sentence with a modal verb.',
'Genitive prepositions':'Write one sentence each with wegen, trotz and während + genitive.',
'N-declension: masculine nouns':'Decline Student or Kollege in nominative, accusative, dative and genitive.',
'lassen + infinitive':'Write one sentence meaning “have something done” and one meaning “let/allow”.',
'Relative clauses with prepositions and genitive forms':'Join two sentences using a preposition + relative pronoun and another using dessen or deren.',
'Konjunktiv II in the past':'Describe an unreal past situation using wenn + wäre/hätte + Partizip II.',
'Je ... desto: proportional comparison':'Make a comparison with je ... desto using comparative forms in both clauses.',
'Word order in complex sentences':'Write one sentence containing a main clause and two subordinate clauses; check each verb position.'
}
for x in arr:
 if x.get('level')=='B1': x['practiceHint']=hints[x['title']]
new=json.dumps(arr,ensure_ascii=False,indent=2)
s=s[:start]+new+s[end:]
# Add B1 status panel in the grammar workspace, before the generic lesson count card.
needle='</div>`:""}<div class="answer"><b>${lessons.length} ${grammarLevel} lessons</b>'
insert='</div>`:""}${grammarLevel==="B1"?`<div class="answer"><b>B1 Grammar · Stage 1 curriculum map</b><div class="lab-metrics"><span>27 consolidated topics</span><span>18 newly covered gaps</span><span>9 core lessons consolidated</span><span>0 explicitly B1-tagged practice questions</span></div><p>This is a CEFR-aligned learning curriculum, not an official exhaustive Goethe grammar list. The lesson inventory and scope have been expanded; detailed linguistic review and B1 exercise development are the next stages.</p><p class="notice">B1 practice is intentionally not mixed with the 135 unclassified legacy questions. Those items must be individually classified and checked before they can be presented as B1 practice.</p></div>`:""}<div class="answer"><b>${lessons.length} ${grammarLevel} lessons</b>'
if needle not in s: print('needle status not found')
else:s=s.replace(needle,insert,1)
# Prevent B1 lesson cards from linking to unclassified mixed practice.
old='${hasFocusedPractice?`<button class="secondary" data-lesson-practice="${esc(g.title)}">Practice this lesson · ${LESSON_PRACTICE.filter(item=>item.title===g.title).length} questions</button>`:`<button class="secondary" data-lesson-general-practice="${g.level}">Use ${g.level} general practice</button>`}'
newfrag='${hasFocusedPractice?`<button class="secondary" data-lesson-practice="${esc(g.title)}">Practice this lesson · ${LESSON_PRACTICE.filter(item=>item.title===g.title).length} questions</button>`:g.level==="B1"?`<button class="secondary" disabled>Dedicated B1 practice · Stage 2</button>`:`<button class="secondary" data-lesson-general-practice="${g.level}">Use ${g.level} general practice</button>`}'
if old not in s: print('lesson practice fragment not found')
else:s=s.replace(old,newfrag,1)
# Replace B1 practice set with explicit B1-only pool and disable entry while empty.
s=s.replace('const practiceSet=grammarLevel==="A1"?GRAMMAR_PRACTICE.filter(q=>q.level==="A1"):grammarLevel==="A2"?GRAMMAR_PRACTICE.filter(q=>q.level==="A2"):GRAMMAR_PRACTICE.filter(q=>q.level==="B1"||!q.level);','const practiceSet=grammarLevel==="A1"?GRAMMAR_PRACTICE.filter(q=>q.level==="A1"):grammarLevel==="A2"?GRAMMAR_PRACTICE.filter(q=>q.level==="A2"):GRAMMAR_PRACTICE.filter(q=>q.level==="B1");')
# B1 footer and button state.
s=s.replace('${grammarLevel==="A1"?Math.min(15,GRAMMAR_PRACTICE.filter(q=>q.level==="A1").length):12} questions','${grammarLevel==="A1"?Math.min(15,GRAMMAR_PRACTICE.filter(q=>q.level==="A1").length):grammarLevel==="A2"?12:GRAMMAR_PRACTICE.filter(q=>q.level==="B1").length} questions')
s=s.replace('${grammarLevel==="A1"?"Practise a broad mix of A1 foundations with level-tagged questions and instant explanations.":"Review 12 mixed A2 questions: three from each of the four learning domains, with instant explanations."}','${grammarLevel==="A1"?"Practise a broad mix of A1 foundations with level-tagged questions and instant explanations.":grammarLevel==="A2"?"Review 12 mixed A2 questions: three from each of the four learning domains, with instant explanations.":"B1-specific practice will be released after each question has been classified and audited."}')
s=s.replace('<button id="startgrammar" style="width:100%;margin-top:8px">Start ${grammarLevel} grammar practice</button>','<button id="startgrammar" style="width:100%;margin-top:8px" ${grammarLevel==="B1"&&GRAMMAR_PRACTICE.filter(q=>q.level==="B1").length===0?"disabled":""}>${grammarLevel==="B1"&&GRAMMAR_PRACTICE.filter(q=>q.level==="B1").length===0?"B1 practice coming in Stage 2":"Start "+grammarLevel+" grammar practice"}</button>')
p.write_text(s,encoding='utf-8')
print('patched',p.stat().st_size,'B1 hints',len(hints))
