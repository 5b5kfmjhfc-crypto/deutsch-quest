# Deutsch Quest v312 — B1 Vocabulary, Grammar & Lesen Final Re-audit

## Status

**PASS** — one editorial metadata mismatch corrected and re-audited.

## Scope

- B1 Vocabulary: 304 nouns, 86 verbs, 61 adjectives, 36 adverbs/function words, 13 prepositions, 219 phrases and 15 word-family groups (734 total records including families).
- B1 Grammar: 27 lessons (14 core/core-bridge; 13 extension/extension-bridge) and 81 focused practice questions, plus the 27-topic mixed mastery check.
- B1 Lesen: original five-part, 30-item practice exam, 65 minutes.

## Correction

The Goethe word-group heading **Bildung: Schulnoten** had a note mistakenly describing countries, nationalities and language names. The note now correctly describes school grades and regional grading-scale variation. No lexical records, grammar lessons, exam items, answer keys, or saved-progress keys were changed.

## QA boundaries

The 14 Goethe B1 word-group headings are mapped, but the app does not claim to reproduce or individually verify all approximately 2,400 official lexical units. The grammar curriculum is CEFR-aligned editorial content, not an official exhaustive Goethe grammar syllabus. Lesen tasks are original practice material aligned with the public Goethe B1 format, not official exam content or a certified score. Physical-device acceptance remains separate and has not been performed in this re-audit.

See `qa/QA-REPORT-B1-VOCAB-GRAMMAR-LESEN-FINAL-REAUDIT-v312.json` and `qa/B1-VOCAB-GRAMMAR-LESEN-CORRECTION-LEDGER-v312.json` for full details.
