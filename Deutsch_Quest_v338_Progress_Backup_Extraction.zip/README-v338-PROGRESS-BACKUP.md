# Deutsch Quest v338 — Progress Backup Extraction

## Purpose
Provide a safe, read-only export path for each independent iOS storage environment (Safari and Home Screen web app) before progress reconciliation.

## Changes from v337
- Added `backup.html`, a same-origin localStorage export page.
- Added a fixed `Progress Backup` entry point in the existing app UI; no top-level menu added.
- Updated service worker cache version to `shell-v338`.
- Added backup page to shell precache and separated backup navigation caching from `index.html` caching.

## Backup behavior
- Reads all localStorage keys and raw values for the current origin/context.
- Exports JSON with schema version, timestamp, user-supplied label, environment metadata, and full key/value entries.
- Does not upload data to a server.
- Does not overwrite, merge, or delete app data.
- Temporarily tests localStorage availability using a disposable probe key, then removes it.

## QA performed
- Backup page JavaScript syntax: PASS.
- Main app backup entry point presence: PASS.
- Service worker JavaScript syntax: PASS.
- ZIP integrity: PASS.
- Cache routing correction: backup page cached separately; main app cache is not overwritten by backup navigation.

## Not yet performed / limitations
- No user device backup has been collected yet.
- No progress merge has been run.
- No Safari/Home Screen runtime acceptance test has been performed on v338.
- This is an extraction release, not live synchronization and not yet a merge/import release.

## Next step
Deploy v338, create one backup labelled `Safari` from Safari and another labelled `Home Screen` from the installed app context, then provide both JSON files for offline inspection and a conflict-aware merge plan.
