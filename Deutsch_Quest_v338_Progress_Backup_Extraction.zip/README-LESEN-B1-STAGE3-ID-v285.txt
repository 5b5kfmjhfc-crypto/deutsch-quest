DEUTSCH QUEST v285 — LESEN B1 STAGE 3
Goethe Exam Blueprint & Task Specification

BASELINE: v284 (Stage 2 Linguistic & Pedagogical Deep QA)
SCOPE: Blueprint only. No exam passages/questions created and no app runtime changes.

OFFICIAL ADULT FORMAT
- 65 minutes total; 5 parts; 30 items.
- Teil 1: correspondence, Richtig/Falsch, 6 items, recommended 10 min.
- Teil 2: two informational/argumentative texts, 3-option MC, 6 items, recommended 20 min.
- Teil 3: 7 situations matched to advertisements/notices; 7 items, recommended 10 min; one no-match outcome.
- Teil 4: 7 opinions/positions, Ja/Nein, recommended 15 min.
- Teil 5: written instructions/rules, 3-option MC, 4 items, recommended 10 min.

IMPORTANT
The text-length ranges in the JSON blueprint are internal Deutsch Quest production targets, not official Goethe specifications. Per-part times are orientation values; total time is 65 minutes and candidates may choose their task order.

FILES
- LESEN-B1-GOETHE-EXAM-BLUEPRINT-v285.json: detailed production specification.
- QA-REPORT-LESEN-B1-STAGE3-GOETHE-EXAM-BLUEPRINT-v285.json: validation report.

NEXT: Stage 4 — create original exam texts, 30 items, answer key, evidence and rationales, then conduct item-level linguistic and psychometric-style review.

OFFICIAL SOURCES
https://bfu.goethe.de/b1_mod/lesen.php
https://www.goethe.de/pro/relaunch/prf/materialien/B1/b1_modellsatz_erwachsene.pdf
https://www.goethe.de/resources/files/pdf124/b1_modellsatz_erwachsene_11_web311111811111111.pdf
https://www.goethe.de/resources/files/pdf136/tipps_und_tricks_prfungsvorbereitung_goethe-zertifikat_b1_lesen2.pdf
