# Deutsch Quest B1 — Official Goethe Vocabulary Crosswalk Stage 1 · v322

## Release result
**PASS_WITH_EXPLICIT_OFFICIAL_CROSSWALK_LIMITATION**

This stage reconciles the full existing B1 vocabulary bank against the documented item-level audit registry and makes the status distinctions visible in the application. It does not claim that all 734 records are official Goethe entries or that the approximately 2,400-unit Wortliste has been exhaustively reproduced.

## Source
Goethe-Zertifikat B1 Wortliste, Goethe-Institut / ÖSD / Universität Freiburg, 2016, 1st edition: https://www.goethe.de/pro/relaunch/prf/id/Goethe-Zertifikat_B1_Wortliste.pdf
The Goethe-Institut Indonesia practice-material page continues to link the official B1 vocabulary list: https://www.goethe.de/ins/id/id/sta/jak/prf/gzb1/ueb.html

## Reconciled inventory
- 719 lexical learning-bank records
- 15 word-family groups with 62 member links
- 734 total records as shipped
- 56 documented exact-item or official word-group confirmations: 48 nouns, 4 verbs, 4 adjectives
- 615 topic-aligned/supplementary or pending exact confirmation
- 43 explicitly labelled vocational bakery supplements
- 5 entries not found in selected exact-string searches; this is not proof of absence

### Count reconciliation
The 48 confirmed noun records consist of 47 standalone exact headwords plus one record represented by the official combined word-group form **die (Fach-)Hochschule**. This resolves the earlier 47 + 1 split without adding an extra noun.

The earlier note that 59/86 verbs were located in selected searches is not equivalent to 59 item-level exact confirmations. Search hits and related/reflexive forms are not promoted to exact status without normalized item-level evidence; the Stage 3 item-level registry confirms 4 exact verb records.

## Method
1. Preserve all existing learning content.
2. Use explicit exact confirmation only where documented in the prior item-level registry.
3. Keep search misses distinct from confirmed absence.
4. Keep vocational bakery vocabulary visibly supplementary.
5. Do not treat a phrase, case pattern or word-family group as an official entry solely because a component word occurs in the official list.

## Application changes
- Added `B1-GOETHE-CROSSWALK-STAGE1-v322.json` with per-record status for all 719 lexical records and member-level cross-references for all 15 word-family groups.
- Added a compact `B1_GOETHE_CROSSWALK_V322` metadata constant in `app/inline-0.js`.
- Updated the B1 Vocabulary Coverage panel to show reconciled counts and limitations.
- No vocabulary or grammar learning record was deleted or rewritten.

## QA
See `QA-REPORT-B1-GOETHE-CROSSWALK-STAGE1-v322.json` and `B1-GOETHE-CROSSWALK-STAGE1-CORRECTION-LEDGER-v322.json`.

## Limits
This is a complete **status inventory**, not a complete reproduction or exhaustive exact match of every unit in the official list. Physical iPhone Safari / Android Chrome testing and independent native-speaker certification have not been performed.
