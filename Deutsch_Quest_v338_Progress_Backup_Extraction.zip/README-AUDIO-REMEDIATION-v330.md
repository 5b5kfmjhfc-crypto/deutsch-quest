# Deutsch Quest v331 — Stage 1D.2 Targeted Audio Remediation

## Baseline
Authoritative v330 `index.html` and `sw.js` from `Deutsch_Quest_v330_Native_Audio_Remediation.zip`. v330 remains unchanged.

## Corrections
- Status helper chooses a visible matching status node when legacy duplicate IDs exist.
- Audio URL normalization catches malformed percent-encoding.
- A1/B1 native players provide buffering, stalled, playing, ended and media-error feedback.
- A1/B1 replay counters count one playback session and do not count pause/resume as another play.
- Vocabulary voice refresh now retries bounded voice enumeration instead of sampling only once.\n- Independent Speaking recorder prevents overlapping microphone permission requests, handles navigation during permission resolution, stops tracks on failure, and rejects empty recordings.
- Service worker shell cache namespace bumped to v331.

## Static re-audit
- 3/3 inline JavaScript blocks pass `node --check`.
- Service worker passes `node --check`.
- ZIP integrity test passes.
- No old `currentTime < 0.25` replay heuristic remains in A1/B1 exam listeners.

## Known limitations
- Native controls permit seeking; session counting is not tamper-proof for partial replay within an already counted session.
- A1 mock counter is in-memory and resets on navigation/reload.
- Legacy `dqB1ExamPlay` remains as a dormant compatibility function.
- Physical Android Chrome and iPhone Safari retests are still required. Stage 1D.1 runtime evidence does not replace v331 retest.

## Release status
Static code correction and re-audit passed. Device acceptance is pending; do not mark full audio compatibility acceptance complete until physical retests pass.
