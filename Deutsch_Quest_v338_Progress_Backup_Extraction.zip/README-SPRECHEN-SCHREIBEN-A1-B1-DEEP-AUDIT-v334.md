# Deutsch Quest v334 — Sprechen & Schreiben A1–B1 Deep Audit

Baseline: v333 (Hören & Lesen A1–B1).

## Scope
Sprechen and Schreiben content at A1, A2 and B1, including A1 Writing & Speaking Mastery, B1 toolkits, guided/independent tasks, mock sets, task-to-model/rubric alignment, word-count targets, timing, point totals, references, source syntax and preservation.

## Corrections
1. A1 Schreiben: corrected the rubric for “Einen Termin verschieben” so it matches the prompt and model; no unsupported requirement to state a reason remains.
2. A1 Writing & Speaking Mastery: clarified that invitation replies must include a short reason and added one to the model.
3. A1 Writing & Speaking Mastery: corrected the directions sample so it answers “Ist es weit?”.

## Audit boundary
The report distinguishes source-level checks from independent native-speaker review and physical-device acceptance. A2 stage content is retained from its prior finalization reports and checked for inventory/integration in the v333 source; this pass does not claim an independent rewrite of every A2 task.

See `QA-REPORT-SPRECHEN-SCHREIBEN-A1-B1-DEEP-AUDIT-v334.json` and `SPRECHEN-SCHREIBEN-A1-B1-CORRECTION-LEDGER-v334.json`.
