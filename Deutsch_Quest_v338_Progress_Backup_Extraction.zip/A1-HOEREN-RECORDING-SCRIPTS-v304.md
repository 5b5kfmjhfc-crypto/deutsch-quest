# A1 Hören — Audio Recording Scripts v304

**Total: 49 unique tracks** (24 short practice + 10 Listening Intelligence + 15 mock-exam tasks).

## Recording standard
- Language: German (de-DE), Standarddeutsch / Hochdeutsch.
- Use clear, natural neural German voices at a moderate A1-friendly pace.
- Do not translate, paraphrase, add filler, omit details, or alter numbers/times.
- Distinguish speakers naturally in dialogues; public announcements should sound like real announcements.
- Mock-exam transcripts must remain hidden until the learner submits the answer.
- These are scripts for audio generation, not MP3 files. The current app still uses browser/device TTS.

## A1 short listening practice (24 tracks)

### A1-SKILL-H-01 — Telefonnachricht
**Level:** A1

**German audio script:**

Guten Tag, hier ist die Praxis Dr. Weber. Ihr Termin ist am Dienstag um neun Uhr. Bitte bringen Sie Ihre Versicherungskarte mit.

**Comprehension task:**
Wann ist der Termin?

### A1-SKILL-H-02 — Ansage im Bahnhof
**Level:** A1

**German audio script:**

Achtung! Der Zug nach Köln fährt heute von Gleis fünf. Die Abfahrt ist um 14 Uhr 20.

**Comprehension task:**
Von welchem Gleis fährt der Zug?

### A1-SKILL-H-03 — Alltagsgespräch
**Level:** A1

**German audio script:**

Möchtest du einen Kaffee? – Nein danke, ich nehme lieber einen Tee.

**Comprehension task:**
Was trinkt die Person?

### A1-SKILL-H-04 — Verabredung
**Level:** A1

**German audio script:**

Treffen wir uns um halb sechs vor dem Kino? – Ja, das passt mir gut.

**Comprehension task:**
Wann treffen sie sich?

### A1-SKILL-H-05 — Ansage am Bahnhof
**Level:** A1

**German audio script:**

Der Zug nach Köln fährt heute nicht von Gleis 3, sondern von Gleis 5. Abfahrt ist um 14 Uhr 20.

**Comprehension task:**
Von welchem Gleis fährt der Zug?

### A1-SKILL-H-06 — Nachricht an der Tür
**Level:** A1

**German audio script:**

Hallo, hier ist Peter. Ich bin schon vor dem Kino. Der Film beginnt um halb acht. Wo bist du?

**Comprehension task:**
Wo wartet Peter?

### A1-SKILL-H-07 — Termin
**Level:** A1

**German audio script:**

Guten Tag, Frau Klein. Ihr Termin ist am Donnerstag, den 12. Juni, um Viertel nach zehn. Bitte kommen Sie fünf Minuten früher.

**Comprehension task:**
Wann ist der Termin?

### A1-SKILL-H-08 — Im Geschäft
**Level:** A1

**German audio script:**

Guten Tag. Kann ich Ihnen helfen? – Ja, ich suche eine blaue Jacke in Größe M. – Die Jacken sind dort links.

**Comprehension task:**
Was sucht die Kundin?

### A1-SKILL-H-09 — Wetterbericht
**Level:** A1

**German audio script:**

Morgen ist es in Berlin sonnig und warm. Am Nachmittag gibt es aber Wind. Die Temperatur liegt bei 22 Grad.

**Comprehension task:**
Wie wird das Wetter am Morgen?

### A1-SKILL-H-10 — Verabredung
**Level:** A1

**German audio script:**

Hallo Lea, hier ist Max. Ich komme heute zehn Minuten später. Der Bus steht im Stau. Warte bitte vor dem Restaurant.

**Comprehension task:**
Warum kommt Max später?

### A1-SKILL-H-11 — Telefon im Büro
**Level:** A1

**German audio script:**

Guten Morgen, hier ist Frau Sommer. Herr Braun ist heute nicht im Büro. Er kommt morgen wieder. Kann ich etwas ausrichten?

**Comprehension task:**
Wann kommt Herr Braun wieder?

### A1-SKILL-H-12 — Uhrzeit
**Level:** A1

**German audio script:**

Der Deutschunterricht beginnt nicht um neun Uhr, sondern schon um Viertel vor neun. Bitte seid pünktlich.

**Comprehension task:**
Wann beginnt der Unterricht?

### A1-SKILL-H-13 — Am Bahnhof
**Level:** A1

**German audio script:**

Achtung, eine Durchsage: Der Zug nach Hamburg fährt heute von Gleis sieben. Die Abfahrt ist um zehn Uhr fünfzehn.

**Comprehension task:**
Von welchem Gleis fährt der Zug?

### A1-SKILL-H-14 — Im Supermarkt
**Level:** A1

**German audio script:**

Guten Tag. Die Milch kostet heute nur neunundneunzig Cent. Äpfel sind im Angebot: ein Kilo für zwei Euro.

**Comprehension task:**
Was kostet die Milch?

### A1-SKILL-H-15 — Eine Verabredung
**Level:** A1

**German audio script:**

Hallo Lea, hier ist Mia. Ich bin heute leider krank. Können wir unseren Kaffee auf Freitag verschieben? Ruf mich bitte zurück.

**Comprehension task:**
Warum kann Mia heute nicht kommen?

### A1-SKILL-H-16 — Im Deutschkurs
**Level:** A1

**German audio script:**

Guten Morgen zusammen. Heute lernen wir die Zahlen und die Uhrzeit. Bitte öffnet das Buch auf Seite zwölf.

**Comprehension task:**
Welche Seite sollen die Lernenden öffnen?

### A1-SKILL-H-17 — Im Restaurant
**Level:** A1

**German audio script:**

Guten Abend. Möchten Sie etwas trinken? – Ja, bitte ein Wasser ohne Kohlensäure und einen Apfelsaft.

**Comprehension task:**
Was bestellt die Person?

### A1-SKILL-H-18 — Telefonische Nachricht
**Level:** A1

**German audio script:**

Hallo Herr Fischer, hier ist die Zahnarztpraxis. Ihr Termin morgen ist nicht um elf, sondern um halb zwölf. Auf Wiederhören.

**Comprehension task:**
Wann ist der Termin?

### A1-SKILL-H-19 — Wetterbericht
**Level:** A1

**German audio script:**

Heute bleibt es am Morgen trocken. Am Abend gibt es starken Wind und Regen. Nehmen Sie bitte einen Regenschirm mit.

**Comprehension task:**
Was soll man mitnehmen?

### A1-SKILL-H-20 — Im Bus
**Level:** A1

**German audio script:**

Liebe Fahrgäste, wir erreichen den Marktplatz in fünf Minuten. Bitte steigen Sie rechts aus.

**Comprehension task:**
Wo hält der Bus bald?

### A1-SKILL-H-21 — Bei der Familie
**Level:** A1

**German audio script:**

Anna, das Essen ist fertig! Kannst du bitte deinen Bruder rufen? Wir essen jetzt zusammen in der Küche.

**Comprehension task:**
Wen soll Anna rufen?

### A1-SKILL-H-22 — Im Hotel
**Level:** A1

**German audio script:**

Guten Tag. Das Frühstück ist von sieben bis zehn Uhr im ersten Stock. Ihr Zimmer ist die Nummer 204.

**Comprehension task:**
Wo gibt es Frühstück?

### A1-SKILL-H-23 — Am Telefon
**Level:** A1

**German audio script:**

Hallo Paul, ich komme heute zehn Minuten später. Der Bus steht im Stau. Warte bitte vor dem Kino.

**Comprehension task:**
Warum kommt die Person später?

### A1-SKILL-H-24 — Im Geschäft
**Level:** A1

**German audio script:**

Kann ich Ihnen helfen? – Ja, ich suche eine schwarze Jacke in Größe M. – Die Jacken sind dort links.

**Comprehension task:**
Was sucht die Kundin oder der Kunde?

## A1 Listening Intelligence (10 tracks)

### A1-PASSAGE-01 — Mein Tagesablauf
**Level:** A1

**German audio script:**

Guten Morgen! Ich heiße Lena. Ich stehe jeden Morgen um sieben Uhr auf. Zuerst dusche ich und frühstücke. Um halb acht fahre ich mit dem Bus zur Arbeit. Ich arbeite bis sechzehn Uhr. Am Abend koche ich und lerne Deutsch.

1. Wann steht Lena auf?

2. Wie fährt sie zur Arbeit?

3. Was macht sie am Abend?

### A1-PASSAGE-02 — Im Supermarkt
**Level:** A1

**German audio script:**

Hallo! Ich brauche heute einige Lebensmittel. Ich kaufe ein Brot, einen Liter Milch, sechs Eier und zwei Äpfel. Die Milch kostet einen Euro zwanzig. Das Brot kostet zwei Euro. An der Kasse bezahle ich mit Karte.

1. Was kauft die Person?

2. Wie viel kostet die Milch?

3. Wie bezahlt die Person?

### A1-PASSAGE-03 — Einen Termin vereinbaren
**Level:** A1

**German audio script:**

Guten Tag, hier ist Anna Müller. Ich möchte einen Termin beim Arzt vereinbaren. Haben Sie am Dienstagvormittag Zeit? Um zehn Uhr kann ich leider nicht. Um elf Uhr passt es gut. Vielen Dank. Auf Wiederhören!

1. Wo möchte Anna einen Termin?

2. Wann passt es Anna?

3. Welche Uhrzeit lehnt Anna ab?

### A1-PASSAGE-04 — Am Bahnhof
**Level:** A1

**German audio script:**

Achtung, bitte! Der Zug nach Berlin fährt heute nicht von Gleis drei, sondern von Gleis fünf. Die Abfahrt ist um vierzehn Uhr zwanzig. Der Zug hat ungefähr zehn Minuten Verspätung. Bitte beachten Sie die Änderung.

1. Wohin fährt der Zug?

2. Von welchem Gleis fährt der Zug?

3. Wie viel Verspätung hat der Zug?

### A1-PASSAGE-05 — Das Wetter am Wochenende
**Level:** A1

**German audio script:**

Am Samstag ist das Wetter schön. Es ist sonnig und warm. Am Vormittag möchte ich im Park spazieren gehen. Am Sonntag regnet es wahrscheinlich. Deshalb bleibe ich zu Hause und lese ein Buch.

1. Wie ist das Wetter am Samstag?

2. Was macht die Person am Samstagvormittag?

3. Warum bleibt sie am Sonntag zu Hause?

### A1-PASSAGE-06 — Mein erster Arbeitstag
**Level:** A1+

**German audio script:**

Heute ist mein erster Arbeitstag in einem kleinen Hotel. Meine Kollegin heißt Maria. Sie zeigt mir die Küche, das Büro und den Pausenraum. Ich beginne um acht Uhr und mache um zwölf Uhr dreißig eine Pause. Alle sind freundlich und ich bin nicht mehr nervös.

1. Wo arbeitet die Person?

2. Wer zeigt der Person die Räume?

3. Wann beginnt die Arbeit?

### A1-PASSAGE-07 — Über eine Ausbildung zur Bäckerin sprechen
**Level:** A1+ → A2

**German audio script:**

Guten Tag. Ich interessiere mich für eine Ausbildung zur Bäckerin. Ich backe gern und möchte neue Rezepte lernen. Die Ausbildung dauert drei Jahre. Die Berufsschule ist zweimal pro Woche. An den anderen Tagen arbeite ich in der Bäckerei. Ich freue mich auf praktische Erfahrungen.

1. Für welche Ausbildung interessiert sich die Person?

2. Wie lange dauert die Ausbildung?

3. Wie oft ist Berufsschule?

### A1-PASSAGE-08 — Im Café
**Level:** A1

**German audio script:**

Guten Tag! Ich hätte gern einen Kaffee und ein Stück Apfelkuchen. Der Kaffee kostet zwei Euro fünfzig und der Kuchen drei Euro. Möchten Sie hier essen oder mitnehmen? Ich esse hier, bitte. Zahlen Sie zusammen? Ja, zusammen. Das macht fünf Euro fünfzig.

1. Was bestellt die Person?

2. Wie viel kostet der Apfelkuchen?

3. Möchte die Person die Bestellung mitnehmen?

### A1-PASSAGE-09 — Eine Wohnung besichtigen
**Level:** A1

**German audio script:**

Hallo, ich bin Frau Weber. Die Wohnung hat zwei Zimmer, eine Küche und ein Bad. Sie ist im zweiten Stock. Die Miete kostet sechshundert Euro im Monat, ohne Strom. Der Balkon ist klein, aber die Wohnung ist sehr hell. Sie können am Freitag um fünf Uhr kommen.

1. Wie viele Zimmer hat die Wohnung?

2. Wie hoch ist die monatliche Miete?

3. Wann kann man die Wohnung besichtigen?

### A1-PASSAGE-10 — An der Bushaltestelle
**Level:** A1

**German audio script:**

Entschuldigung, fährt dieser Bus zum Bahnhof? Ja, aber nicht direkt. Sie fahren drei Haltestellen und steigen dann am Rathaus aus. Dort nehmen Sie den Bus Nummer acht. Der fährt direkt zum Bahnhof. Vielen Dank! Gern geschehen.

1. Fährt der erste Bus direkt zum Bahnhof?

2. Wo muss die Person aussteigen?

3. Welche Busnummer fährt von dort zum Bahnhof?

## A1 Goethe-style Hören mock (15 tracks)

### A1-MOCK-H-01 — Teil 1 · Multiple choice · zweimal hören · Aufgabe 1
**Level:** A1

**German audio script:**

Der Pullover kostet fünfundneunzig Euro. Nein, Entschuldigung, ich meine neunzehn Euro fünfundneunzig.

**Comprehension task:**
Was kostet der Pullover?

**Exam part:** Teil 1 · Multiple choice · zweimal hören · **Replay limit:** 2

### A1-MOCK-H-02 — Teil 1 · Multiple choice · zweimal hören · Aufgabe 2
**Level:** A1

**German audio script:**

Es ist schon ziemlich spät. Es ist Viertel vor fünf.

**Comprehension task:**
Wie spät ist es?

**Exam part:** Teil 1 · Multiple choice · zweimal hören · **Replay limit:** 2

### A1-MOCK-H-03 — Teil 1 · Multiple choice · zweimal hören · Aufgabe 3
**Level:** A1

**German audio script:**

Für mich bitte den Fisch. Die Pommes sind für meinen Sohn.

**Comprehension task:**
Was isst die Frau im Restaurant?

**Exam part:** Teil 1 · Multiple choice · zweimal hören · **Replay limit:** 2

### A1-MOCK-H-04 — Teil 1 · Multiple choice · zweimal hören · Aufgabe 4
**Level:** A1

**German audio script:**

Mein Sohn ist jetzt in der vierten Klasse. Nächstes Jahr kommt er in die fünfte.

**Comprehension task:**
In welche Klasse geht Frau Hegers Sohn?

**Exam part:** Teil 1 · Multiple choice · zweimal hören · **Replay limit:** 2

### A1-MOCK-H-05 — Teil 1 · Multiple choice · zweimal hören · Aufgabe 5
**Level:** A1

**German audio script:**

Der Aufzug ist kaputt. Ich nehme die Treppe um die Ecke.

**Comprehension task:**
Wie kommt die Frau in den zweiten Stock?

**Exam part:** Teil 1 · Multiple choice · zweimal hören · **Replay limit:** 2

### A1-MOCK-H-06 — Teil 1 · Multiple choice · zweimal hören · Aufgabe 6
**Level:** A1

**German audio script:**

Ich fahre am Wochenende nicht ans Meer. Ich besuche meine Familie in Hamburg.

**Comprehension task:**
Wohin fährt Herr Albers?

**Exam part:** Teil 1 · Multiple choice · zweimal hören · **Replay limit:** 2

### A1-MOCK-H-07 — Teil 2 · Richtig oder falsch · einmal hören · Aufgabe 7
**Level:** A1

**German audio script:**

Achtung, liebe Kunden. Unser Kaufhaus schließt heute ausnahmsweise erst um 20 Uhr. Morgen sind wir wieder bis 18 Uhr geöffnet.

**Comprehension task:**
Das Kaufhaus schließt heute um 18 Uhr.

**Exam part:** Teil 2 · Richtig oder falsch · einmal hören · **Replay limit:** 1

### A1-MOCK-H-08 — Teil 2 · Richtig oder falsch · einmal hören · Aufgabe 8
**Level:** A1

**German audio script:**

Der Bus 12 fährt heute nicht zum Museum. Bitte steigen Sie an der Haltestelle Rathaus aus.

**Comprehension task:**
Der Bus 12 hält heute am Rathaus.

**Exam part:** Teil 2 · Richtig oder falsch · einmal hören · **Replay limit:** 1

### A1-MOCK-H-09 — Teil 2 · Richtig oder falsch · einmal hören · Aufgabe 9
**Level:** A1

**German audio script:**

Der Zug nach Köln fährt heute von Gleis vier statt Gleis zwei ab.

**Comprehension task:**
Der Zug nach Köln fährt heute von Gleis 2 ab.

**Exam part:** Teil 2 · Richtig oder falsch · einmal hören · **Replay limit:** 1

### A1-MOCK-H-10 — Teil 2 · Richtig oder falsch · einmal hören · Aufgabe 10
**Level:** A1

**German audio script:**

Unsere Apotheke ist samstags von acht bis zwölf Uhr geöffnet.

**Comprehension task:**
Die Apotheke ist am Samstag um 10 Uhr geöffnet.

**Exam part:** Teil 2 · Richtig oder falsch · einmal hören · **Replay limit:** 1

### A1-MOCK-H-11 — Teil 3 · Multiple choice · zweimal hören · Aufgabe 11
**Level:** A1

**German audio script:**

Meine Telefonnummer ist eins-eins-acht-acht-drei.

**Comprehension task:**
Wie lautet die Telefonnummer?

**Exam part:** Teil 3 · Multiple choice · zweimal hören · **Replay limit:** 2

### A1-MOCK-H-12 — Teil 3 · Multiple choice · zweimal hören · Aufgabe 12
**Level:** A1

**German audio script:**

Wir treffen uns nicht am Zug, sondern direkt an der Information im Bahnhof.

**Comprehension task:**
Wo treffen sich die Männer genau?

**Exam part:** Teil 3 · Multiple choice · zweimal hören · **Replay limit:** 2

### A1-MOCK-H-13 — Teil 3 · Multiple choice · zweimal hören · Aufgabe 13
**Level:** A1

**German audio script:**

Ich warte noch zehn Minuten. Wenn du dann nicht da bist, fahre ich nach Hause.

**Comprehension task:**
Wie lange will der Mann noch warten?

**Exam part:** Teil 3 · Multiple choice · zweimal hören · **Replay limit:** 2

### A1-MOCK-H-14 — Teil 3 · Multiple choice · zweimal hören · Aufgabe 14
**Level:** A1

**German audio script:**

Am Montag kann ich nicht. Sonntag ist auch schlecht. Am Samstag habe ich Zeit.

**Comprehension task:**
An welchem Tag hat die Frau Zeit?

**Exam part:** Teil 3 · Multiple choice · zweimal hören · **Replay limit:** 2

### A1-MOCK-H-15 — Teil 3 · Multiple choice · zweimal hören · Aufgabe 15
**Level:** A1

**German audio script:**

Mein Handy funktioniert nicht mehr. Der Bildschirm ist kaputt.

**Comprehension task:**
Was ist kaputt?

**Exam part:** Teil 3 · Multiple choice · zweimal hören · **Replay limit:** 2

## Important
Do not upload these recordings into the app until the audio files have been checked against this manifest. In particular, preserve the mock-exam replay limits: Teil 1 twice, Teil 2 once, Teil 3 twice.