# Deutsch Quest B1 Vocabulary — Finalization v316

## Release decision
The curated 734-record B1 vocabulary bank is frozen for the current content cycle. This is a **content freeze**, not a claim that all entries are official Goethe B1 headwords.

## Frozen bank
- 304 nouns
- 86 verbs
- 61 adjectives and comparison forms
- 36 adverbs/function words
- 13 preposition constructions
- 15 word-family records
- 219 phrases/collocations
- Total: 734 records

## Quality basis
This release carries forward the item-level structural/editorial registry and nine usage/countability clarifications from v315. The source app was re-opened and the shipped vocabulary structures were checked again. Existing learning content was preserved; no bank entries were deleted or promoted to official Goethe status without evidence.

## Goethe alignment
Reference: [Goethe-Zertifikat B1 Wortliste (2016)](https://www.goethe.de/pro/relaunch/prf/id/Goethe-Zertifikat_B1_Wortliste.pdf).

The official foreword describes about 2,400 lexical units, says the list is mainly a reference and expects receptive understanding, and explains that derivable compounds and nominalizations may not be separate entries. Accordingly, the bank intentionally separates:
1. Goethe-confirmed core items where direct evidence exists;
2. topic-aligned/supplementary items;
3. Ausbildung-oriented vocabulary useful beyond the official list.

**Crosswalk status: partial, not certified complete.** The v315 evidence includes 47 exact noun matches, 253 noun records that are supplementary/unconfirmed, 3 not found in selected searches, and 1 combined official word-group form. For verbs, 59/86 base lemmas or related reflexive forms were located in selected PDF searches; 27 were not located. Individual exact crosswalks for all adjectives/comparison forms, adverbs, preposition constructions, phrases and word-family members remain incomplete. Search failure is not proof of absence.

## Verification boundaries
- Internal structural/editorial checks and JavaScript syntax checks are included.
- ZIP integrity is checked.
- Browser/device acceptance is not performed.
- No independent native-speaker certification is claimed.
