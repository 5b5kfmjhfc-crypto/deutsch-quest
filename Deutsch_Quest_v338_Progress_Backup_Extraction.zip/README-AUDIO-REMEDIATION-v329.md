# Deutsch Quest v329 — Audio Playback Remediation

## Baseline
v328 deployed to Cloudflare Pages. The user confirmed:
- Direct MP3 URL: duration appears, playback time advances, and sound is audible.
- In-module A1 and B1 Hören: silent.
- Vocabulary TTS: `interrupted`.

## Key diagnosis
The v328 service worker intercepted `.mp3` requests and synthesized HTTP 206 responses for Range requests. Direct navigation to an MP3 and media-element playback do not necessarily use the same request path. This is a strong code-level candidate for why direct MP3 playback worked while in-module playback was silent. v329 lets Cloudflare Pages and the browser handle MP3 Range requests natively by bypassing the service worker for MP3 requests.

## Corrections
- Removed custom MP3 Range response and MP3 service-worker caching.
- A1 Hören now uses a shared persistent Audio player and absolute same-origin MP3 URLs.
- B1 Goethe exam audio now uses the same shared player; play count increments only after actual playback starts.
- B1 Skills audio URL helper now returns absolute same-origin URLs.
- Vocabulary TTS no longer unconditionally cancels the speech queue through the dialogue stop helper. It cancels only when an utterance is actually speaking/pending, invalidates old dialogue tokens/timers, and ignores stale events.
- Added visible accessible audio status feedback on module screens.
- Bumped service-worker shell cache to v329 and set `updateViaCache: "none"`.

## Static re-audit
- 93 MP3 assets retained.
- 10 A1 listening-bank audio references checked; none missing.
- 8 unique B1 Goethe exam audio references checked; none missing.
- 3/3 inline JavaScript blocks pass `node --check`.
- Service worker passes `node --check`.
- All JSON files parse successfully.

## Required physical-device retest
Static checks do not prove that audio is audible on the device. After deploying v329 to the same Cloudflare Pages project:
1. Open the Pages URL in Chrome on Android and hard-refresh.
2. Test A1 Hören from inside the module.
3. Test B1 Goethe Hören from inside the module; confirm replay count increments only after playback starts.
4. Test Vocabulary's German voice button.
5. Retest the A2 Listening Audio Library.
6. Repeat on iPhone Safari.

Do not remove the existing Worker or the v328 Pages deployment until v329 passes acceptance.
