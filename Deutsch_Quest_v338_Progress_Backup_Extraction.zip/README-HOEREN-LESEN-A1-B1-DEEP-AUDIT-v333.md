# Deutsch Quest v333 — Hören & Lesen A1–B1 Deep Audit

Baseline: v332.

## Result
Static content/source audit and re-audit: PASS. Automated checks: 375/375. Inline JavaScript syntax: 3/3 PASS. MP3 technical decode: 93/93 PASS.

## Corrections
1. A1 Hören: six repeated/generic item titles were made unique and content-specific. The embedded bank, recording manifest and script headings were synchronized. No transcript or audio was changed.
2. B1 Lesen item 19: evidence was changed from a non-verbatim overall conclusion to an exact excerpt from advertisement A. The app-embedded bank, standalone bank and answer key were synchronized. The answer and rationale were retained.

## Coverage
- A1 Hören: 24 short practice items; 10 Listening Intelligence passages; 15 Goethe-style mock items; 49 recording-manifest tracks.
- A1 Lesen: 24 practice items; 15 Goethe-style mock items across three parts.
- A2 Hören: 59 passages (49 A2, 8 A1 foundation, 2 A1+ bridge), 124 comprehension questions; 20-item four-part mock.
- A2 Lesen: 24 practice sets across four parts (120 tasks); six integrated mock variants of 20 items.
- B1 Hören: 30 items, four parts, eight audio units, 40 minutes.
- B1 Lesen: 30 items, five parts, 65 minutes.

## Limits
This is internal static/source QA, not official Goethe certification. No independent native-speaker review or physical iPhone/Android acceptance is claimed. MP3 decoding is a technical integrity check, not a human listening assessment.
