from pathlib import Path
import json,re,zipfile,shutil,hashlib,os
base=Path('/mnt/data/grammar_b1_stage1')
html=base/'Deutsch_Quest_v273_index.html'
s=html.read_text(encoding='utf-8')
marker='const GRAMMAR = '
pos=s.index(marker)+len(marker)
# Find balanced JS array
q=None; esc=False; depth=0
for j in range(pos,len(s)):
 c=s[j]
 if q:
  if esc: esc=False
  elif c=='\\': esc=True
  elif c==q: q=None
 else:
  if c in '\"\'`': q=c
  elif c=='[': depth+=1
  elif c==']':
   depth-=1
   if depth==0: end=j+1; break
old=json.loads(s[pos:end])
# Consolidate the old B1 set, retaining the strongest entry as canonical source.
non_b1=[x for x in old if x.get('level')!='B1']
b1=[x for x in old if x.get('level')=='B1']
by={x['title']:x for x in b1}
# Create a clean, consolidated base of 9 lessons with merged examples and accurate scope.
base_lessons=[
{
'level':'B1','title':'Relative clauses: nominative, accusative and dative',
'rule':'A relative clause adds information about a noun. The relative pronoun agrees with the antecedent in gender and number, but its case is determined by its grammatical role inside the relative clause. The finite verb goes to the end.',
'content':'Nominative: der / die / das / die · Accusative: den / die / das / die · Dative: dem / der / dem / denen. The antecedent supplies gender and number; the clause supplies case.',
'example':'Das ist die Frau, die neben mir wohnt. / Das ist der Mann, den ich gestern getroffen habe. / Die Frau, der ich helfe, ist meine Nachbarin.',
'tip':'Do not choose the case from the main clause. Ask what the pronoun does inside its own relative clause.'},
{
'level':'B1','title':'Konjunktiv II: polite requests, wishes and hypothetical situations',
'rule':'Konjunktiv II expresses distance from reality, politeness, wishes and hypothetical situations. Frequent forms include wäre, hätte, könnte, müsste and dürfte. würde + infinitive is common with many other verbs.',
'content':'Polite: Könnten Sie mir bitte helfen? · Wish: Ich hätte gern mehr Zeit. · Hypothesis: Wenn ich Zeit hätte, würde ich mehr lernen. · Present counterfactual: Wenn ich in Deutschland wäre, würde ich Deutsch sprechen.',
'example':'Ich würde gern eine Ausbildung machen. / Wenn ich mehr Zeit hätte, würde ich jeden Tag backen.',
'tip':'Learn the common irregular forms directly. In a wenn-clause, the conjugated verb goes to the end; in the result clause, the finite würde-form is in position 2.'},
{
'level':'B1','title':'Passive voice: present, past and perfect',
'rule':'Vorgangspassiv focuses on an action or process. Present: werden + Partizip II. Präteritum: wurde/wurden + Partizip II. Perfekt: sein (conjugated) + Partizip II + worden.',
'content':'Präsens: Das Brot wird gebacken. · Präteritum: Das Brot wurde gebacken. · Perfekt: Das Brot ist gebacken worden. · Agent: von + Dativ (von der Bäckerin). Do not confuse worden in the passive perfect with geworden in the lexical perfect of werden.',
'example':'Die Bestellung wird heute geliefert. / Die Arbeitsfläche wurde nach der Schicht gereinigt. / Das Brot ist am Morgen gebacken worden.',
'tip':'The object of the active sentence often becomes the subject of the passive sentence. Use passive when the process matters more than the agent.'},
{
'level':'B1','title':'Infinitive clauses with zu',
'rule':'An infinitive clause with zu complements certain verbs, nouns and adjectives, or expresses an intended action. The infinitive is placed at the end. With separable verbs, zu appears between the prefix and the stem.',
'content':'Ich habe vor, Deutsch zu lernen. · Es ist wichtig, regelmäßig zu üben. · Sie versucht, pünktlich anzukommen. · Modal verbs normally take a bare infinitive without zu.',
'example':'Ich hoffe, bald eine passende Ausbildung zu finden.',
'tip':'Check whether the governing verb or expression requires zu. Do not add zu after a modal verb in an ordinary infinitive construction.'},
{
'level':'B1','title':'Subordinate clauses: weil, dass and obwohl',
'rule':'weil gives a reason, dass introduces reported content or a statement, and obwohl expresses concession. These subordinating conjunctions send the finite verb to the end of their clause.',
'content':'Main clause + weil/dass/obwohl + subject + ... + finite verb. If the subordinate clause comes first, the following main clause begins with its finite verb: Obwohl ich müde bin, lerne ich weiter.',
'example':'Ich lerne Deutsch, weil ich in Deutschland arbeiten möchte. / Ich glaube, dass der Kurs interessant ist. / Obwohl es regnet, gehe ich spazieren.',
'tip':'Keep the verb-final rule inside the subordinate clause. After a fronted subordinate clause, remember inversion in the main clause.'},
{
'level':'B1','title':'Adjective declension: weak, mixed and strong endings',
'rule':'Attributive adjectives before nouns take endings determined by case, gender, number and the determiner. Weak endings follow definite articles; mixed endings follow ein-words and possessives; strong endings appear when no determiner supplies the grammatical marking.',
'content':'Weak: der nette Mann, mit dem netten Mann. · Mixed: ein guter Kaffee, einen guten Kaffee, mit einem guten Kollegen. · Strong: guter Kaffee, mit gutem Kaffee. Feminine and plural forms also change by case.',
'example':'Ich suche eine zuverlässige Mitarbeiterin. / Wir sprechen mit erfahrenen Kolleginnen. / Frisches Brot schmeckt gut.',
'tip':'Identify case, gender and number first; then identify the determiner type. Learn complete noun phrases, not isolated endings.'},
{
'level':'B1','title':'Indirect questions',
'rule':'Indirect questions are subordinate clauses. They begin with ob for yes/no questions or with a question word such as wann, wo, warum or wie. The finite verb goes to the end.',
'content':'Direct: Wann kommt der Zug? → Indirect: Können Sie mir sagen, wann der Zug kommt? · Direct: Arbeitet sie heute? → Indirect: Ich weiß nicht, ob sie heute arbeitet.',
'example':'Könnten Sie mir erklären, wie die Anmeldung funktioniert?',
'tip':'Do not use question word order inside the indirect clause. The whole sentence may still be a question, but the embedded clause has verb-final order.'},
{
'level':'B1','title':'Genitive: possession and relationships',
'rule':'The genitive expresses possession, belonging and relationships, especially in formal and written German. Masculine and neuter singular nouns commonly add -(e)s; feminine and plural nouns usually have no ending.',
'content':'der Mann → des Mannes · das Kind → des Kindes · die Frau → der Frau · die Leute → der Leute. The article and adjective endings also reflect genitive case.',
'example':'Das ist das Auto meines Bruders. / Die Farbe des Hauses ist schön. / Der Name der Schule ist bekannt.',
'tip':'Everyday speech often uses von + dative, but recognise and practise genitive forms in formal texts.'},
{
'level':'B1','title':'Cautious statements and expressions of uncertainty',
'rule':'Expressions such as soweit ich weiß, soweit ich mich erinnere and meines Wissens qualify a statement and show that the speaker is not claiming complete certainty. A fronted clause with soweit follows subordinate-clause word order; the following main clause follows verb-second order.',
'content':'Soweit ich weiß, beginnt der Kurs im Januar. · Soweit ich mich erinnere, haben wir schon darüber gesprochen. · Meines Wissens ist die Bäckerei sonntags geschlossen.',
'example':'Soweit ich weiß, ist die Bäckerei sonntags geschlossen.',
'tip':'Use these expressions to make opinions and information sound appropriately cautious, not unnecessarily uncertain.'}
]
# 18 additional B1 topics that fill genuine gaps without duplicating A1/A2 core.
new=[
('Präteritum: common verbs and modal verbs','The Präteritum is common in written narratives and is also frequent in spoken German with sein, haben and modal verbs. Regular verbs form it with -te; strong verbs often change their stem.','sein: war · haben: hatte · können: konnte · müssen: musste · machen: machte. Modal verbs in the Präteritum are especially common in everyday reports.','Als ich jünger war, musste ich jeden Tag früh aufstehen.','Learn the high-frequency forms as complete paradigms; do not assume every strong verb follows one predictable vowel change.'),
('Plusquamperfekt: the earlier past','The Plusquamperfekt describes an action that happened before another past event. Form it with hatte/war (Präteritum of haben/sein) + Partizip II.','hatte gemacht · war gegangen. The choice of auxiliary follows the same broad pattern as Perfekt.','Als ich am Bahnhof ankam, war der Zug schon abgefahren.','Use it to make the sequence of two past events clear; the later past event is often in Präteritum or Perfekt.'),
('Futur I: predictions, plans and assumptions','Futur I is formed with werden (conjugated) + infinitive at the end. It expresses predictions, intentions or assumptions; present tense with a time expression is also common for planned events.','ich werde lernen · du wirst arbeiten · Wir werden morgen anrufen.','Ich werde nächstes Jahr eine Ausbildung beginnen.','Do not use Futur I automatically for every future meaning; German often uses Präsens with a clear future time expression.'),
('Temporal subordinate clauses','Temporal conjunctions locate events in time. als refers to a single/period past situation, wenn to repeated past situations or present/future conditions; bevor, nachdem, während, bis and sobald introduce subordinate clauses with verb-final order.','als/wenn · bevor · nachdem · während · bis · sobald.','Bevor ich zur Arbeit gehe, frühstücke ich. / Als ich in Japan lebte, arbeitete ich in einer Fischerei.','Distinguish als from wenn by time reference and repetition. Keep the finite verb at the end of each temporal subordinate clause.'),
('Purpose clauses: damit and um ... zu','Use um ... zu when the understood subject of both clauses is the same. Use damit when the subjects differ or when the subordinate clause has its own subject. Both express purpose and place the finite verb at the end in a damit-clause.','Ich lerne viel, um die Prüfung zu bestehen. · Ich erkläre es langsam, damit du alles verstehst.','Ich spare Geld, um später in Deutschland zu leben.','Compare the subjects before choosing. um ... zu is an infinitive clause; damit is a finite subordinate clause.'),
('Infinitive clauses with ohne ... zu and (an)statt ... zu','ohne ... zu expresses an accompanying action that does not happen; (an)statt ... zu expresses an alternative action. The infinitive clause normally shares its understood subject with the main clause.','ohne + zu + infinitive · (an)statt + zu + infinitive.','Er ging, ohne sich zu verabschieden. / Statt fernzusehen, lernt sie Deutsch.','With separable verbs, place zu between prefix and stem: aufzuräumen. Use ohne dass / statt dass when the subjects differ.'),
('Two-part conjunctions','Correlative conjunctions connect parallel elements or clauses. Their parts must be placed around the elements they connect; word order depends on the second part and the clause structure.','entweder ... oder · weder ... noch · sowohl ... als auch · nicht nur ... sondern auch · zwar ... aber.','Ich trinke entweder Tee oder Kaffee. / Sie spricht nicht nur Deutsch, sondern auch Englisch.','Keep the paired elements grammatically parallel. weder ... noch normally uses no additional nicht.'),
('Main-clause connectors and sentence adverbs','Connectors such as deshalb, deswegen, daher, trotzdem, außerdem and dennoch link main clauses. When the connector occupies position 1, the finite verb remains in position 2 and comes before the subject.','Es regnet. Deshalb bleiben wir zu Hause. · Ich bin müde. Trotzdem arbeite ich weiter.','Der Bus hatte Verspätung; deshalb kam ich zu spät.','Contrast coordinating conjunctions (und, aber, denn) with sentence adverbs (deshalb, trotzdem): the latter occupy a clause position and trigger verb-second order.'),
('Verbs with prepositions and da-/wo-compounds','Many German verbs require a fixed preposition and a particular case. For things or ideas, da-compounds often replace preposition + es; wo-compounds form questions.','warten auf + Akk. · teilnehmen an + Dat. · sich interessieren für + Akk. · Ich freue mich darauf. · Worauf wartest du?','Ich interessiere mich für eine Ausbildung. / Worauf freust du dich? – Auf den Urlaub.','Memorise verb + preposition + case as one unit. Use da(r)- before a vowel where required: daran, darauf; use personal pronouns for people.'),
('Reflexive verbs with prepositions','Some reflexive verbs combine with a fixed preposition and case. The reflexive pronoun agrees with the subject; the preposition governs the following noun or pronoun.','sich freuen auf + Akk. · sich erinnern an + Akk. · sich beschäftigen mit + Dat. · sich bewerben um + Akk.','Ich freue mich auf meinen ersten Arbeitstag. / Sie bewirbt sich um eine Ausbildungsstelle.','Learn the complete pattern: reflexive pronoun + verb + preposition + case.'),
('Passive voice with modal verbs','A passive clause with a modal verb uses the conjugated modal verb in position 2 and werden + Partizip II as an infinitive cluster at the end.','Modal verb (conjugated) + ... + Partizip II + werden.','Die Bewerbung muss bis Freitag eingereicht werden. / Der Teig kann von Hand geknetet werden.','The passive infinitive is werden, not worden. In subordinate clauses, the full verb cluster remains at the end.'),
('Genitive prepositions','Some prepositions take the genitive in standard formal German. Common examples include wegen, trotz, während and innerhalb; colloquial usage may vary regionally.','wegen des Wetters · trotz des Regens · während der Ferien · innerhalb einer Woche.','Wegen des starken Regens bleibt die Veranstaltung geschlossen.','Learn the case governed by each preposition and notice the genitive article and noun endings.'),
('N-declension: masculine nouns','Some masculine nouns add -(e)n in all singular cases except nominative. These are often people or animals and include nouns such as Student, Kollege and Junge.','der Student · den Studenten · dem Studenten · des Studenten; der Herr → den Herrn.','Ich helfe dem neuen Kollegen. / Die Tasche des Studenten ist hier.','Learn the full case forms with the noun. Not every masculine noun belongs to this group.'),
('lassen + infinitive','lassen can mean to let/allow, have something done, or leave something in a state. With another verb, lassen is followed by a bare infinitive without zu.','Ich lasse mein Fahrrad reparieren. · Lass mich bitte ausreden. · Wir lassen die Tür offen.','Ich lasse mir die Haare schneiden.','Distinguish lassen + infinitive from the lexical meaning “leave”. In Perfekt with a second infinitive, the Ersatzinfinitiv pattern may occur.'),
('Relative clauses with prepositions and genitive forms','When a relative pronoun follows a preposition, the preposition determines its case. Genitive relative pronouns dessen and deren express possession.','mit dem · auf die · für das · dessen (masculine/neuter) · deren (feminine/plural).','Das ist der Kollege, mit dem ich arbeite. / Das ist die Frau, deren Sohn in Berlin studiert.','The relative pronoun still agrees with the antecedent in gender/number; the preposition or possessive relation determines its case.'),
('Konjunktiv II in the past','Past hypothetical situations and regrets are commonly expressed with hätte/wäre + Partizip II. The construction describes an unreal or unfulfilled past situation.','hätte + Partizip II · wäre + Partizip II.','Wenn ich früher losgefahren wäre, hätte ich den Zug erreicht.','Choose hätte or wäre according to the auxiliary used in the corresponding Perfekt construction.'),
('Je ... desto: proportional comparison','The paired construction je ... desto (or umso) expresses that a change in one situation corresponds to a change in another. The je-clause is subordinate; the desto/umso clause is a main clause with verb-second order.','Je + comparative + subordinate clause, desto/umso + comparative + finite verb + subject ...','Je mehr ich übe, desto sicherer spreche ich Deutsch.','Use comparative forms in both parts and keep the verb at the end of the je-clause.'),
('Word order in complex sentences','In complex sentences, each clause follows its own word-order rule: main clauses use verb-second order, yes/no questions use verb-first order, and subordinate clauses place the finite verb at the end. Verb clusters remain together at the clause boundary.','Main clause: ..., deshalb lerne ich. · Subordinate: ..., weil ich lernen muss. · Fronted subordinate clause: Weil ich lernen muss, bleibe ich zu Hause.','Obwohl ich wenig Zeit habe, übe ich jeden Abend, weil ich die Prüfung bestehen möchte.','Identify clause boundaries first. Then locate the finite verb in each clause separately.'),
]
# Add the missing B1 lesson entries
for title,rule,content,example,tip in new:
 base_lessons.append({'level':'B1','title':title,'rule':rule,'content':content,'example':example,'tip':tip})
# Keep a stable, pedagogical order; 27 lessons total.
assert len(base_lessons)==27
new_all=non_b1+base_lessons
# Replace the existing grammar data with formatted JSON; the surrounding JS remains unchanged.
replacement=json.dumps(new_all,ensure_ascii=False,indent=2)
s2=s[:pos]+replacement+s[end:]
# Add explicit Stage 1 curriculum inventory metadata after GRAMMAR declaration.
insert=end+(len(replacement)-(end-pos))
meta='\n\nconst B1_GRAMMAR_STAGE1_AUDIT = '+json.dumps({
 'release':'v274','stage':'Grammar B1 Stage 1 — Inventory, Coverage Expansion & Structural Audit',
 'status':'completed_with_stage2_linguistic_deep_audit_pending',
 'baseline':'Deutsch Quest v273','baseline_grammar_lessons':92,
 'baseline_level_counts':{'A1':39,'A2':35,'B1':18},
 'baseline_b1_findings':{'overlapping_or_duplicate_lesson_titles':9,'distinct_core_topics_after_consolidation':9,'untagged_shared_grammar_practice_items':135,'explicit_b1_tagged_grammar_practice_items':0},
 'final_level_counts':{'A1':39,'A2':35,'B1':27},'final_grammar_lessons':101,
 'b1_lessons_consolidated':9,'b1_new_topics_added':18,
 'scope_note':'Goethe-Institut publishes B1 exam skill requirements and model papers, not a mandatory exhaustive grammar syllabus. This curriculum map is pedagogical and CEFR-aligned, not an official Goethe grammar list.',
 'stage2_required':['item-by-item linguistic audit of all 27 B1 lessons','complete examples, exceptions and common errors','verify B1 vs A2 boundary','classify and map shared grammar practice items','create B1-specific exercises with checked answer keys']
},ensure_ascii=False,indent=2)+';\n'
s2=s2[:insert]+meta+s2[insert:]
out=base/'Deutsch_Quest_v274_Grammar_B1_Stage1.html'
out.write_text(s2,encoding='utf-8')
# Stage 1 report
report={
 'release':'Deutsch Quest v274','base_release':'Deutsch Quest v273','stage':'Grammar B1 — Stage 1: Inventory, Coverage Expansion & Structural Audit',
 'status':'completed_with_stage2_linguistic_deep_audit_pending',
 'baseline':{'grammar_lessons':92,'A1':39,'A2':35,'B1':18},
 'baseline_b1_titles':[x['title'] for x in b1],
 'findings':[
  {'severity':'high','area':'B1 lesson architecture','finding':'18 B1 lessons contained repeated/overlapping coverage: relative clauses, passive voice, Konjunktiv II, adjective endings and subordinate connectors appeared in multiple lessons.','correction':'Consolidated overlapping entries into 9 coherent core lessons.'},
  {'severity':'high','area':'B1 coverage gaps','finding':'Existing B1 bank lacked explicit lessons for several useful intermediate structures, including Plusquamperfekt, temporal clauses, purpose clauses, two-part conjunctions, verb-preposition patterns, passive with modal verbs and N-declension.','correction':'Added 18 B1 topics with concise scope, rule, structure, example and learning tip.'},
  {'severity':'high','area':'Practice alignment','finding':'The existing grammar practice bank contains 275 items: 140 explicitly tagged A1 and 135 untagged/shared; no items are explicitly tagged B1.','correction':'Recorded as a Stage 2 requirement; do not silently relabel ambiguous shared items.'},
  {'severity':'medium','area':'Adjective declension','finding':'Three separate lessons split overview, definite-article endings and ein-word endings, but strong endings without a determiner and the full case matrix were not represented in a single learning path.','correction':'Consolidated into weak, mixed and strong declension lesson; full matrix and exercises remain Stage 2.'},
  {'severity':'medium','area':'Passive voice','finding':'Present passive was repeated and the past/perfect forms were separated from the foundational explanation.','correction':'Merged present, Präteritum and Perfekt passive into one progression; modal passive added as a separate extension.'},
  {'severity':'medium','area':'Konjunktiv II','finding':'Polite requests, würde + infinitive and hypothetical situations overlapped across three entries; past counterfactual was absent.','correction':'Merged present/current hypothetical uses and added a dedicated past hypothetical lesson.'}
 ],
 'final_inventory':{'total_grammar_lessons':101,'A1':39,'A2':35,'B1':27,'b1_consolidated_lessons':9,'b1_new_topics':18},
 'b1_final_titles':[x['title'] for x in base_lessons],
 'practice_inventory':{'total_items':275,'A1_tagged':140,'B1_tagged':0,'untagged_shared':135,'stage2_action':'Classify each shared item by target level/topic and check answer key and explanation; add B1 practice coverage.'},
 'scope_and_limits':[
  'This stage completes inventory, structural deduplication and coverage expansion, not the item-by-item linguistic deep audit of all B1 explanations.',
  'Goethe-Institut specifies B1 communicative outcomes and four exam modules, but does not prescribe a single exhaustive grammar syllabus.',
  'The 18 added lessons are concise Stage 1 scope entries; Stage 2 must deepen rules, exceptions, examples, contrastive notes and practice.'
 ],
 'external_references':[
  {'title':'Goethe-Zertifikat B1 — Further Information','url':'https://www.goethe.de/ins/id/en/sta/jak/prf/gzb1/inf.html','ref':'turn379469search0'},
  {'title':'Goethe-Zertifikat B1 — Exam Information','url':'https://www.goethe.de/ins/de/en/prf/gzb1.cfm','ref':'turn379469search1'},
  {'title':'Goethe-Zertifikat B1 — Practice Materials','url':'https://www.goethe.de/ins/id/en/m/sta/jak/prf/gzb1/ueb.html','ref':'turn379469search2'}
 ]
}
(base/'QA-REPORT-GRAMMAR-B1-STAGE1-v274.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
# Change ledger
ledger=[]
for oldtitle in [x['title'] for x in b1]:
 ledger.append({'source_title':oldtitle,'action':'consolidated_into_canonical_b1_curriculum','note':'Overlapping lesson merged into a unified topic or reclassified as a distinct progression point.'})
for x in new: ledger.append({'new_title':x[0],'action':'added_stage1_scope_entry','note':'Concise rule, structure, example and learning tip; full pedagogical development scheduled for Stage 2.'})
(base/'GRAMMAR-B1-STAGE1-CORRECTION-LEDGER-v274.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2),encoding='utf-8')
print('WROTE',out,'bytes',out.stat().st_size)
print('lessons',len(new_all),'A1',sum(x['level']=='A1' for x in new_all),'A2',sum(x['level']=='A2' for x in new_all),'B1',sum(x['level']=='B1' for x in new_all))
