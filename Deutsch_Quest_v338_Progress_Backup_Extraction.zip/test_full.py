from playwright.sync_api import sync_playwright
from pathlib import Path
errs=[];cerr=[];results={}
html=Path('/mnt/data/grammar_b1_stage1/Deutsch_Quest_v274_Grammar_B1_Stage1.html').read_text()
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':375,'height':812})
 page.on('pageerror',lambda e:errs.append(str(e)))
 page.on('console',lambda m:cerr.append(m.text) if m.type=='error' else None)
 page.set_content(html,wait_until='domcontentloaded')
 page.locator('[data-nav="Grammar"]').click(); page.locator('[data-gl="B1"]').click()
 cards=page.locator('.gq-lesson'); n=cards.count(); good=0; titles=[]
 for i in range(n):
  card=cards.nth(i); title=card.locator('summary b').first.inner_text(); titles.append(title)
  card.evaluate('(e)=>e.open=true')
  visible=card.locator('.gq-concept-card').count()==1 and card.locator('.gq-example-grid').count()>=1 and card.locator('.gq-practice-card').count()==1 and card.locator('[data-done]').count()==1
  if visible:good+=1
 # Check all IDs unique and no horizontal overflow at target widths
 ids=page.locator('[id]').evaluate_all('(els)=>els.map(e=>e.id)')
 dup=sorted({x for x in ids if ids.count(x)>1})
 widths=[]
 for w in [375,390,768,1280]:
  page.set_viewport_size({'width':w,'height':900})
  widths.append([w,page.locator('body').evaluate('(e)=>e.scrollWidth'),page.locator('body').evaluate('(e)=>e.clientWidth')])
 results={'b1_cards':n,'cards_with_concept_examples_practice_and_completion':good,'unique_titles':len(set(titles)),'duplicate_dom_ids':dup,'widths':widths,'page_errors':errs,'console_errors':cerr}
 print(results)
 b.close()
