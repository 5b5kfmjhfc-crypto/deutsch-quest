# Deutsch Quest B1 Review & Integration — v303

## What is included
- Six integrated review units retained from v302.
- Six playable listening audio placements using existing v282 assets.
- Six reading evidence activities referencing the existing v289 Lesen bank.
- 18 contextual Vocabulary/Grammar retrieval questions.
- Six speaking and six writing transfer activities.
- Saved learner notes, unit completion, review dates and an error log.
- Suggested spaced retrieval intervals: days 1, 3, 7, 14 and 30.

## Integration
Integrated into the v301 application as **B1 Review & Integration**. Progress uses a separate `dqB1Review` state namespace within the existing `dq-complete-state` store; existing Sprechen and Schreiben state is preserved.

## QA
Static checks include source traceability, audio file existence, JSON parsing, navigation/render branch presence, JS syntax, state separation and baseline file preservation. Browser runtime and physical-device acceptance tests remain pending.

## Boundaries
This is original Deutsch Quest practice, not official Goethe material. Reading tasks refer to the existing Lesen bank. Vocabulary/Grammar retrieval is topic/function-based and does not invent lesson IDs. The diagnostic is formative, not CEFR certification.
