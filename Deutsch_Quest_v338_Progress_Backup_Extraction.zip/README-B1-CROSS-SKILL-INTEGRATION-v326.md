# Deutsch Quest — B1 Cross-Skill Integration v326

## Status
**Cross-skill content integration: PASS. Static re-audit: 37/37 PASS. Browser/device acceptance: pending.**

## Baseline and purpose
Built directly from `Deutsch_Quest_B1_Grammar_Final_Verification_v325.zip`. Stage 4 connects the latest Vocabulary v324 and Grammar v325 curricula with the existing B1 Hören, Lesen, Sprechen and Schreiben modules. No Clean Rebuild was started.

## What changed
- Updated B1 Review & Integration provenance to the current Vocabulary v324 and Grammar v325 releases.
- Distinguished current Hören/Lesen exam bank versions from original audio/reading asset identifiers.
- Added a specific vocabulary focus and grammar focus to each of the six integrated pathways.
- Added a production-transfer prompt linking each pathway to the existing Grammar B1 production challenges without inventing lesson IDs.
- Added four observable six-skill integration checkpoints per unit.
- Updated the unit screen to display current Vocabulary and Grammar focus cards and the integration checklist.

## Six integrated pathways
1. Ankommen, Umzug und Alltag
2. Kurse, Lernen und digitale Angebote
3. Stadtleben, Umwelt und Gemeinschaft
4. Termine, Arbeit und Verantwortung
5. Konsum, Reparatur und Nachhaltigkeit
6. Medien, Freizeit und persönliche Entscheidungen

## Preservation and source boundaries
- Existing six pathways, retrieval questions, listening/reading/speaking/writing tasks and spaced-retrieval scheduler are retained.
- Original audio and reading/task IDs remain traceable; they are not silently relabelled as newly authored assets.
- Unit 5 neighbourhood-garden audio remains explicitly a sustainability/community transfer context, not direct consumer-topic evidence.
- Exam-format replay rules, task instructions and answer keys remain controlled by their original skill modules.
- The module remains formative, not an official Goethe exam or CEFR certification.

## Re-audit
- All six units checked for six-skill coverage and complete task fields.
- Retrieval quiz counts and answer indices checked.
- All audio references checked against files.
- Current v324/v325 provenance and visible UI anchors checked.
- Existing review state namespace, milestone migration and local-date handling retained.
- Existing Skills Mastery Lab and exam-bank assets preserved.

See `B1-CROSS-SKILL-INTEGRATION-MAP-v326.json`, `B1-CROSS-SKILL-INTEGRATION-CORRECTION-LEDGER-v326.json` and `QA-REPORT-B1-CROSS-SKILL-INTEGRATION-v326.json`.

## Limitations
Static/source QA is not physical-device acceptance. iPhone Safari and Android Chrome interaction/persistence testing remains pending. Writing and speaking remain formative and require human judgement for formal evaluation.
