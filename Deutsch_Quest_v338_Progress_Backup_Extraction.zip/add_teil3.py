from pathlib import Path
import json,re,zipfile,os
p=Path('/mnt/data/dq_v253_teil3/index.html')
s=p.read_text()
assert 'if(state.active==="Lesen A2 · Teil 3")' not in s
bank=[
{
'title':'Eine Nachricht von Anna','topic':'Freundschaft · Wochenendpläne',
'de':'Hallo Lisa,\n\nwie geht es dir? Danke für deine Einladung zum Geburtstag am Samstag. Ich komme sehr gern! Ich kann aber erst gegen 18 Uhr da sein, weil ich bis 16 Uhr arbeiten muss. Soll ich etwas mitbringen? Ich könnte einen Schokoladenkuchen backen. Sag mir bitte noch, ob wir draußen feiern. Im Wetterbericht steht, dass es am Abend vielleicht regnet.\n\nLiebe Grüße\nAnna',
'en':'Hi Lisa, how are you? Thank you for inviting me to your birthday on Saturday. I would love to come! However, I can only arrive around 6 p.m. because I have to work until 4 p.m. Should I bring anything? I could bake a chocolate cake. Please also tell me whether we are celebrating outside. The weather forecast says it may rain in the evening. Best wishes, Anna.',
'vocab':[['die Einladung','invitation'],['gegen 18 Uhr','around 6 p.m.'],['mitbringen','to bring along'],['der Wetterbericht','weather forecast'],['draußen','outside']],
'qs':[
['Warum kommt Anna erst gegen 18 Uhr?',['Sie muss bis 16 Uhr arbeiten.','Der Zug hat Verspätung.','Sie hat vorher einen Arzttermin.'],0,'Anna says she has to work until 16:00.','„... weil ich bis 16 Uhr arbeiten muss.“'],
['Was möchte Anna vielleicht mitbringen?',['Blumen.','Einen Schokoladenkuchen.','Getränke.'],1,'She offers to bake a chocolate cake.','„Ich könnte einen Schokoladenkuchen backen.“'],
['Wann findet Lisas Geburtstag statt?',['Am Freitag.','Am Sonntag.','Am Samstag.'],2,'The invitation is for Saturday.','„... zum Geburtstag am Samstag.“'],
['Was möchte Anna noch wissen?',['Ob draußen gefeiert wird.','Wie viele Gäste kommen.','Wann die Musik beginnt.'],0,'She asks whether the celebration will be outside.','„... ob wir draußen feiern.“'],
['Was könnte am Abend passieren?',['Es wird sehr heiß.','Es könnte regnen.','Es schneit.'],1,'The forecast says it may rain in the evening.','„... dass es am Abend vielleicht regnet.“']]
},
{
'title':'Eine E-Mail an den Sprachkurs','topic':'Kurs · Anmeldung · Termine',
'de':'Guten Tag,\n\nich heiße Daniel Weber und besuche seit zwei Wochen Ihren Deutschkurs A2 am Montag und Mittwoch. Leider kann ich ab nächster Woche montags nicht mehr kommen, weil ich dann länger arbeiten muss. Gibt es eine andere Gruppe am Dienstag oder Donnerstag? Am Mittwoch kann ich weiterhin teilnehmen. Können Sie mir bitte sagen, ob ich die Gruppe wechseln kann und ob dafür zusätzliche Kosten entstehen?\n\nVielen Dank für Ihre Hilfe.\nMit freundlichen Grüßen\nDaniel Weber',
'en':'Good day, my name is Daniel Weber and I have been attending your A2 German course on Mondays and Wednesdays for two weeks. Unfortunately, from next week I can no longer come on Mondays because I will have to work later. Is there another group on Tuesday or Thursday? I can still attend on Wednesday. Could you tell me whether I can change groups and whether there will be any additional costs? Thank you for your help. Kind regards, Daniel Weber.',
'vocab':[['seit zwei Wochen','for two weeks'],['leider','unfortunately'],['länger arbeiten','to work longer'],['die Gruppe wechseln','to change groups'],['zusätzliche Kosten','additional costs']],
'qs':[
['Wie lange besucht Daniel den Kurs schon?',['Seit zwei Wochen.','Seit zwei Monaten.','Seit einem Jahr.'],0,'He says he has attended for two weeks.','„... besuche seit zwei Wochen Ihren Deutschkurs A2 ...“'],
['An welchem Tag kann Daniel ab nächster Woche nicht mehr kommen?',['Mittwochs.','Montags.','Donnerstags.'],1,'His work schedule prevents him from coming on Mondays.','„... montags nicht mehr kommen ...“'],
['Warum muss Daniel den Kurstag ändern?',['Er zieht in eine andere Stadt.','Der Kurs ist zu teuer.','Er muss länger arbeiten.'],2,'He will have to work longer on Mondays.','„... weil ich dann länger arbeiten muss.“'],
['An welchen Tagen fragt Daniel nach einer anderen Gruppe?',['Dienstag oder Donnerstag.','Freitag oder Samstag.','Montag oder Mittwoch.'],0,'He asks whether there is a group on Tuesday or Thursday.','„Gibt es eine andere Gruppe am Dienstag oder Donnerstag?“'],
['Was möchte Daniel über den Gruppenwechsel wissen?',['Ob er ein Buch kaufen muss.','Ob zusätzliche Kosten entstehen.','Ob der Kurs online stattfindet.'],1,'He asks whether changing groups costs extra.','„... ob dafür zusätzliche Kosten entstehen?“']]
},
{
'title':'Eine Nachricht vom Vermieter','topic':'Wohnen · Reparatur · Termin',
'de':'Liebe Frau Berger,\n\nich möchte Sie informieren, dass am Donnerstag ein Handwerker in Ihre Wohnung kommen muss. Die Heizung im Wohnzimmer funktioniert leider nicht richtig. Der Handwerker kann zwischen 8 und 10 Uhr kommen. Bitte geben Sie mir bis morgen Bescheid, ob Sie zu dieser Zeit zu Hause sind. Falls Sie arbeiten müssen, können Sie mir auch erlauben, die Wohnung mit dem Ersatzschlüssel zu öffnen. Die Reparatur dauert wahrscheinlich nicht länger als eine Stunde.\n\nViele Grüße\nHerr König',
'en':'Dear Ms Berger, I would like to inform you that a repair person needs to come to your apartment on Thursday. Unfortunately, the heating in the living room is not working properly. The repair person can come between 8 and 10 a.m. Please let me know by tomorrow whether you will be home at that time. If you have to work, you can also allow me to open the apartment with the spare key. The repair will probably take no longer than an hour. Best wishes, Mr König.',
'vocab':[['der Handwerker','repair person / tradesperson'],['die Heizung','heating'],['Bescheid geben','to let someone know'],['der Ersatzschlüssel','spare key'],['die Reparatur','repair']],
'qs':[
['Warum soll ein Handwerker kommen?',['Die Heizung funktioniert nicht richtig.','Das Fenster ist kaputt.','Die Küche wird renoviert.'],0,'The heating in the living room is not working properly.','„Die Heizung im Wohnzimmer funktioniert leider nicht richtig.“'],
['An welchem Tag kommt der Handwerker?',['Am Mittwoch.','Am Donnerstag.','Am Freitag.'],1,'The message says Thursday.','„am Donnerstag ein Handwerker in Ihre Wohnung kommen muss.'],
['Zu welcher Zeit kann der Handwerker kommen?',['Zwischen 10 und 12 Uhr.','Am Nachmittag.','Zwischen 8 und 10 Uhr.'],2,'The available time window is 8 to 10 a.m.','„Der Handwerker kann zwischen 8 und 10 Uhr kommen.“'],
['Bis wann soll Frau Berger antworten?',['Bis morgen.','Bis Donnerstagabend.','Bis nächste Woche.'],0,'She is asked to reply by tomorrow.','„Bitte geben Sie mir bis morgen Bescheid ...“'],
['Was kann passieren, wenn Frau Berger arbeiten muss?',['Der Termin wird automatisch abgesagt.','Herr König kann mit dem Ersatzschlüssel öffnen.','Der Handwerker kommt am Wochenende.'],1,'She can permit the landlord to open with the spare key.','„... können Sie mir auch erlauben, die Wohnung mit dem Ersatzschlüssel zu öffnen.“']]
},
{
'title':'Eine Einladung vom Sportverein','topic':'Freizeit · Sport · Anmeldung',
'de':'Hallo zusammen,\n\nam kommenden Sonntag machen wir mit dem Sportverein eine Fahrradtour zum See. Wir treffen uns um 9 Uhr vor der Sporthalle und fahren gemeinsam los. Die Strecke ist ungefähr 20 Kilometer lang und auch für Anfänger geeignet. Bitte bringt Wasser, etwas zu essen und einen Fahrradhelm mit. Wenn ihr kein eigenes Fahrrad habt, könnt ihr bis Freitag eines im Verein ausleihen. Bei starkem Regen fällt die Tour aus. Wir informieren euch am Samstag auf unserer Internetseite.\n\nViele Grüße\nEuer Sportverein',
'en':'Hello everyone, next Sunday we are going on a bike trip to the lake with the sports club. We meet at 9 a.m. in front of the sports hall and leave together. The route is about 20 kilometres and is also suitable for beginners. Please bring water, something to eat and a bicycle helmet. If you do not have your own bicycle, you can borrow one from the club until Friday. If it rains heavily, the trip will be cancelled. We will inform you on Saturday on our website. Best wishes, your sports club.',
'vocab':[['die Fahrradtour','bike tour'],['die Strecke','route / distance'],['geeignet sein für','to be suitable for'],['ausleihen','to borrow'],['ausfallen','to be cancelled']],
'qs':[
['Wohin fährt der Sportverein?',['Zum See.','In die Berge.','In die Innenstadt.'],0,'The group is cycling to the lake.','„... eine Fahrradtour zum See.“'],
['Wann treffen sich die Teilnehmer?',['Um 8 Uhr.','Um 9 Uhr.','Um 10 Uhr.'],1,'The meeting time is 9 a.m.','„Wir treffen uns um 9 Uhr vor der Sporthalle ...“'],
['Wie lang ist die Strecke?',['Ungefähr 10 Kilometer.','Ungefähr 15 Kilometer.','Ungefähr 20 Kilometer.'],2,'The route is about 20 kilometres long.','„Die Strecke ist ungefähr 20 Kilometer lang ...“'],
['Was sollen die Teilnehmer mitbringen?',['Wasser, Essen und einen Helm.','Eine Regenjacke und eine Karte.','Ein Zelt und einen Schlafsack.'],0,'The message lists water, food and a bicycle helmet.','„Bitte bringt Wasser, etwas zu essen und einen Fahrradhelm mit.“'],
['Wann erfahren die Teilnehmer, ob die Tour wegen des Wetters ausfällt?',['Am Freitag.','Am Samstag.','Am Sonntagmorgen.'],1,'The club will post the information on Saturday.','„Wir informieren euch am Samstag auf unserer Internetseite.“']]
},
{
'title':'Eine Nachricht aus dem Hotel','topic':'Reisen · Reservierung · Änderungen',
'de':'Sehr geehrter Herr Fischer,\n\nwir bestätigen Ihre Reservierung für zwei Nächte vom 14. bis 16. August. Sie haben ein Einzelzimmer mit Frühstück gebucht. Leider ist unser Restaurant am 15. August wegen einer privaten Veranstaltung am Abend geschlossen. Das Frühstück wird wie gewohnt von 7 bis 10 Uhr angeboten. Wenn Sie möchten, empfehlen wir Ihnen gern ein Restaurant in der Nähe. Der Check-in ist ab 15 Uhr möglich. Bitte teilen Sie uns mit, wenn Sie später als 20 Uhr anreisen.\n\nMit freundlichen Grüßen\nHotel am Markt',
'en':'Dear Mr Fischer, we confirm your reservation for two nights from 14 to 16 August. You have booked a single room with breakfast. Unfortunately, our restaurant will be closed in the evening on 15 August due to a private event. Breakfast will be served as usual from 7 to 10 a.m. If you wish, we can recommend a nearby restaurant. Check-in is possible from 3 p.m. Please let us know if you will arrive later than 8 p.m. Kind regards, Hotel am Markt.',
'vocab':[['die Reservierung','reservation'],['das Einzelzimmer','single room'],['bestätigen','to confirm'],['in der Nähe','nearby'],['anreisen','to arrive / travel to a place']],
'qs':[
['Wie lange bleibt Herr Fischer im Hotel?',['Eine Nacht.','Zwei Nächte.','Drei Nächte.'],1,'The reservation is for two nights.','„... für zwei Nächte vom 14. bis 16. August.“'],
['Welche Zimmerart hat Herr Fischer gebucht?',['Ein Einzelzimmer.','Ein Doppelzimmer.','Ein Familienzimmer.'],0,'He booked a single room.','„Sie haben ein Einzelzimmer mit Frühstück gebucht.“'],
['Was ist am Abend des 15. August anders?',['Das Frühstück beginnt später.','Der Check-in ist geschlossen.','Das Restaurant ist geschlossen.'],2,'The restaurant is closed that evening because of a private event.','„... unser Restaurant am 15. August wegen einer privaten Veranstaltung am Abend geschlossen.“'],
['Wann gibt es Frühstück?',['Von 6 bis 9 Uhr.','Von 7 bis 10 Uhr.','Von 8 bis 11 Uhr.'],1,'Breakfast is offered from 7 to 10 a.m.','„Das Frühstück wird wie gewohnt von 7 bis 10 Uhr angeboten.“'],
['Was soll Herr Fischer tun, wenn er nach 20 Uhr ankommt?',['Das Hotel vorher informieren.','Ein anderes Hotel suchen.','Am nächsten Morgen anrufen.'],0,'The hotel asks him to inform them if he arrives after 20:00.','„Bitte teilen Sie uns mit, wenn Sie später als 20 Uhr anreisen.“']]
},
{
'title':'Eine E-Mail von der Schule','topic':'Schule · Elterninformation · Ausflug',
'de':'Liebe Eltern,\n\nam Freitag macht die Klasse 5b einen Ausflug ins Naturmuseum. Die Kinder treffen sich wie immer um 8 Uhr vor der Schule. Der Bus fährt um 8.15 Uhr ab. Bitte geben Sie Ihrem Kind ein Lunchpaket und eine Trinkflasche mit. Eintritt und Busfahrt bezahlt die Schule. Wir sind voraussichtlich um 14 Uhr zurück. Wenn Ihr Kind Medikamente braucht oder eine besondere Ernährung hat, informieren Sie bitte die Klassenlehrerin bis Mittwoch.\n\nFreundliche Grüße\nFrau Neumann',
'en':'Dear parents, on Friday class 5b is going on a trip to the natural history museum. The children meet as usual at 8 a.m. in front of the school. The bus leaves at 8:15. Please give your child a packed lunch and a water bottle. The school pays for admission and the bus journey. We expect to return at 2 p.m. If your child needs medication or has a special diet, please inform the class teacher by Wednesday. Kind regards, Ms Neumann.',
'vocab':[['der Ausflug','school trip / excursion'],['das Lunchpaket','packed lunch'],['die Trinkflasche','water bottle'],['voraussichtlich','expected / probably'],['die Klassenlehrerin','class teacher (female)']],
'qs':[
['Wohin fährt die Klasse 5b?',['Ins Naturmuseum.','In den Zoo.','In die Stadtbibliothek.'],0,'The class is visiting the natural history museum.','„... einen Ausflug ins Naturmuseum.“'],
['Wann fährt der Bus ab?',['Um 8 Uhr.','Um 8.15 Uhr.','Um 14 Uhr.'],1,'The bus departure is at 8:15.','„Der Bus fährt um 8.15 Uhr ab.“'],
['Was sollen die Kinder mitbringen?',['Sportkleidung und Schuhe.','Ein Buch und einen Stift.','Ein Lunchpaket und eine Trinkflasche.'],2,'Parents are asked to pack lunch and a water bottle.','„Bitte geben Sie Ihrem Kind ein Lunchpaket und eine Trinkflasche mit.“'],
['Wer bezahlt Eintritt und Busfahrt?',['Die Schule.','Die Eltern.','Die Kinder selbst.'],0,'The school covers both costs.','„Eintritt und Busfahrt bezahlt die Schule.“'],
['Bis wann sollen Eltern besondere Informationen mitteilen?',['Bis Freitagmorgen.','Bis Mittwoch.','Bis nächste Woche.'],1,'The teacher needs the information by Wednesday.','„... informieren Sie bitte die Klassenlehrerin bis Mittwoch.“']]
}
]
# Audit source content
assert len(bank)==6
for bi,b in enumerate(bank):
    assert len(b['qs'])==5 and len(b['vocab'])==5
    for qi,q in enumerate(b['qs']):
        assert len(q)==5 and len(q[1])==3 and q[2] in (0,1,2)
        ev=' '.join(q[4].replace('„','').replace('“','').replace('...', '').split()); assert ev and ev in b['de'], (bi,qi,'evidence not verbatim',ev)
        assert q[3]
# Serialize and create app branch
jb=json.dumps(bank,ensure_ascii=False,separators=(',',':'))
block=f'''if(state.active==="Lesen A2 · Teil 3"){{
 const bank={jb};
 const storageKey="dq-a2-lesen-teil3-v1";
 let run;try{{run=JSON.parse(dqStorageGet(storageKey,"{{}}"))||{{}}}}catch(e){{run={{}}}}
 run.index=Number.isInteger(run.index)?Math.max(0,Math.min(bank.length-1,run.index)):0;
 run.answers=run.answers&&typeof run.answers==="object"?run.answers:{{}};
 run.completed=run.completed&&typeof run.completed==="object"?run.completed:{{}};
 run.awarded=run.awarded&&typeof run.awarded==="object"?run.awarded:{{}};
 run.showTranslation=!!run.showTranslation;
 const persist=()=>dqStorageSet(storageKey,JSON.stringify(run));
 const idx=run.index,t=bank[idx],key="set"+idx,answers=run.answers[key]||{{}},done=!!run.completed[key];
 const countDone=Object.keys(run.completed).filter(k=>run.completed[k]&&Number.isFinite(run.completed[k].score)).length;
 const totalCorrect=Object.values(run.completed).reduce((n,x)=>n+(Number(x&&x.score)||0),0);
 const progress=Math.round(countDone/bank.length*100);
 const vocab=t.vocab.map((v,i)=>`<div class="mini-card"><b>${{escA2(v[0])}}</b><small class="muted">${{escA2(v[1])}}</small><button class="secondary" data-a2t3-vocab="${{i}}">🔊 Hear word</button></div>`).join("");
 const qs=t.qs.map((q,qi)=>{{const chosen=answers[qi];return `<div class="answer" style="margin:12px 0"><b>${{qi+1}}. ${{escA2(q[0])}}</b><div class="grid" style="grid-template-columns:1fr;gap:6px;margin-top:9px">${{q[1].map((o,oi)=>`<button class="secondary" style="text-align:left;white-space:normal;${{chosen===oi?(done?(oi===q[2]?"border:2px solid #27845b":"border:2px solid #c45a55"):"border:2px solid #397b9b"):""}}" data-a2t3-answer="${{qi}}" data-a2t3-option="${{oi}}" ${{done?"disabled":""}}>${{String.fromCharCode(97+oi)}}. ${{escA2(o)}}</button>`).join("")}}</div>${{done?`<div class="answer ${{chosen===q[2]?"good":"bad"}}" style="margin-top:8px"><b>${{chosen===q[2]?"Correct":"Not quite"}}</b> — ${{escA2(q[3])}}<p class="muted" style="margin:5px 0 0"><b>Text evidence:</b> ${{escA2(q[4])}}</p></div>`:""}}</div>`}}).join("");
 el.innerHTML=`<div class="lab-hero"><div class="lab-kicker">DEUTSCH QUEST · A2 LESEN · GOETHE-STYLE TRAINING</div><h2>Teil 3 · Korrespondenz verstehen</h2><p>Read everyday emails and messages. Identify the writer's reason, plans, requests, dates, times and important details. Choose one answer (a, b or c) for each question.</p><div class="lab-metrics"><span>6 original messages</span><span>5 questions each</span><span>30 questions total</span><span>${{countDone}}/6 completed</span></div><div class="progress"><i style="width:${{progress}}%"></i></div></div>
 <div class="answer"><h3>Exam format · what you must do</h3><p><b>Goethe-style A2 practice:</b> read a short everyday message or email and answer five three-option multiple-choice questions. Look for the sender's purpose, who is involved, what is changing, and exact details such as dates, times, places, costs and deadlines.</p><p class="muted">These are original practice texts, not copied official exam questions. The complete Lesen module has four parts and a total time limit; this practice set is for Teil 3 only.</p></div>
 <div class="answer"><h3>Reading strategy · 6 steps</h3><ol><li><b>Identify the sender and recipient:</b> who writes to whom?</li><li><b>Find the purpose:</b> invitation, request, information, complaint, confirmation or change?</li><li><b>Mark key details:</b> dates, times, prices, places, names and deadlines.</li><li><b>Notice reason words:</b> weil, deshalb, leider, aber, falls and wenn.</li><li><b>Separate facts from suggestions:</b> könnte, möchte and vielleicht do not always describe a fixed plan.</li><li><b>Check the whole sentence:</b> options may repeat one keyword but change the reason, time or person.</li></ol><p><b>Important:</b> choose only what the message actually says.</p></div>
 <div class="answer"><div class="row" style="justify-content:space-between;align-items:center"><h3 style="margin:0">Practice messages</h3><span class="pill">${{countDone}}/6 completed · ${{totalCorrect}}/30 correct</span></div><div class="grid">${{bank.map((x,i)=>`<button class="${{i===idx?"primary":"secondary"}}" data-a2t3-set="${{i}}">${{i+1}}. ${{escA2(x.title)}} ${{run.completed["set"+i]?"✓":""}}</button>`).join("")}}</div></div>
 <div class="answer"><div class="row" style="justify-content:space-between"><span class="pill">Message ${{idx+1}} of ${{bank.length}}</span><span class="pill">${{escA2(t.topic)}}</span></div><h2>${{escA2(t.title)}}</h2><div class="notice" style="margin:10px 0"><b>Nachricht / E-Mail</b> · Read the complete message before answering.</div><p style="font-size:14px;line-height:1.85;white-space:pre-line">${{escA2(t.de)}}</p><div class="actions"><button class="secondary" id="a2t3ShowTranslation">${{run.showTranslation?"Hide English translation":"Show English translation"}}</button></div><div id="a2t3Translation">${{run.showTranslation?`<div class="answer">${{escA2(t.en)}}</div>`:""}}</div></div>
 <div class="answer"><h3>Key vocabulary</h3><div class="grid">${{vocab}}</div></div>
 <div class="answer"><h3>Comprehension · choose a, b or c</h3><p class="muted">Answer all five questions, then submit once to see explanations and exact evidence from the message. Your first completed score is saved.</p>${{qs}}${{!done?`<button class="primary" id="a2t3Submit" ${{Object.keys(answers).length===5?"":"disabled"}}>Check all 5 answers</button>`:`<div class="answer good"><b>Message completed · ${{run.completed[key].score}}/5 correct</b><p>${{run.completed[key].score===5?"Excellent! You understood all five details.":"Review the explanations and evidence, then continue. Your first score remains saved."}}</p></div>`}}<div class="actions"><button class="secondary" id="a2t3Prev" ${{idx===0?"disabled":""}}>← Previous message</button><button class="primary" id="a2t3Next" ${{idx===bank.length-1?"disabled":""}}>Next message →</button></div></div>
 <div class="answer"><h3>Self-check · what to notice</h3><ul><li>Can you identify why the person is writing?</li><li>Can you distinguish an invitation from a confirmed appointment?</li><li>Can you find exact dates, times, deadlines and conditions?</li><li>Can you understand polite requests and possible alternatives?</li><li>Can you avoid choosing an answer that changes one important detail?</li></ul><p class="muted">Suggested method: answer without translation first; use the English version and evidence when reviewing.</p></div>`;
 document.querySelectorAll("[data-a2t3-set]").forEach(b=>b.onclick=()=>{{run.index=Number(b.dataset.a2t3Set);run.showTranslation=false;persist();render()}});
 document.querySelectorAll("[data-a2t3-answer]").forEach(b=>b.onclick=()=>{{if(done)return;const qi=Number(b.dataset.a2t3Answer),oi=Number(b.dataset.a2t3Option);run.answers[key]=run.answers[key]||{{}};run.answers[key][qi]=oi;persist();render()}});
 document.querySelectorAll("[data-a2t3-vocab]").forEach(b=>b.onclick=()=>speak(t.vocab[Number(b.dataset.a2t3Vocab)][0]));
 const tr=document.querySelector("#a2t3ShowTranslation");if(tr)tr.onclick=()=>{{run.showTranslation=!run.showTranslation;persist();render()}};
 const submit=document.querySelector("#a2t3Submit");if(submit)submit.onclick=()=>{{const a=run.answers[key]||{{}};if(Object.keys(a).length!==5)return;const score=t.qs.reduce((n,q,i)=>n+(Number(a[i])===q[2]?1:0),0);run.completed[key]={{score,at:new Date().toISOString()}};if(!run.awarded[key]){{state.xp=(state.xp||0)+score*5;run.awarded[key]=true;}}persist();save();render()}};
 const prev=document.querySelector("#a2t3Prev");if(prev)prev.onclick=()=>{{run.index=Math.max(0,idx-1);run.showTranslation=false;persist();render()}};
 const next=document.querySelector("#a2t3Next");if(next)next.onclick=()=>{{run.index=Math.min(bank.length-1,idx+1);run.showTranslation=false;persist();render()}};
 return;
 }}
'''
marker='\n if(state.active==="Reading"){'
assert marker in s
s=s.replace(marker,'\n '+block+marker,1)
# Menu/module links
old='["Lesen A2 · Teil 2","📋","A2 information boards · programmes · 30 original questions"],'
assert old in s
s=s.replace(old,old+'["Lesen A2 · Teil 3","✉️","A2 emails and everyday correspondence · 30 original questions"],',1)
old2='"Lesen A2 · Teil 1","Lesen A2 · Teil 2","Writing"'
assert old2 in s
s=s.replace(old2,'"Lesen A2 · Teil 1","Lesen A2 · Teil 2","Lesen A2 · Teil 3","Writing"',1)
p.write_text(s)
# Save exact script and report
Path('/mnt/data/dq_v253_teil3/add_teil3.py').write_text(Path(__file__).read_text() if '__file__' in globals() else '')
print('Teil 3 inserted:',len(bank),'texts,',sum(len(x['qs']) for x in bank),'questions')
