DEUTSCH QUEST — HÖREN B1 — STAGE 5 (v282)
Audio integration and application candidate

STATUS
- Eight user-provided MP3 recordings are integrated.
- No audio was regenerated, re-recorded, sped up, slowed down, or re-encoded.
- The app candidate adds the Goethe B1 Listening Exam module to the existing v281 application copy.
- This package is not published. It is a candidate for runtime verification.

HOW TO OPEN
1. Extract the ZIP while preserving the folder structure.
2. Open dq_v277_build/index.html through the same web hosting/local server setup used for the existing Deutsch Quest app.
3. Open Practice Center.
4. Under Hören, open "More Hören modules".
5. Select "Goethe B1 Listening Exam".

EXAM STRUCTURE
- 40-minute practice timer.
- Teil 1: five recordings, each may be played twice; 10 questions.
- Teil 2: one recording, played once; 5 questions.
- Teil 3: one recording, played once; 7 questions.
- Teil 4: one recording, played twice; 8 speaker-attribution questions.
- 30 raw points total.
- Transcript, translation, correct answer, evidence and explanation are revealed after submission.
- Result is a practice raw score, not an official Goethe conversion or certificate score.

AUDIO
- Canonical audio assets are in dq_v277_build/audio/b1/.
- Filenames are canonical audio IDs, so the app references are stable.
- The original user upload filenames are recorded in B1-HOEREN-STAGE5-AUDIO-MANIFEST-v282.json.
- Audio bytes are copied unchanged from the uploaded ZIP.

QA NOTES
- All 8 audio files: MP3, mono, 24 kHz, 48 kbps.
- No decoded peak reaches 0 dBFS.
- Audio file mapping is based on the eight numbered upload files and the approved Stage 4 manifest order.
- The 30-item bank, answer key, answer evidence and part distribution pass automated structural checks.
- Inline JavaScript syntax passes Node.js --check.
- Exact spoken-word matching and independent German pronunciation certification were not possible in this environment.
- Live iPhone Safari playback was not tested. Test the extracted package in the same deployment environment as the existing app before publishing.

NO RE-RECORDING
The eight MP3 files are retained as supplied. This stage does not request new recordings.
