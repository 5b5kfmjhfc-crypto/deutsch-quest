# Deutsch Quest — Stage 5 Device Acceptance Preparation (v327)

## Outcome
Technical hardening is complete and the app is **ready for physical device acceptance**. This is not a claim that iPhone or Android testing has passed.

## Corrections and additions
- Added the missing `app/sw.js` referenced by the existing registration call.
- Added a versioned app-shell cache and lazy cache for MP3 files after successful online playback.
- Added offline navigation fallback to the cached app shell.
- Added visible `:focus-visible` styling for keyboard and assistive navigation.
- Added `prefers-reduced-motion` support and small-screen overflow safeguards.
- Preserved the existing app content, local progress namespace, module data, and audio assets.

## Static verification
- 233 JSON files parse successfully, including the Stage 5 reports.
- All 3 inline JavaScript blocks pass `node --check`.
- Both PWA icon files exist.
- The service-worker registration target now exists; install, activation, offline navigation fallback, and MP3 byte-range handling pass static code review.
- 14 responsive media-query groups are present.
- ZIP integrity passes after packaging.

## Important test limitations
A headless Chromium load was attempted but timed out while loading the 6.7 MB inline-data application. It is not counted as a runtime pass. No physical iPhone Safari, Android Chrome, HTTPS-hosting, screen-reader, or touch-target acceptance test was performed.

## Required physical acceptance
Run the checklist in `QA-REPORT-DEVICE-ACCEPTANCE-STAGE5-v327.json` on a real iPhone and Android device. Host the app over HTTPS (or localhost for local testing); service workers do not register from `file://`. Test offline behavior only after the shell has been cached and each MP3 has been played once online.

## Release decision
**READY_FOR_PHYSICAL_DEVICE_ACCEPTANCE — technical hardening complete; physical acceptance pending.** Do not mark Stage 5 fully passed until both device runs are recorded.
