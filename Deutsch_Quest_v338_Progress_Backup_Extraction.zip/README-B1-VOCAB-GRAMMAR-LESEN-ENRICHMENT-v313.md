# Deutsch Quest v313 — B1 Vocabulary, Grammar & Lesen Enrichment

## What changed

Three new learner-facing companion modules have been added to the existing **Language skills** navigation group:

1. **B1 Vocabulary Enrichment**
   - 20 collocations / lexical chunks
   - 12 verb-preposition patterns with case
   - 12 word-formation clusters
   - 4 register contrasts
   - A spaced-retrieval study cycle

2. **B1 Grammar Deep Clinic**
   - 12 high-impact structures with rules, examples, common errors and usage notes
   - 10 self-check questions with answers and explanations
   - Designed to supplement, not replace, the 27 existing B1 grammar lessons

3. **B1 Lesen Strategy Lab**
   - Strategy for each of the five Goethe B1 Lesen parts
   - Purpose–Question–Text evidence–Eliminate (P–Q–T–E) method
   - Paraphrase/distractor examples
   - Suggested 65-minute workflow

## Preserved

- Existing B1 vocabulary source banks
- Existing 27 B1 grammar lessons and 81 focused questions
- Existing original 30-item, five-part B1 Lesen exam
- A1/A2 content and saved progress structures

## Re-audit

- 13/13 targeted structural and content checks passed.
- 3/3 inline JavaScript scripts passed `node --check`.
- ZIP integrity verified after packaging.

## Important limits

This is a substantive enrichment release, not an independent native-speaker certification of every legacy vocabulary or grammar entry. The 12 grammar structures supplement the 27 existing lessons; they do not prove that every sentence in all 27 lessons has been independently proofread. The new vocabulary chunks do not reproduce the complete Goethe B1 lexical inventory. Lesen practice remains original Deutsch Quest content aligned to the public five-part Goethe format, not official Goethe exam content or a certified score. Physical iPhone Safari and Android Chrome acceptance was not performed.

## Official format references

- Goethe B1 online model set — Lesen: https://bfu.goethe.de/b1_mod/lesen.php
- Goethe B1 adult model set PDF: https://www.goethe.de/pro/relaunch/prf/materialien/B1/b1_modellsatz_erwachsene.pdf
- Goethe B1 reading preparation tips: https://www.goethe.de/resources/files/pdf136/tipps_und_tricks_prfungsvorbereitung_goethe-zertifikat_b1_lesen21.pdf
