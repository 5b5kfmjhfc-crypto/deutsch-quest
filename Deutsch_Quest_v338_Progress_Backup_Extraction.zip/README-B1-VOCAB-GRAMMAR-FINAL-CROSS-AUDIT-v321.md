# Deutsch Quest — B1 Vocabulary & Grammar Final Cross Audit v321

## Baseline and scope
- Baseline: v320 Goethe B1 Exam Simulation archive.
- No Clean Rebuild was started.
- The current application remains the source of truth.
- Vocabulary banks, 27 grammar lessons, 81 focused grammar questions and all four Goethe B1 exam modules were preserved.

## Inventory re-opened from the shipped application
| Category | Records |
|---|---:|
| Nouns | 304 |
| Verbs | 86 |
| Adjectives | 61 |
| Adverbs / function words | 36 |
| Preposition patterns | 13 |
| Phrases / collocations | 219 |
| Word-family groups | 15 |
| **Total** | **734** |

Grammar: 27 lessons, 81 dedicated questions (3 per topic). Scope distribution: 9 B1 core, 5 B1 core/A2 bridge, 11 B1 extension, 2 B1 extension/A2 bridge.

## Confirmed correction
One B1 grammar question generated the ungrammatical string “Meines meines Wissens”. The prompt now reads “___ ist die Bibliothek heute geschlossen.” and the correct full expression is “Meines Wissens”. The answer options now contrast the correct genitive phrase with incorrect forms.

## App integration corrections
1. Updated the Vocabulary B1 coverage panel from stale v312 crosswalk wording to the v316 evidence and explicit limitations.
2. Added a B1 Vocabulary & Grammar preparation panel to the Goethe B1 Exam Simulation dashboard. It explains that the 734-record vocabulary bank and 27-topic grammar curriculum are preparation resources, not additional official exam modules or score components.
3. Clarified the Grammar B1 core/extension topic counts, including A2 bridge topics.

## Official Goethe crosswalk — intentionally partial
Reference: [Goethe-Zertifikat B1 Wortliste (2016)](https://www.goethe.de/pro/relaunch/prf/de/Goethe-Zertifikat_B1_Wortliste.pdf). Its foreword describes approximately 2,400 lexical units, expects at least receptive knowledge, and presents the list as a reference rather than a standalone teaching course.

Current evidence retained from v316: 47 noun entries have exact confirmed matches; 253 noun records are topic-aligned/supplementary or unconfirmed; 3 were not located in selected exact searches; and 1 concept is confirmed through the combined official word-group spelling “die (Fach-)Hochschule”. For verbs, 59/86 base lemmas or related reflexive forms were located in selected official PDF text searches; 27 were not located in those searches. Search failure is not proof of absence. Exact item-level crosswalks for all adjectives, adverbs, preposition patterns, phrases and word families remain incomplete. The 734 records are a curated study bank, not a certified exhaustive copy of the official Wortliste.

## Re-audit checks
- Required fields and duplicates rechecked across vocabulary banks.
- All 86 B1 verbs checked for six present-tense forms and principal-part metadata.
- All 27 grammar lessons checked for rule, content, examples, tips, practice hints, scope, common mistakes and deep examples.
- All 81 focused grammar questions checked for required fields, answer membership, unique stems and 3-per-topic coverage.
- Six B1 Review & Integration units checked for vocabulary and grammar retrieval links.
- Exam dashboard bridge and stale-copy correction checked.

Re-audit: 39/39 content and integration checks passed; all 3 inline JavaScript blocks passed `node --check`; all 209 JSON files parsed; ZIP integrity passed (407 files).

See `QA-REPORT-B1-VOCAB-GRAMMAR-FINAL-CROSS-AUDIT-v321.json` and `B1-VOCAB-GRAMMAR-FINAL-CROSS-AUDIT-CORRECTION-LEDGER-v321.json`.

## Limitations
Static/source-level checks only; physical iPhone Safari and Android Chrome acceptance remain pending. This is internal editorial and linguistic QA, not independent native-speaker certification. Writing/Speaking still require human judgement.
