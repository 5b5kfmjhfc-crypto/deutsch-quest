import json,re,zipfile,subprocess,hashlib
from pathlib import Path
root=Path(__file__).parent
html=(root/'index.html').read_text(encoding='utf-8')
manifest=json.loads((root/'A1-HOEREN-RECORDING-MANIFEST-v304.json').read_text(encoding='utf-8'))
extract=json.loads(Path('/mnt/data/a1_audit_sources/extracted_a1_banks.json').read_text(encoding='utf-8'))
audio=json.loads((root/'audio-manifest.json').read_text(encoding='utf-8'))
inventory=json.loads((root/'A1-CONTENT-INVENTORY-v304.json').read_text(encoding='utf-8'))
checks=[]
def ck(name,fn):
    ok=bool(fn()); checks.append((name,ok));
# inventory / source integrity
ck('01 index.html exists',lambda:(root/'index.html').is_file())
ck('02 A1 skill listening bank has 24 items',lambda:len(extract['skill']['Hören'])==24)
ck('03 A1 skill reading bank has 24 items',lambda:len(extract['skill']['Lesen'])==24)
ck('04 A1 mock Hören has 15 tasks',lambda:len(extract['exam']['hoeren'])==15)
ck('05 A1 mock Lesen has 15 tasks',lambda:len(extract['exam']['lesen'])==15)
ck('06 combined listening bank has 59 passages',lambda:len(extract['bank'])==10 and 'const DQ128_LISTENING_BANK' in html and 'DQ128_LISTENING_BANK.length' in html)
ck('07 core A1 listening passages count is 8',lambda:sum(x['level']=='A1' for x in extract['bank'])==8)
ck('08 extension listening passages count is 2',lambda:sum(x['level']!='A1' for x in extract['bank'])==2)
# manifest integrity
ck('09 manifest has 49 tracks',lambda:len(manifest['tracks'])==49)
ck('10 track IDs unique',lambda:len({x['id'] for x in manifest['tracks']})==49)
ck('11 transcripts unique',lambda:len({re.sub(r'\s+',' ',x['transcript_de'].strip().casefold()) for x in manifest['tracks']})==49)
ck('12 short practice track count is 24',lambda:sum(x['group']=='A1 short listening practice' for x in manifest['tracks'])==24)
ck('13 passage track count is 10',lambda:sum(x['group']=='A1 Listening Intelligence' for x in manifest['tracks'])==10)
ck('14 mock track count is 15',lambda:sum(x['group']=='A1 Goethe-style Hören mock' for x in manifest['tracks'])==15)
ck('15 every track has transcript',lambda:all(x['transcript_de'].strip() for x in manifest['tracks']))
ck('16 all direct answer indices valid',lambda:all(0<=x['answer_index']<len(x['options']) for x in manifest['tracks'] if 'answer_index' in x))
ck('17 all passage question indices valid',lambda:all(0<=q['answer_index']<len(q['options']) for x in manifest['tracks'] for q in x.get('questions',[])))
# Goethe-style distribution and playback
mock=[x for x in manifest['tracks'] if x['group']=='A1 Goethe-style Hören mock']
ck('18 mock Teil 1 has six tasks',lambda:sum(x['part'].startswith('Teil 1') for x in mock)==6)
ck('19 mock Teil 2 has four tasks',lambda:sum(x['part'].startswith('Teil 2') for x in mock)==4)
ck('20 mock Teil 3 has five tasks',lambda:sum(x['part'].startswith('Teil 3') for x in mock)==5)
ck('21 mock replay limits follow 2/1/2',lambda:all(x['replay_limit']==(1 if x['part'].startswith('Teil 2') else 2) for x in mock))
# audio inventory and correction
ck('22 app package has zero A1 MP3 files',lambda:not list((root/'audio').glob('a1*.mp3')) and manifest['summary']['integrated_mp3_tracks']==0)
ck('23 existing audio manifest has 36 A2 files',lambda:audio['total']==36 and len(audio['files'])==36)
ck('24 existing app package has eight B1 MP3 files',lambda:len(list((root/'audio'/'b1').glob('*.mp3')))==8)
ck('25 Bus 12 transcript correction is present',lambda:'Er hält heute an der Haltestelle Rathaus.' in html and 'Der Bus 12 fährt heute nicht zum Museum. Er hält heute an der Haltestelle Rathaus. Bitte steigen Sie dort aus.' in html)
# JS syntax and TTS disclaimer
scripts=re.findall(r'<script[^>]*>([\s\S]*?)</script>',html,re.I)
jsok=True
for i,script in enumerate(scripts):
    p=root/f'.qa_inline_{i}.js';p.write_text(script,encoding='utf-8')
    r=subprocess.run(['node','--check',str(p)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    p.unlink(missing_ok=True)
    if r.returncode: jsok=False
ck('26 inline JavaScript syntax and TTS disclaimer',lambda:jsok and 'device/browser text-to-speech' in html)
ck('27 A1 noun inventory contains 587 nouns',lambda:inventory['a1_nouns']['count']==587)
ck('28 A1 nouns have plural and examples, no exact duplicates',lambda:inventory['a1_nouns']['missing_plural']==0 and inventory['a1_nouns']['missing_example']==0 and inventory['a1_nouns']['duplicate_headwords']==0)
ck('29 A1 grammar has 39 lessons',lambda:inventory['a1_grammar']['count']==39)
ck('30 A1 grammar lesson titles are unique',lambda:inventory['a1_grammar']['unique_titles']==39)
ck('31 A1 grammar required teaching fields complete',lambda:inventory['a1_grammar']['missing_required_fields']==0)
ck('32 A1 verb bank has 203 unique infinitives',lambda:inventory['a1_verbs']['count']==203 and inventory['a1_verbs']['unique_infinitives']==203)
ck('33 every A1 verb has six present-tense forms',lambda:len(inventory['a1_verbs']['missing_paradigms'])==0)
ck('34 A1 adjectives have required fields and no duplicates',lambda:inventory['a1_adjectives']['count']==122 and inventory['a1_adjectives']['missing_required']==0 and inventory['a1_adjectives']['duplicates']==0)
ck('35 A1 adverbs have required fields and no duplicates',lambda:inventory['a1_adverbs']['count']==76 and inventory['a1_adverbs']['missing_required']==0 and inventory['a1_adverbs']['duplicates']==0)
ck('36 A1 prepositions have required fields and no duplicates',lambda:inventory['a1_prepositions']['count']==15 and inventory['a1_prepositions']['missing_required']==0 and inventory['a1_prepositions']['duplicates']==0)
ck('37 A1 phrases have required fields and no duplicates',lambda:inventory['a1_phrases']['count']==526 and inventory['a1_phrases']['missing_required']==0 and inventory['a1_phrases']['duplicates']==0)
failed=[n for n,ok in checks if not ok]
print(f'{len(checks)-len(failed)}/{len(checks)} PASS')
for n,ok in checks: print(('PASS' if ok else 'FAIL')+' '+n)
if failed: raise SystemExit(1)
