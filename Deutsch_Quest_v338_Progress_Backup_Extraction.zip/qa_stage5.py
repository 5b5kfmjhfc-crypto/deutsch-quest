import json, os, re, subprocess, sys, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BANK = ROOT / "B1-HOEREN-STAGE4-FINAL-EXAM-BANK-v281.json"
KEY = ROOT / "B1-HOEREN-STAGE4-FINAL-ANSWER-KEY-v281.json"
MANIFEST = ROOT / "B1-HOEREN-STAGE5-AUDIO-MANIFEST-v282.json"
HTML = ROOT / "index.html"
AUDIO = ROOT / "audio" / "b1"

bank=json.loads(BANK.read_text(encoding="utf-8"))
key=json.loads(KEY.read_text(encoding="utf-8"))
manifest=json.loads(MANIFEST.read_text(encoding="utf-8"))
html=HTML.read_text(encoding="utf-8")

records=[]
for part in bank["parts"]:
    if part["part"]==1:
        for item in part["items"]:
            for q in item["questions"]: records.append((part,item,q))
    else:
        for q in part["questions"]: records.append((part,part,q))

assert len(bank["parts"])==4
assert len(records)==30
assert sorted(q["number"] for _,_,q in records)==list(range(1,31))
assert [sum(1 for p,_,_ in records if p["part"]==i) for i in range(1,5)]==[10,5,7,8]
assert len(key["items"])==30
for _,item,q in records:
    assert q["evidence_de"] in item["transcript"]
    assert q["why_en"]
    answer=next(x["answer"] for x in key["items"] if x["number"]==q["number"])
    assert answer==q["answer"]

assets=manifest["assets"]
assert len(assets)==8
for a in assets:
    f=AUDIO/a["canonical_file"]
    assert f.exists() and f.stat().st_size==a["size_bytes"]
    assert a["sample_rate_hz"]==24000 and a["channels"]==1 and a["bitrate_bps"]==48000
    assert "audio/b1/${esc(id)}.mp3" in html

assert 'if(state.active==="Goethe B1 Listening Exam"){dqB1ExamRender();return;}' in html
assert 'Goethe B1 Listening Exam' in html
assert '40*60*1000' in html
assert 'data-b1-play' in html and 'data-b1-q' in html
assert 'dqB1ExamScore' in html
assert 'transcript' in html
print("PASS: 4 parts, 30 questions, exact evidence, answer key, 8 MP3 assets, app route, timer and playback controls.")
