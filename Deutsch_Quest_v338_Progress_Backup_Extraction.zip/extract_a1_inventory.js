const fs=require('fs'),vm=require('vm');
const source=fs.readFileSync(__dirname+'/index.html','utf8');
function extract(name){
 const re=new RegExp('(?:const|let)\\s+'+name+'\\s*='); const m=re.exec(source); if(!m)throw Error('Missing '+name);
 let i=source.indexOf('=',m.index)+1; while(/\s/.test(source[i]))i++;
 const open=source[i], close=open==='['?']':'}'; if(!close)throw Error('Unexpected opener '+name);
 let depth=0, quote=null, escape=false, template=false, lineComment=false, blockComment=false;
 for(let j=i;j<source.length;j++){
  const c=source[j],n=source[j+1];
  if(lineComment){if(c==='\n')lineComment=false;continue;}
  if(blockComment){if(c==='*'&&n==='/'){blockComment=false;j++;}continue;}
  if(quote){if(escape){escape=false;continue;}if(c==='\\'){escape=true;continue;}if(c===quote)quote=null;continue;}
  if(template){if(escape){escape=false;continue;}if(c==='\\'){escape=true;continue;}if(c==='`')template=false;continue;}
  if(c==='/'&&n==='/'){lineComment=true;j++;continue;} if(c==='/'&&n==='*'){blockComment=true;j++;continue;}
  if(c==='"'||c==="'"){quote=c;continue;} if(c==='`'){template=true;continue;}
  if(c===open)depth++; if(c===close){depth--;if(depth===0)return vm.runInNewContext('('+source.slice(i,j+1)+')');}
 }
 throw Error('Unclosed '+name);
}
const names=['VOCAB','VERBS','ADJECTIVES','ADVERBS','PREPOSITIONS','PHRASES','GRAMMAR','VERB_FORMS'];
const data=Object.fromEntries(names.map(n=>[n,extract(n)]));
const a1=x=>Array.isArray(x)?(x[4]==='A1'||x[3]==='A1'):(x.level==='A1');
const nouns=data.VOCAB.filter(x=>x.level==='A1'&&/^(der|die|das)\s/.test(x.de));
const grammar=data.GRAMMAR.filter(x=>x.level==='A1');
const verbs=data.VERBS.filter(a1);
const verbForms=Object.fromEntries(verbs.map(v=>[v[0],data.VERB_FORMS[v[0]]||null]));
const inv={version:'v304',source:'v303 full app index.html',counts:Object.fromEntries(names.filter(n=>Array.isArray(data[n])).map(n=>[n,{total:data[n].length,a1:data[n].filter(a1).length}])),a1_nouns:{count:nouns.length,missing_plural:nouns.filter(x=>!('plural'in x)).length,missing_example:nouns.filter(x=>!x.example).length,duplicate_headwords:nouns.length-new Set(nouns.map(x=>x.de.toLowerCase())).size},a1_grammar:{count:grammar.length,unique_titles:new Set(grammar.map(x=>x.title)).size,missing_required_fields:grammar.filter(x=>!x.title||!x.rule||!x.content||!x.example||!x.tip||!x.commonMistakes||!x.deepExamples||!x.practiceHint).length},a1_verbs:{count:verbs.length,missing_paradigms:verbs.filter(v=>!Array.isArray(data.VERB_FORMS[v[0]])||data.VERB_FORMS[v[0]].length!==6).map(v=>v[0]),unique_infinitives:new Set(verbs.map(v=>v[0])).size},a1_adjectives:{count:data.ADJECTIVES.filter(a1).length,missing_required:data.ADJECTIVES.filter(a1).filter(x=>!x[0]||!x[1]||!x[2]).length,duplicates:data.ADJECTIVES.filter(a1).length-new Set(data.ADJECTIVES.filter(a1).map(x=>x[0].toLowerCase())).size},a1_adverbs:{count:data.ADVERBS.filter(a1).length,missing_required:data.ADVERBS.filter(a1).filter(x=>!x.de||!x.en||!x.example).length,duplicates:data.ADVERBS.filter(a1).length-new Set(data.ADVERBS.filter(a1).map(x=>x.de.toLowerCase())).size},a1_prepositions:{count:data.PREPOSITIONS.filter(a1).length,missing_required:data.PREPOSITIONS.filter(a1).filter(x=>!x.de||!x.en||!x.example).length,duplicates:data.PREPOSITIONS.filter(a1).length-new Set(data.PREPOSITIONS.filter(a1).map(x=>x.de.toLowerCase())).size},a1_phrases:{count:data.PHRASES.filter(a1).length,missing_required:data.PHRASES.filter(a1).filter(x=>!x.de||!x.en||!x.example).length,duplicates:data.PHRASES.filter(a1).length-new Set(data.PHRASES.filter(a1).map(x=>x.de.toLowerCase())).size}};
fs.writeFileSync(__dirname+'/A1-CONTENT-INVENTORY-v304.json',JSON.stringify(inv,null,2));
console.log(JSON.stringify(inv,null,2));
