# Deutsch Quest B1 — Hören, Sprechen & Schreiben Finalization v317

## Release status
**Content finalization: PASS. Static QA: PASS. Device acceptance: pending.**

This release continues from the exact v316 package. Existing A1/A2/B1 content, app assets, and the already integrated B1 modules are preserved. Changes are limited to verified clarifications and the Hören score-reference enhancement.

## Finalized inventory

### Hören B1
- Four parts; 30 items distributed 10 / 5 / 7 / 8; 40-minute practice exam.
- Eight integrated MP3 recordings (24 kHz, mono, 48 kbps).
- Replay policy: Teil 1 twice per recording; Teil 2 once; Teil 3 once; Teil 4 twice.
- Answer keys and evidence excerpts passed structural checks.
- The official raw-point conversion reference is now shown after the practice attempt. The raw score remains a Deutsch Quest practice result, not an official Goethe result.

### Sprechen B1
- 12 toolkit units and 65 phrase records.
- 9 guided tasks and 9 independent tasks.
- 3 original mock sets, each with all three speaking parts.
- 15-minute preparation and 15-minute pair-exam flow.
- Scoring maxima align to the 100-point structure; the full examiner descriptors are not reproduced and no automatic pronunciation score is claimed.

### Schreiben B1
- 12 toolkit units.
- 9 guided tasks and 9 independent tasks.
- 3 original mock sets, each containing all three writing tasks.
- 60-minute mock, with 20 / 25 / 15 minute task allocation.
- Approximate word targets 80 / 80 / 40.
- Added explicit word-count convention: stored model counts refer to the body and exclude greeting, sign-off and sender name.

## Cross-skill transfer
The recommended practice cycle is: listen for information and evidence → discuss, plan or present → write a coherent response. Shared topics include work, education, health, everyday life, travel, environment, digital media and community. The modules retain distinct task requirements.

## Verification
- 15 targeted structural and runtime checks passed.
- 8/8 MP3 files decoded successfully with ffmpeg and passed codec/sample-rate/channel checks.
- 3/3 inline JavaScript blocks passed `node --check`.
- ZIP integrity is checked in the release archive.

## Boundaries
- All practice content is original Deutsch Quest material, not official Goethe examination content.
- Writing and speaking scoring is formative; formal assessment requires human judgement and current official examiner descriptors.
- No speech recording, speech recognition or automatic pronunciation assessment.
- No independent native-speaker certification.
- iPhone Safari and Android Chrome acceptance testing remains pending.
