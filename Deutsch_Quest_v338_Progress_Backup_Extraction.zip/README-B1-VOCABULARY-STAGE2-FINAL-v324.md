# Deutsch Quest B1 – Vocabulary Stage 2 Final Linguistic Verification (v324)

## Release decision
Stage 2 is complete at the editorial linguistic-verification level. The v323 baseline was used; all 719 lexical records, 15 word-family groups and 62 family-member links were retained.

## Work completed
- Rechecked all noun, verb, adjective, adverb/function-word, preposition, and phrase records.
- Rechecked word-family derivations and labels.
- Corrected the `aufgeben` English sense distinction and added a parcel-dispatch example.
- Corrected the `sich lohnen` conjugation display to teach the common 3rd-person construction.
- Corrected `die Wissenschaft` plural to `die Wissenschaften` and upgraded it to a direct Goethe exact match.
- Added usage notes for specialist/rare plural forms (`Verbrauch`, `Durchschnitt`, `Arbeitsbedingung`).
- Added verb valency patterns for 23 high-value verbs.
- Added register notes for selected conversational/formal phrases.
- Corrected the `Erfahrungen sammeln` collocation in the learner-facing enrichment page.
- Added a concise learner-facing linguistic precision panel.
- Added Stage 2 review metadata to all lexical records and word-family groups.

## Crosswalk update
Two new direct official matches are documented:
- `aufgeben` – official Goethe B1 Wortliste 2016, extracted line 1089.
- `die Wissenschaft` – official Goethe B1 Wortliste 2016, extracted lines 7209–7210.

Updated exact-confirmed inventory: 136. Remaining supplementary/pending: 526. Pending is not proof of absence.

## QA
31/31 content and integrity checks passed. JavaScript syntax checks are recorded in the QA report. ZIP integrity is checked after archive creation.

## Scope limits
This is an editorial linguistic review, not a signed native-speaker certification. Study-level tags remain pedagogical, not official CEFR assignments. Dictionary verification is claimed only where a named source and exact evidence are attached.
