/* Deutsch Quest v337 — end-to-end audit cache refresh */
const CACHE_PREFIX = "deutsch-quest-";
const SHELL_CACHE = CACHE_PREFIX + "shell-v338";
const SHELL = ["./", "./index.html", "./backup.html", "./manifest.webmanifest", "./icons/icon-192.png", "./icons/icon-512.png"];
const SHELL_PATHS = new Set(["/", "/index.html", "/backup.html", "/manifest.webmanifest", "/icons/icon-192.png", "/icons/icon-512.png"]);


self.addEventListener("install", event => {
  event.waitUntil((async () => {
    const cache = await caches.open(SHELL_CACHE);
    await cache.addAll(SHELL);
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith(CACHE_PREFIX) && ![SHELL_CACHE].includes(key)).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (request.mode === "navigate") {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (response && response.ok) {
          const cache = await caches.open(SHELL_CACHE);
          const path = url.pathname;
          if (path.endsWith("/backup.html")) cache.put("./backup.html", response.clone());
          else if (path.endsWith("/") || path.endsWith("/index.html")) cache.put("./index.html", response.clone());
        }
        return response;
      } catch (_) {
        return (await caches.match(request)) || (url.pathname.endsWith("/backup.html") ? await caches.match("./backup.html") : null) || (await caches.match("./index.html")) || Response.error();
      }
    })());
    return;
  }

  // MP3 requests intentionally bypass this service worker; the browser and Pages handle media Range requests natively.
  if (SHELL_PATHS.has(url.pathname) || url.pathname.endsWith("/backup.html")) {
    event.respondWith((async () => {
      const cached = await caches.match(request);
      if (cached) return cached;
      return fetch(request);
    })());
  }
});
