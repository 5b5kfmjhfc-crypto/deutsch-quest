# Deutsch Quest — B1 Review & Integration v319

## Purpose
A cross-skill consolidation module connecting Hören, Lesen, Vocabulary, Grammar, Sprechen and Schreiben through six practical B1 situations.

## Six integrated pathways
1. Ankommen, Umzug und Alltag
2. Kurse, Lernen und digitale Angebote
3. Stadtleben, Umwelt und Gemeinschaft
4. Termine, Arbeit und Verantwortung
5. Konsum, Reparatur und Nachhaltigkeit
6. Medien, Freizeit und persönliche Entscheidungen

Each unit retains its existing v303 scenario, three contextual retrieval questions, reading-bank references, productive transfer tasks and audio placement. v319 adds a unit-specific listening focus with a two-pass gist/detail routine. Unit 5 explicitly labels the neighbourhood-garden audio as a sustainability/community transfer context, not as a recording about purchases or repairs.

## Spaced retrieval correction
- The first successful three-question retrieval starts the schedule.
- Milestones are tracked separately at days 1, 3, 7, 14 and 30.
- A milestone remains visible as overdue until it is recorded.
- A second retrieval cannot be recorded on the same local calendar date, or before the next milestone is due.
- The app uses local calendar dates rather than UTC date strings.
- Existing v303 `reviewDates` are migrated into the new milestone state without discarding learner history.
- Repeated-retrieval evidence means successful retrieval on at least two distinct dates. It is a learning rule, not a Goethe score or CEFR certification.

## Source boundaries
- Vocabulary/Grammar prompts refer to existing B1 modules; no unsupported lesson IDs were invented.
- Reading prompts refer to the existing v289 Lesen bank; reading passages and answer keys are not duplicated here.
- Audio files are existing v282 assets. Their original task instructions/play-count remain authoritative for exam-format use.
- Unit 5 reuses the Unit 3 neighbourhood-garden recording for transfer; it is not direct consumer-topic listening material.

## QA and limitations
See `QA-REPORT-B1-REVIEW-INTEGRATION-v319.json` and `B1-REVIEW-INTEGRATION-CORRECTION-LEDGER-v319.json`.
Static content, path, JSON, JavaScript syntax and audio-probe checks passed. Browser interaction, localStorage persistence and physical-device acceptance were not tested in this pass. The unit-completion checkbox remains learner self-attestation, not automatically scored assessment.
