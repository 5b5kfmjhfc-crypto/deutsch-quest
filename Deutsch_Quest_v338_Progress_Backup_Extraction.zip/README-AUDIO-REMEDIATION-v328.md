# Deutsch Quest v328 — Audio Remediation

## Baseline
v327, preserved as the content baseline.

## Corrections
- Vocabulary TTS now resets interrupted speech, selects an installed German voice when available, resumes the Android speech queue, and exposes an accessible playback/error status.
- A1 recorded Hören resolves audio URLs against `document.baseURI`, explicitly loads media, and reports media errors.
- B1 exam audio explicitly preloads/loads before playback and reports more useful failure information.
- Vocabulary now contains an `aria-live` audio status region.
- Service worker cache names are versioned to v328 to avoid stale v327 shell/audio cache reuse.

## Static re-audit
- 93/93 MP3 files pass ffprobe codec/container validation.
- 10/10 A1 recorded-audio references resolve to existing MP3 files.
- 8/8 B1 exam audio references resolve to existing MP3 files.
- 3/3 inline JavaScript blocks pass `node --check`.
- 177/177 JSON files parse successfully.
- ZIP integrity is verified after packaging.

## Device retest required
This release is not yet a physical-device audio acceptance pass. After redeploying v328, test:
1. Vocabulary word speaker and Test German voice.
2. A1 recorded Hören.
3. B1 Hören exam audio.
4. Existing A2 Listening Audio Library.

If Vocabulary remains silent while MP3 works, enable/install Android Text-to-speech output and German voices in Android system settings. If MP3 remains silent, use the visible audio status/error and test the corresponding `/audio/...mp3` asset URL directly.
