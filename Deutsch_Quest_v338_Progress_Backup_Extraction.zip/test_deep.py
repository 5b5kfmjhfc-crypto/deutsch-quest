from playwright.sync_api import sync_playwright
from pathlib import Path
import json,re,hashlib
p=Path('/mnt/data/grammar_b1_stage1/Deutsch_Quest_v274_Grammar_B1_Stage1.html'); html=p.read_text()
errs=[]; cerrors=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':390,'height':844})
 page.on('pageerror',lambda e:errs.append(str(e)))
 page.on('console',lambda m:cerrors.append(m.text) if m.type=='error' else None)
 page.set_content(html,wait_until='domcontentloaded')
 page.locator('[data-nav="Grammar"]').click(); page.wait_for_timeout(150)
 page.locator('[data-gl="B1"]').click(); page.wait_for_timeout(150)
 print('lesson cards',page.locator('.gq-lesson').count())
 print('B1 audit panel',page.get_by_text('B1 Grammar · Stage 1 curriculum map').count())
 print('B1 practice btn',page.locator('#startgrammar').inner_text(),'disabled',page.locator('#startgrammar').is_disabled())
 # open first lesson and verify explanation and practice hint; mark complete.
 first=page.locator('.gq-lesson').first
 title=first.locator('summary b').inner_text()
 first.evaluate('(e)=>e.open=true'); page.wait_for_timeout(80)
 print('first title',title,'concept',first.locator('.gq-concept-card').inner_text()[:120])
 print('try it',first.locator('.gq-practice-card').count(),'done button',first.locator('[data-done]').count())
 # click completion
 first.locator('[data-done]').click(); print('done text',first.locator('[data-done]').inner_text())
 print('errors',errs,'console',cerrors)
 print('overflow',page.locator('body').evaluate('(e)=>[e.scrollWidth,e.clientWidth]'))
 b.close()
