DEUTSCH QUEST — A2 FINAL INTEGRATION & DEEP QA (v269)

Contents
- index.html: Deutsch Quest application with A2 Lesen Teil 1, Teil 2 and Teil 3 modules, plus the A2 Listening audio library.
- audio/a2_01.mp3 ... audio/a2_36.mp3: 36 mapped WevoLabs MP3 recordings.
- audio-manifest.json: mapping from source A2 listening items to final MP3 assets and technical metadata.
- add_teil2.py / add_teil3.py: reproducible source scripts for the two added modules.

A2 Lesen — Teil 1
- Six original media-style texts, 30 questions total (five per text), three options each.
- English translations, vocabulary, pronunciation buttons, explanations and text evidence.

A2 Lesen — Teil 2
- Six original information boards / programmes, 30 questions total (five per board), three options each.
- English translations, vocabulary, pronunciation buttons, explanations and text evidence.

A2 Lesen — Teil 3
- Six original everyday emails and messages, 30 questions total (five per text), three options each.
- English translations, five vocabulary items per text, pronunciation buttons, explanations and exact text evidence.
- Reading strategy covers sender/recipient, purpose, key details, reason words, suggestions vs facts, and distractors.
- Learner answers and first-attempt scores are stored locally; XP is awarded once per completed text.
- These are original practice materials, not copied Goethe exam questions.

Deep-audit checks for Teil 3
- 6/6 texts present; 5/5 questions and 5 vocabulary entries per text.
- 30/30 questions have exactly three distinct options and valid answer indices.
- 30/30 answer evidence excerpts were checked against the corresponding German message (ellipsis may omit non-essential words).
- All six texts are everyday correspondence in A2-oriented contexts: invitation, course change, landlord repair, club outing, hotel reservation and school trip.
- Module navigation and render route are registered.
- All inline JavaScript blocks pass Node syntax validation.
- Existing Teil 1, Teil 2, Listening A2 module, manifest and 36 MP3 assets are preserved.

Listening A2 asset status
- 36 mapped assets present and retained.
- Previous technical audio validation: all 36 MP3s decoded; MP3, 24 kHz, mono.
- Human listening quality was reviewed and accepted by the user. This package does not claim independent native-speaker acoustic certification.

Limitations
- This build has source-level and syntax validation. Real-device iPhone Safari interaction, screen-reader accessibility and independent native-speaker proofreading have not been independently certified in this run.


UPDATE v255 — GOETHE A2 LESEN TEIL 4
- Added module: Lesen A2 · Teil 4 — Anzeigen verstehen.
- Exam task format: match five people and their needs to suitable advertisements; one advertisement remains unused.
- Six independent sets, five matching tasks per set (30 tasks total), with six advertisements per set.
- Includes immediate answer checking, explanations for each match, score display, set navigation, retry, and XP (awarded once per set).
- Teil 1, Teil 2, Teil 3 and the existing audio assets are retained unchanged.


UPDATE v256 — SCHREIBEN A2 LANGUAGE TOOLKIT (STAGE 2)
- Added a new default entry point inside the existing Writing section: Language Toolkit.
- Added 8 complete learning units:
  1. Register & relationship (du/Sie, greetings and closings).
  2. Message & email structure (personal message and semi-formal email).
  3. Redemittel by communicative function (apologising, explaining, informing, asking, requesting, suggesting, accepting/declining and thanking).
  4. Questions & polite requests (W-questions, yes/no questions and indirect questions).
  5. Sentence building & word order (main-clause verb position, modal verbs, Perfekt and weil-clauses).
  6. Connectors & text flow (und, aber, oder, denn, weil, deshalb and sequence expressions).
  7. Time, dates & arrangements.
  8. Editing & final self-check (capitalisation, punctuation, task coverage and revision routine).
- Explanations are in English; German examples are paired with English translations.
- Each unit includes explanations, examples, a practical reminder and 3 multiple-choice knowledge checks (24 questions total).
- Answers can be retried after an incorrect attempt; correct answers award XP once; unit completion requires all 3 answers correct.
- Progress, answers and completion are saved locally.
- The existing A1–B1 Writing Workshop and all three A2 general writing tasks are preserved.
- Existing A2 Grammar content is referenced for review rather than duplicated.
- This toolkit is learning support, not a claim of official Goethe certification or automatic official writing assessment.

QA — SCHREIBEN A2 STAGE 2
- 8/8 units present.
- 24/24 knowledge-check questions present (3 per unit).
- All questions have 3 answer options and valid answer indices.
- Inline JavaScript syntax check: all 3 script blocks pass Node.js --check.
- Existing A1–B1 Writing Workshop tasks remain in the application.
- Existing Lesen A2 Teil 1–4 and 36 MP3 assets are retained.
- This run includes source-level QA; live iPhone Safari interaction and screen-reader testing have not been independently completed.


Deutsch Quest v257 - Schreiben A2 Stage 3
- Menambahkan Guided Writing dengan 8 tugas: 4 Teil 1 (20-30 kata) dan 4 Teil 2 (30-40 kata).
- Setiap tugas memuat situasi, tiga poin isi, urutan perencanaan, Redemittel, area draft, penghitung kata, self-check, dan model answer.
- Draft disimpan lokal pada perangkat; penyelesaian tugas memberikan XP satu kali setelah syarat terpenuhi.
- Language Toolkit, Writing Workshop, Lesen Teil 1-4, dan aset audio dari v256 dipertahankan.
- Lihat QA-REPORT-SCHREIBEN-STAGE3.json untuk rincian pemeriksaan.


UPDATE v258 — SCHREIBEN A2 INDEPENDENT WRITING PRACTICE (STAGE 4)
- Added 8 independent writing tasks: four personal messages (Teil 1) and four semi-formal emails (Teil 2).
- Teil 1 target length: 20–30 words; Teil 2 target length: 30–40 words.
- Each task identifies the recipient/register and contains exactly three content points.
- Unlike Guided Writing, Independent Writing intentionally provides no phrase bank or step-by-step writing plan.
- Includes editable draft, local autosave, live word count, target-range submission validation, four-item self-review rubric, model-answer reveal after submission, and once-only 15 XP task completion.
- Model answers are 23–27 words for Teil 1 and 34–35 words for Teil 2.
- Free-text answers are not automatically graded; self-review/XP is not an official Goethe score.
- Stage 1 was an exam mapping and content audit only; it was not a separate in-app learning module in v258.

QA — SCHREIBEN A2 STAGE 4
- 8/8 tasks present; 4 tasks per Teil.
- 24/24 content points present (exactly three per task).
- All model answers fall within their target word ranges.
- All three inline JavaScript blocks pass Node.js --check.
- Existing Language Toolkit, Guided Writing, Writing Workshop, Lesen Teil 1–4 and all 36 MP3 assets retained.
- Live iPhone Safari interaction and accessibility testing remain outstanding.


UPDATE v259 — SCHREIBEN A2 STAGE 1 INTEGRATION + STAGE 5 MOCK EXAM
Stage 1 — Exam Overview
- Integrated the adult Goethe-Zertifikat A2 Schreiben exam map as the default entry point when opening the Writing section.
- Documents the 30-minute duration, two tasks (SMS and E-Mail), 20–30 words for Teil 1, 30–40 words for Teil 2, and three communicative functions per task.
- Includes exam conditions, register guidance, official assessment criteria (Aufgabenerfüllung and Sprache), A–E point values (5, 3.5, 2, 0.5, 0), the rule that Aufgabenerfüllung E makes the whole task score zero, and raw-score conversion.
- Includes official links to the adult Goethe Modellsatz and Durchführungsbestimmungen (status 1 September 2025).
- Makes clear that Deutsch Quest's practice assessment is not an official Goethe result.

Stage 5 — Goethe-style Mock Exam
- Added four original mock sets, each with one SMS and one E-Mail (8 tasks total).
- Each task has three content points and German-language task instructions.
- Teil 1 target: 20–30 words; Teil 2 target: 30–40 words.
- Each set runs as one shared 30-minute timed attempt.
- Includes persistent deadline, auto-submit at timeout, locked navigation and set switching during an active attempt, live word count, local draft autosave and manual submission.
- After submission, learners self-rate Aufgabenerfüllung and Sprache using the official A–E point values, reveal model answers and retake the set.
- Self-assessment score estimate follows the official raw-score rounding and x1.25 conversion but is not an official grade.

QA — v259
- Four mock sets and eight tasks checked.
- All 24 content points checked (three per task).
- All eight model answers are within their Teil word ranges.
- All three inline JavaScript blocks pass Node.js --check.
- Chromium smoke test and interactions passed: overview navigation, exam start, timer, active-attempt lock, drafting, manual submit, self-rating, score calculation, timeout submission, model reveal and retake.
- All 36 MP3 assets and existing Lesen Teil 1–4 retained.
- Live iPhone Safari and screen-reader accessibility testing remain outstanding.


UPDATE v260 — SCHREIBEN A2 STAGE 6 FINAL INTEGRATION & DEEP QUALITY AUDIT
- Final audit completed across Stage 1 Exam Overview and Stages 2–5.
- Corrected the Stage 1 official rubric explanation and added the conditional third-assessment rule from the Goethe A2 administration rules dated 1 September 2025.
- Fixed global navigation locking during an active timed mock exam.
- Fixed restoration of an in-progress mock exam after reload, including its selected set, saved drafts and original deadline; expired attempts auto-submit on resume.
- Fixed Stage 4 first-time self-review completion so all four current checks are recognised without requiring a page refresh.
- Stage 4 submitted drafts are now read-only. Clearing a draft resets its submission, self-review and model-answer visibility.
- Refined the Stage 4 language-school model answer so it asks about lesson days and actual lesson times.
- Rechecked all 24 model answers across Guided Writing, Independent Writing and Mock Exam: every answer is within the assigned 20–30 or 30–40 word range.
- Rechecked the 24 Stage 2 knowledge-check questions: three options each and valid answer keys.
- Confirmed all 24 writing tasks across Stages 3–5 contain exactly three content points each (72 total).

QA — STAGE 6
- All three inline JavaScript blocks pass Node.js syntax validation.
- Chromium interaction tests passed for Stage 2 unit completion, Stage 3 guided completion, Stage 4 submit/review/model/clear flows, Stage 5 navigation lock, official E-rule scoring, resume and timeout submission.
- Responsive layout checked at 375 px, 390 px and 1280 px across all five Writing views; no horizontal overflow found.
- All 36 MP3 assets and Lesen A2 Teil 1–4 are retained. ZIP integrity check passed.
- Not independently certified: physical iPhone Safari, screen-reader accessibility, or independent native-speaker proofreading of every item. Free-text German is not automatically graded.
- Full details: QA-REPORT-SCHREIBEN-STAGE6-FINAL.json.


UPDATE v261 — SPRECHEN A2 STAGE 2 SPEAKING TOOLKIT
- Added a dedicated module: “Sprechen A2 · Speaking Toolkit”, registered in the main Language Skills navigation and Sprechen practice path.
- Added 8 learning units covering: (1) forming personal questions from cue words; (2) answering naturally and asking for clarification; (3) structuring a short personal talk; (4) routines, time expressions and Perfekt; (5) preferences and reasons; (6) starting a joint plan and proposing times/places; (7) reacting, negotiating and confirming arrangements; (8) pronunciation, pausing and communication-repair strategies.
- Each unit contains two detailed explanation sections, German examples with English meanings, a practical reminder and 3 multiple-choice knowledge checks (24 questions total).
- German example sentences have browser speech-synthesis playback using the app’s existing German voice selection/rate settings. Playback availability and voice quality depend on the learner’s browser/device.
- Progress, selected answers, correct checks and unit completion are saved locally. Incorrect answers can be retried; a unit completes only after all three checks are correct. Each completed unit awards 20 XP once.
- Added direct links to the official Goethe adult A2 interactive speaking model and adult model exam/rubric PDF.
- Stage 2 is a language toolkit only. Guided recording, spontaneous conversation simulation and mock examination remain for Stages 3–5.

QA — SPRECHEN A2 STAGE 2
- 8/8 units present; 24/24 knowledge-check questions present; each question has three options and a valid answer index.
- German examples cover question formation, verb-second/verb-first word order, weil/denn clauses, Perfekt with haben/sein, time expressions, preference phrases, polite suggestions and agreement/alternatives.
- All three inline JavaScript blocks pass Node.js syntax validation.
- Main module registration and Sprechen practice-path registration checked in source.
- Local progress, retry and once-only XP logic reviewed in source.
- All 36 existing MP3 assets and Lesen A2 Teil 1–4 plus Schreiben A2 v260 modules are retained.
- Runtime browser interaction could not be completed in this environment because Chromium navigation/set-content was blocked by the execution environment. Physical iPhone Safari, screen-reader accessibility and independent native-speaker proofreading remain outstanding.
- TTS uses the existing browser SpeechSynthesis API; actual voice availability differs by device and operating system.

UPDATE v262 — SPRECHEN A2 STAGE 3 GUIDED SPEAKING
- Added a dedicated “Sprechen A2 · Guided Speaking” module and registered it in the main module list, Language Skills group and Sprechen practice path.
- Added a direct Stage 2 Toolkit → Stage 3 Guided Speaking navigation action.
- Added six original guided scenarios: two Teil 1 question-and-answer tasks, two Teil 2 personal talks, and two Teil 3 joint-planning tasks.
- Each scenario contains a German task prompt, cue words, useful sentence frames, likely partner/follow-up prompts, a German model response, an English meaning and five self-review criteria.
- Teil 2 speaking prompts target approximately 45–60 seconds. Teil 3 planning exchanges target approximately 2–3 minutes.
- Added German speech-synthesis playback for task prompts and model responses.
- Added optional microphone recording using the browser MediaRecorder API and in-page audio replay. Recordings are temporary, are not uploaded, and do not persist after navigation or reload. Microphone access depends on browser permissions and a supported secure context.
- Speaking notes, self-review checks and scenario completion are saved locally. Each scenario awards 20 XP once when all five self-review criteria are checked.
- Recording is optional: if microphone access or MediaRecorder is unavailable, learners can still practise aloud and use the self-review checklist.
- The module explicitly states that self-review is not an official Goethe assessment and the app does not automatically grade pronunciation or spoken performance.

QA — SPRECHEN A2 STAGE 3
- 6/6 scenarios present, distributed as two per official Teil.
- 26 cue-word prompts, six German model responses with six English meanings, and 30 self-review criteria checked.
- German prompts, frames and model responses manually reviewed for A2-oriented grammar, natural phrasing, task relevance and du/Sie role consistency; independent native-speaker proofreading remains outstanding.
- All three inline JavaScript blocks pass Node.js --check.
- Main navigation, Language Skills grouping, Sprechen practice path and Stage 2-to-Stage 3 CTA registrations checked in source.
- Local notes/checklist/completion persistence and once-only XP logic reviewed in source.
- Recording code reviewed for no upload, stopping microphone tracks, temporary object URL playback and discard-on-navigation behavior.
- Chromium runtime interaction could not be completed because navigation was blocked by the execution environment (ERR_BLOCKED_BY_ADMINISTRATOR). Microphone runtime, physical iPhone Safari, screen-reader accessibility and cross-browser compatibility remain to be tested.
- All 36 existing MP3 assets, A2 Lesen Teil 1–4 and Schreiben A2 v260 plus Sprechen A2 Stage 2 are retained.
- Full details: QA-REPORT-SPRECHEN-STAGE3.json.

UPDATE v263 — SPRECHEN A2 STAGE 4 INDEPENDENT SPEAKING
- Added a dedicated “Sprechen A2 · Independent Speaking” module, registered in the main module list, Language Skills group and Sprechen practice path.
- Added eight original independent speaking tasks: two Teil 1 personal question-and-answer tasks, three Teil 2 personal talks, and three Teil 3 joint-planning tasks.
- Stage 4 deliberately removes sentence frames and hides model answers until the learner submits the attempt. Learners receive only the task instruction, cue words/card and partner/follow-up information before speaking.
- Each task includes five self-review criteria, a German model response, an English meaning and a reflection focus (40 criteria and 8 model responses/meanings total).
- Teil 2 prompts target approximately 45–60 seconds; Teil 3 prompts target approximately 2–3 minutes for the exchange.
- Learners can prepare brief keywords, optionally record and replay their spoken attempt, complete the self-review and submit. Model answers unlock only after submission.
- A submitted task can be repeated. Retrying clears the current notes/checklist and re-locks the model until the next submission; the original completion and XP remain recorded.
- Notes, checks, submission/unlock state and completion are saved locally. Each task awards 25 XP once (200 XP maximum across eight tasks).
- Optional MediaRecorder audio is temporary, not uploaded and not persisted. Microphone tracks are stopped and temporary object URLs are revoked when leaving the module/task. Unsupported recording has a clear spoken-practice fallback.
- The module explicitly states that self-review is not an official Goethe assessment and the app does not automatically grade grammar, fluency or pronunciation.

QA — SPRECHEN A2 STAGE 4
- 8/8 tasks present: 2 Teil 1, 3 Teil 2 and 3 Teil 3.
- 40/40 self-review criteria present; 8/8 German model responses and 8/8 English meanings present.
- All three inline JavaScript blocks pass Node.js --check.
- Chromium Playwright runtime tests (using page.set_content) passed for all eight task renders, submit gating, model reveal, retry/re-lock, once-only XP (200 XP for eight tasks; zero duplicate XP on retry), note persistence across task navigation, and Stage 2/Stage 3 regression smoke tests.
- Responsive layout checked at 375 px, 390 px and 1280 px; no horizontal overflow. Zero JavaScript runtime errors during tested flows.
- Unsupported recording fallback tested. Actual microphone hardware capture was not tested.
- Direct HTTP navigation was blocked by the execution environment (ERR_BLOCKED_BY_ADMINISTRATOR); Chromium runtime testing used an in-memory page.set_content harness.
- All 36 existing MP3 assets, A2 Lesen Teil 1–4, Schreiben A2 v260, Sprechen Stage 2 Toolkit and Stage 3 Guided Speaking are retained.
- Physical iPhone Safari, screen-reader accessibility and independent native-speaker proofreading remain outstanding.
- Full details: QA-REPORT-SPRECHEN-STAGE4.json.


VERSI v264 — SPRECHEN A2 STAGE 5: GOETHE MOCK EXAM
- Empat set simulasi orisinal dengan Teil 1, Teil 2, dan Teil 3.
- Timer gabungan 15 menit, disimpan lokal, dan auto-submit saat waktu habis.
- Mode solo memakai respons partner virtual tertulis; bukan percakapan adaptif atau pengganti pasangan manusia.
- Rubrik self-assessment mengikuti skala poin Goethe A2, maksimum 25; skor adalah estimasi mandiri.
- Rekaman per bagian bersifat sementara dan tidak diunggah.
- Hasil self-assessment tetap tersimpan ketika kembali ke daftar mock set; retake terpisah dari review hasil.
- Mengingatkan waktu membaca kartu sekitar 20 detik berdasarkan panduan penguji Goethe; tidak dibuat countdown persiapan terpisah.
- Mode solo berfokus pada giliran peserta pengguna dan tidak mereplikasi seluruh waktu bicara dua peserta, khususnya produksi Teil 2 peserta kedua.

VERSI v265 — SPRECHEN A2 STAGE 6: FINAL INTEGRATION & DEEP QA
- Stage 6 adalah tahap konsolidasi dan QA akhir, bukan stage latihan baru. Stage 2–5 tetap dipertahankan dan diintegrasikan dalam navigasi aplikasi.
- Audit integrasi mengonfirmasi Speaking Toolkit (8 unit), Guided Speaking (6 skenario), Independent Speaking (8 tugas) dan Goethe Mock Exam (4 set, masing-masing 3 bagian).
- Pemeriksaan ulang mencakup registrasi modul, jalur Language Skills, CTA antartahap, state persistence, navigation guard mock exam, dan cleanup rekaman sementara.
- Ditemukan dan diperbaiki bug pada Lesen A2 · Teil 4: renderer menggunakan identifier `app` yang tidak terdefinisi. Target render kini menggunakan elemen workspace `el` yang tersedia.
- Uji Chromium/Playwright lulus untuk seluruh stage Speaking, mock exam empat set, Writing, Lesen A2 Teil 4 dan Goethe A2 Listening Exam.
- Tidak ditemukan JavaScript runtime error atau duplicate DOM ID pada tampilan modul yang diuji. Tiga blok inline JavaScript lolos `node --check`.
- Responsif diuji pada lebar 375, 390, 768 dan 1280 px tanpa horizontal overflow.
- Integritas ZIP diperiksa; seluruh 36 MP3, audio manifest, QA report tahap sebelumnya dan file aplikasi sebelumnya dipertahankan.
- Batas pengujian: belum dilakukan uji iPhone Safari/perangkat iOS fisik, perekaman mikrofon fisik, screen reader, atau proofreading independen native speaker. Simulasi partner Stage 5 tetap berbasis respons tertulis/scripted, bukan partner adaptif atau pengganti ujian dua peserta.
- Detail cakupan, koreksi dan batas pengujian: QA-REPORT-SPRECHEN-STAGE6-FINAL.json.


VOCABULARY A2 — STAGE 1 FINAL (v266)
Stage 1 Integrated Linguistic & Editorial Deep Audit telah diselesaikan dalam satu tahap pengerjaan. Audit runtime final mencakup 354 nouns, 89 verbs, 38 adjectives, 26 adverbs/function words, 10 prepositions, 384 phrases, dan 18 word-family groups (901 lexical entries + 18 kelompok keluarga kata = 919 records/groups). Pemeriksaan internal dapat dilakukan dalam batch untuk menjaga ketelitian, tetapi bukan sub-stage pembelajaran.
Koreksi langsung diterapkan pada sumber aplikasi. Laporan rinci: QA-REPORT-VOCAB-STAGE1-FINAL.json. Audit internal bukan sertifikasi formal CEFR dan tidak semua entri diklaim telah diverifikasi satu per satu dengan kamus eksternal.


VOCABULARY A2 — STAGE 1 FINAL INTEGRATED DEEP AUDIT (v266)
Audit runtime banks after deduplication: 354 nouns, 89 verbs, 38 adjectives, 26 adverbs/function words, 10 prepositions, 384 phrases = 901 unique lexical entries; 18 word-family groups are tracked separately (919 total records/groups).
Goethe A2 crosswalk: 121 listed core entries, 780 supplementary checked entries, 0 pending. 33 same-bank duplicates and 3 redundant cross-bank phrase records were consolidated; removed source rows are preserved in the in-app audit archive. Three additional A2 verbs received complete six-person present and past-form/auxiliary records.
Full details and limits: QA-REPORT-VOCAB-STAGE1-FINAL.json. Internal audit is not formal CEFR certification; not every item is individually dictionary-certified.
Duplicate merge traceability: VOCAB-A2-DUPLICATE-MERGE-ARCHIVE.json.


VOCABULARY A2 — STAGE 2 FINAL DEEP AUDIT & APPLICATION TESTING (v267)
- Stage 2 selesai sebagai audit integrasi dan pengujian aplikasi; tidak menambah bank kosakata baru. Baseline konten tetap v266.
- Diperbaiki pencarian vocabulary agar mencari headword Jerman, arti Inggris, plural, contoh kalimat, catatan penggunaan, bentuk lampau verb dan collocation. State kosong sekarang tetap menyediakan navigasi kategori/level; referensi A1-only menjelaskan cara kembali ke level A1.
- Checklist topik Goethe A1 tidak lagi ditampilkan pada tampilan A2/B1. Detail verb A2 kini menampilkan status integrated linguistic audit dan bentuk lampau/Partizip II/auxiliary yang sudah tersedia, bukan fallback provisional A1.
- Diperbaiki 39 benturan kunci SRS akibat lemma yang sama muncul secara sah pada level CEFR berbeda. Kartu duplikat lintas-level sekarang memakai ID level-aware; kunci lama dimigrasikan mengikuti level yang tersimpan agar progres lama tetap terjaga. Seluruh 3.757 kartu runtime kini memiliki ID unik.
- Seluruh 10 kategori Vocabulary Bank diuji untuk alur Add to Review; Goethe A-Z dan Word Groups kini juga memiliki entri review yang dapat ditemukan kembali. Dashboard menghitung kartu yang dipraktikkan lintas-level, sementara denominator progress inti A1 mengecualikan dua bank referensi opsional.
- Diperbaiki regex pada Vocabulary Workout: tokenisasi frasa, deteksi verb + preposition + case, dan pencarian noun dalam kombinasi verb + noun. Sebelumnya escape ganda menyebabkan pool soal gap-fill kosong dan crash pada perpindahan soal. Pool A2 hasil perbaikan: 372 phrase-gap, 30 verb+noun dan 10 verb+preposition.
- Jenis latihan Workout sekarang hanya dimasukkan jika pool memiliki data. A2 memiliki 12 mode unik: meaning, article, context, typed recall, sentence production, plural, full noun recall, collocation, collocation sentence writing, gap-fill, verb+noun, dan verb+preposition+case. Label mode type/noun juga diperbaiki. Sentence production menggunakan self-check terhadap model, bukan penilaian grammar otomatis.
- Interval SRS diuji: Again 10 menit, Hard 12 jam, Good 1 hari, Easy 4 hari untuk kartu baru. Penyimpanan lokal diuji dengan storage harness.
- Pencarian diuji dengan bahasa Jerman/Inggris, plural dan contoh; detail noun menampilkan konteks phrase yang cocok. Tidak ada state kategori kosong yang mengunci navigasi.
- Semua 3 blok JavaScript inline lolos node --check. Chromium/Playwright: seluruh 10 kategori, 12 mode latihan A2, alur review, SRS, responsive 375/390/768/1280 px, serta regression Speaking Stage 2–5, Writing, Lesen A2 Teil 4 dan Listening lulus; 0 runtime errors dan tidak ada horizontal overflow.
- ZIP final mempertahankan seluruh 36 MP3, audio manifest, laporan QA sebelumnya dan arsip merge Stage 1.
- Batas pengujian: belum dilakukan uji fisik iPhone Safari, screen reader, microphone hardware atau proofreading independen native speaker. TTS menggunakan suara yang tersedia pada browser/perangkat.
- Detail: QA-REPORT-VOCAB-STAGE2-FINAL.json.


UPDATE v268 — A2 READINESS LAB · STAGE 1
- Added the A2 Readiness Lab to the Test & Track module group.
- The lab organises six competency areas: Grammar and Vocabulary as foundations; Hören, Lesen, Schreiben and Sprechen as the four official Goethe A2 exam skills.
- Added 24 self-assessment criteria (four per competency area), a completion indicator, saved-state update through the existing application save function, and direct navigation to the corresponding practice modules.
- Added direct links to all four Lesen parts, the Goethe A2 Listening Exam, Writing, the Speaking Mock Exam and Vocabulary Workout.
- The checklist is a learner self-check. It does not produce a CEFR decision or official Goethe result.

STAGE 1 FIXES
- Fixed an A2 Lesen runtime error in Teil 2 and Teil 3: both modules used `escA2()` even though the helper was scoped inside Teil 1. Added a shared escaping helper and routed Teil 2/3 through it.
- Fixed narrow-screen text overflow in the new readiness checklist by allowing the checklist text to shrink and wrap.
- Registered the new module both in the module directory and in the Test & Track group.

A2 CONTENT & STRUCTURE INVENTORY
- Grammar: 23 learner-facing canonical A2 lessons; 48 integrated A2 questions across four assessment domains; 320 focused lesson questions across the 23 canonical topics.
- Vocabulary: retains the v267 audit baseline of 901 unique lexical entries and 18 word-family groups.
- Hören: four parts, five tasks each (20 tasks), 30-minute practice simulation.
- Lesen: four parts, six practice sets per part, five tasks per set (120 practice tasks total).
- Schreiben: 24 original tasks across Stages 3–5, two writing parts per mock set.
- Sprechen: four original mock sets, three parts each, approximately 15-minute paired-exam simulation.

VALIDATION
- All three inline JavaScript blocks pass Node.js syntax validation.
- Chromium `page.set_content` runtime harness: A2 Readiness Lab renders 24 checkboxes and all 14 navigation links; all ten unique destinations open the intended module.
- Checkbox interaction updates the saved application state object; cross-reload persistence of this new field was not independently verified in this harness.
- Responsive widths tested: 375, 390, 768 and 1280 px; no horizontal overflow; no duplicate IDs; zero JavaScript page errors in the tested views.
- Grammar A2 practice: all 12 questions rendered and the session completed.
- Hören mock: start screen and timed Part 1 rendered; 20-task bank and answer/evidence structures validated.
- Lesen Teil 1–4: all modules rendered; Teil 1–3 answer controls and Teil 4 matching controls were present; no runtime errors after the helper fix.
- Writing exam overview and Speaking mock exam opened without runtime errors.
- ZIP integrity and preservation of all 36 MP3 assets checked.

KNOWN LIMITATIONS / STAGE 2 FOLLOW-UPS
- Lesen is currently organised as four separate practice modules, each with six five-question sets. There is not yet one combined 20-item, 30-minute Reading mock exam.
- The readiness checklist is self-assessment and does not automatically aggregate scores from all six modules.
- Hören uses device-generated German text-to-speech, not official Goethe recordings or studio-recorded native audio.
- Writing and Speaking self-assessment cannot reproduce independent examiner grading; the Speaking partner is scripted.
- Physical iPhone Safari, screen-reader accessibility, physical microphone capture and independent native-speaker proofreading were not tested in this run.
- The audit is a structural and functional readiness review, not formal Goethe-Institut/CEFR certification.


UPDATE v269 — A2 FINAL INTEGRATION & DEEP QA (STAGE 2)
- Added the integrated module “Lesen A2 · Goethe Mock Exam” to the existing Test & Track group and linked it from A2 Readiness Lab.
- Exam format: 30 minutes, 20 items, four parts, five items per part.
- The exam rotates through six combinations made from the six existing sets in Lesen Teil 1, Teil 2, Teil 3 and Teil 4. This reuses the existing reading bank; it does not create a duplicate bank.
- Teil 1: media-style text comprehension; Teil 2: information board / programme; Teil 3: everyday correspondence; Teil 4: match five people to six advertisements.
- Timed attempt includes countdown, saved answer state through the app's existing save path, active-exam navigation guard, automatic submission on time expiry, zero points for unanswered items, post-submit score and per-part breakdown, explanations, text evidence and English translation support after the exam.
- A2 Readiness Lab now displays the latest completed integrated Lesen mock score and its four-part breakdown; up to 20 completed attempts are retained in app state.
- Score is a raw practice score out of 20. It is not an official Goethe grade, CEFR result or certificate decision.
- Grammar, Vocabulary, Hören, Schreiben and Sprechen banks are preserved. No duplicate grammar or vocabulary modules were created.

STAGE 2 DEEP QA — v269
- All six integrated mock variants tested; each produced 20/20 when the original answer keys were entered.
- 20 scored items per attempt: 15 multiple-choice items plus five matching items (45 radio options and five select controls).
- Six existing sets per Lesen part structurally checked: 120 reading practice items total; five valid items per set; valid answer keys; three distinct options for each multiple-choice item; explanations/evidence present; Part 4 matching answer IDs valid and unique.
- A2 Readiness Lab, Grammar, Vocabulary, Vocabulary Workout, Goethe A2 Listening Exam, Lesen Teil 1–4, Writing and Sprechen mock opened in Chromium with zero tested-view runtime errors.
- Timer expiry and navigation guard passed; the latest Lesen mock result appears in A2 Readiness Lab.
- All three inline JavaScript blocks pass Node.js syntax validation.
- Responsive widths 375, 390, 768 and 1280 px: no horizontal overflow.
- All 36 audio assets, the audio manifest and previous QA reports retained.
- Known limitations: physical iPhone Safari, screen-reader, physical microphone and independent native-speaker proofreading were not tested. Cross-reload local-storage persistence for the new timed Lesen mock could not be independently confirmed in this in-memory browser harness. Hören continues to use device TTS rather than official Goethe audio. Writing and Speaking remain outside automatic common scoring.
- See QA-REPORT-A2-FINAL-INTEGRATION-STAGE2-v269.json for the detailed test ledger and limitations.


UPDATE v270 — B1 VOCABULARY STAGE 1 DEEP AUDIT
- Audited the existing B1 vocabulary banks: 221 nouns, 34 verbs, 30 adjectives, 23 adverbs/function words, 9 prepositions, 165 phrases and 7 word-family groups.
- Consolidated two redundant generic preposition records (während, wegen) into their case-marked canonical entries; the original records are preserved in VOCAB-B1-STAGE1-MERGE-ARCHIVE.json.
- Corrected the noun lemma der Sicherheitsschuh; added the second accepted plural of der Umtausch; clarified context-sensitive plurals and selected collocations.
- Improved the avoid-verb example, phrase translations, housing question and administrative collocation.
- Clarified preposition case government and word-family stems.
- Added QA-REPORT-B1-VOCAB-STAGE1-FINAL-v270.json. Selective Duden checks are documented there; this is not formal Goethe/CEFR certification or independent native-speaker proofreading.
- Preserved all previous A1/A2 modules, reports, assets and 36 MP3 audio files.


UPDATE v271 — B1 VOCABULARY STAGE 2: GOETHE COVERAGE & EXPANSION
- Added 221 supplementary B1 lexical records: 69 nouns, 52 verbs, 29 adjectives, 15 adverbs/function words, 4 prepositions and 52 phrases.
- Added 8 word-family groups. Final B1 inventory: 290 nouns, 86 verbs, 59 adjectives, 38 adverbs/function words, 13 prepositions, 217 phrases and 15 word-family groups (703 lexical records + 15 groups).
- Mapped all 14 official Goethe B1 Wortliste word-group headings and 13 broader topic areas in the B1 Vocabulary Bank coverage panel.
- Completed six-person Präsens, Präteritum, Partizip II, auxiliary and usage data for all 86 B1 verbs; corrected existing paradigms and clarified reflexive Perfekt patterns.
- The official Goethe B1 Wortliste describes approximately 2,400 lexical units. This release provides topic-level coverage mapping and supplementary expansion, not a complete item-by-item crosswalk of all 2,400 units; Stage 3 continues that work.
- Added QA-REPORT-B1-VOCAB-STAGE2-GOETHE-COVERAGE-v271.json, B1-GOETHE-COVERAGE-MAP-v271.json, B1-VERB-PARADIGM-AUDIT-v271.json and B1-STAGE2-EXPANSION-LEDGER-v271.json.
- Preserved previous A1/A2 modules, grammar, reading, listening, writing, speaking, prior QA reports and all 36 MP3 audio assets.


UPDATE v272 — B1 VOCABULARY STAGE 3: LINGUISTIC & PEDAGOGICAL DEEP VERIFICATION
- Individually reviewed all 719 current B1 lexical records and all 15 B1 word-family groups, organized into 12 internal audit batches (60 records per batch; final batch 59).
- Final inventory: 304 nouns, 86 verbs, 61 adjectives, 36 adverbs/function words, 13 prepositions, 219 phrases and 15 word-family groups.
- Corrected der Schwager plural to die Schwäger; reclassified weder ... noch and sowohl ... als auch as multi-part conjunctions under Phrases/Connectors; clarified zukünftig and innerhalb; corrected the bound word-family stem zahl-.
- Added 14 missing official Goethe B1 word-group nouns and two political adjectives after cross-checking the official political and education word groups.
- All 86 B1 verbs retain six-person Präsens forms, Präteritum, Partizip II and auxiliary; special usage notes clarify sich lohnen and ausreichen.
- Added 43 clear vocational-bakery supplement labels and collocations/distinctions for related bakery terms.
- Confirmed 56 exact official Goethe B1 items/forms. The remaining 663 app records have not all been individually crosswalked against the full ~2,400-unit official list; topic-aligned and vocational supplements are clearly distinguished.
- Added Stage 3 QA report, 719-record item-level audit manifest, correction ledger and Goethe crosswalk.
- Preserved all previous A1/A2 modules, grammar, reading, listening, writing, speaking, prior QA reports and all 36 MP3 audio assets.
- QA: Node syntax 3/3 PASS; Chromium in-memory runtime 0 errors; 15/15 interactive checks PASS; responsive 375/390/768/1280 px no overflow; ZIP integrity PASS.
- Limitations: no full official 2,400-item crosswalk, no independent native-speaker proofreading, no physical iPhone Safari/screen-reader/microphone-hardware testing.

UPDATE v273 — B1 VOCABULARY STAGE 4: APPLICATION INTEGRATION & FINAL DEEP QA
- Integrated B1 mixed active-recall practice across the existing noun, verb, adjective, adverb/function-word and preposition banks: meaning recall, contextual recognition and typed recall.
- Added a dedicated B1 word-family recognition mode for the 15 existing word-family groups. Word-family entries remain linked to their existing Review card identities.
- Corrected Add-to-Review category routing for mixed B1 questions. Review now preserves the actual source category and B1 level for verbs, prepositions and word families; no duplicate Review bank was created.
- Updated the B1 coverage panel to identify the v273 Stage 4 integration and retained the explicit Goethe crosswalk limitation.
- Final inventory remains 304 nouns, 86 verbs, 61 adjectives, 36 adverbs/function words, 13 prepositions, 219 phrases and 15 word-family groups: 719 lexical records plus 15 family groups.
- Review catalog: 4,000 cards with 4,000 unique IDs; 734 B1 cards including word-family groups.
- QA: Node syntax 3/3 PASS; 27/27 Stage 4 functional and integration checks PASS; 0 JavaScript page errors; 0 console errors; responsive 375/390/768/1280 px no horizontal overflow.
- All 36 MP3 assets and all previous modules/reports retained. See QA-REPORT-B1-VOCAB-STAGE4-FINAL-v273.json and B1-STAGE4-CORRECTION-LEDGER-v273.json.
- Limitations remain: this is not a complete line-by-line crosswalk of all ~2,400 official Goethe B1 lexical units; no independent native-speaker proofreading, physical iPhone Safari, screen-reader or physical microphone-hardware test was performed. Free-form sentence writing is self-assessed, not automatically grammar-graded.


UPDATE v278 — HÖREN B1 STAGE 1: INVENTORY & GOETHE EXAM COVERAGE AUDIT
- Audited the existing Hören/listening content in the v277 baseline without modifying application code or A1/A2 material.
- Existing workplace listening bank DQ137: 8 clips / 16 questions, level A1–A2.
- Existing Listening Intelligence Lab DQ138: 7 detail lessons / 21 questions (3 A2, 1 A2–B1, 3 B1); 8 dictation lines (2 A1, 3 A2, 3 B1); shadowing reuses the same 8-line bank.
- Existing DQ138 playback uses browser SpeechSynthesis (de-DE), not fixed MP3 audio.
- The separate A2 MP3 library contains 36 recorded assets and remains out of B1 scope.
- Official Goethe B1 Hören blueprint verified: approx. 40 minutes, four parts, 30 tasks distributed 10 + 5 + 7 + 8; playback counts and task types documented in QA-REPORT-HOEREN-B1-STAGE1-INVENTORY-GOETHE-COVERAGE-v278.json.
- Coverage result: PARTIAL. Current B1 material is useful vocational listening practice but is not a Goethe B1 Hören mock exam.
- Stage 1 corrections: distinguish the mixed-level Listening Intelligence Lab from a B1-only exam module; do not count dictation/shadowing as exam tasks; use the official four-part structure as the later build blueprint.
- MP3 decision: deferred until Stage 2 linguistic and pedagogical audit has finalized scripts, tasks, answer keys and transcripts.
- No application code, A1/A2 content, or existing MP3 assets were changed.


UPDATE v279 — HÖREN B1 STAGE 2: LINGUISTIC & PEDAGOGICAL DEEP AUDIT
- Audited all three explicitly B1 Listening Intelligence Lab lessons, all three B1 dictation lines, and the A2–B1 production-sequence bridge item.
- Corrected and strengthened the B1 trainer correction notice with more natural vocational vocabulary and a purpose clause (damit); added evidence to all three questions.
- Improved spoken naturalness and precision in Shift handover, including the tray phrase, remaining resting time, expected delivery and shift handover instruction.
- Rewrote the awkward negated instruction in The delivery is not complete; clarified the supplier follow-up and corrected the evidence for the missing-pack calculation so it includes both 12 expected and 10 received.
- Refined B1 dictation d6 (immediate safety response and responsible person) and d7 (more precise passive completion wording); d8 passed without correction.
- Retained the A2–B1 production sequence as a bridge item rather than relabelling it as core B1.
- B1 lesson questions: 9/9 have exactly three distinct options and valid answer indices; answer-key indices unchanged.
- All 3 inline JavaScript blocks pass Node.js --check. ZIP integrity verified.
- No MP3 recording is required yet. Do not record until the full original Goethe B1 Hören Teil 1–4 scripts, answer keys, evidence and transcripts have been constructed and passed QA.
- A1/A2 content, the A2 MP3 library, existing module navigation and unrelated modules are retained.


UPDATE v280 — HÖREN B1 STAGE 3: GOETHE EXAM BLUEPRINT & TASK CONSTRUCTION
- Verified the current official Goethe B1 Hören model-set format and regulations.
- Constructed one original B1 practice set with 8 audio scripts and 30 items:
  - Teil 1: five short texts, each played twice, two tasks per text (10 items; Richtig/Falsch + multiple choice).
  - Teil 2: one longer text played once, five multiple-choice items.
  - Teil 3: one conversation played once, seven Richtig/Falsch items.
  - Teil 4: one discussion played twice, eight speaker-attribution items.
- Topics include an appointment change, library notice, community repair event, train disruption, adult-learning course, community garden report, workplace training conversation and home-office discussion.
- Added B1-HOEREN-STAGE3-EXAM-BANK-v280.json, separate answer key and detailed Stage 3 QA report.
- QA: all 30 item numbers sequential; all 30 evidence excerpts are exact contiguous transcript excerpts; every question has an answer and explanation; all options are unique; all answer values valid; all part-specific task formats and play counts pass structural checks.
- Transcript lengths: Teil 1 short texts 60–67 words each; Teil 2 290 words; Teil 3 288 words; Teil 4 465 words.
- MP3 recording is NOT requested yet. Stage 4 final linguistic, distractor, answer, transcript, timing and speaker QA must be completed first. Planned recordings: 8 audio files.
- Stage 3 assets are standalone and not yet integrated into the application UI. Existing app code, A1/A2 content and all 36 A2 MP3 files are preserved.
- These are original Goethe-format-aligned practice materials, not official Goethe questions or certified exam materials.


UPDATE v281 — HÖREN B1 STAGE 4: FINAL LINGUISTIC QA & RECORDING PREPARATION
- Reopened and audited the v280 exam bank against the current Goethe B1 Hören model set and examination regulations.
- Confirmed four-part format, 40-minute module, 5 short Teil 1 texts played twice (2 tasks each), Teil 2 one text once/5 MC, Teil 3 one conversation once/7 Richtig-Falsch, and Teil 4 one discussion twice/8 speaker attribution.
- Corrected eight transcript issues: explicit train departure/platform wording; more idiomatic member availability wording; clarified actual gardening work; more precise course-task wording; removed ambiguous certificate connector; replaced Kursrunde with Kurs; corrected awkward German word order in the Homeoffice discussion; refined technical term to sichere Software.
- Refined three question prompts (Teil 3 Q20; Teil 4 Q23 and Q24) and updated transcript evidence where required.
- Final validation: 30/30 sequential questions; 30/30 exact transcript evidence excerpts; 30/30 answer-key alignment; 30/30 explanations; unique options; all four task formats and playback counts pass.
- Prepared exactly eight recording scripts and an audio manifest with exact filenames, speaker allocation, pace guidance, pronunciation focus and technical recommendations.
- MP3 production is now required. Each file must contain one complete performance only; the app will handle the official repetitions (Teil 1 twice, Teil 2 once, Teil 3 once, Teil 4 twice).
- Preferred MP3 output: mono, 24 kHz if supported, to match the existing A2 audio library; no music, effects, intro or outro. Natural clear Hochdeutsch at the specified approximate B1 pace.
- Actual pronunciation, speaker consistency, audio quality, clipping, metadata and transcript-to-audio fidelity remain pending until the user uploads all eight MP3s.
- No app UI integration in this stage. Existing index.html, A1/A2 modules and all 36 A2 MP3 assets are preserved.
- These are original Goethe-format-aligned practice materials, not official Goethe questions or certified equivalence.
