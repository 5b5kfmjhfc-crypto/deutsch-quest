DEUTSCH QUEST v283 — LESEN B1 STAGE 1
Inventory & Goethe Coverage Audit

Baseline: v282 (Hören B1 Stage 5 package)
This release adds the Stage 1 audit report only. Existing app content is preserved.
A1/A2 reading content was not changed.

Key result:
- Reading Workshop: 21 texts (15 A1, 3 A2, 3 B1)
- Existing B1 Reading Workshop: 3 short texts, 9 comprehension questions
- Dedicated Goethe B1 Lesen exam: not found
- Official adult Goethe B1 reference: 5 parts, 30 items, 65 minutes

See QA-REPORT-LESEN-B1-STAGE1-v283.json for the detailed inventory,
task blueprint, coverage assessment, findings and Stage 2 recommendations.

This is an original learning-app audit, not Goethe certification.
