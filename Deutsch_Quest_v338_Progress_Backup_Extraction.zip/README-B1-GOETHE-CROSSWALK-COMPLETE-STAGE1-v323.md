# Deutsch Quest B1 — Complete Goethe Vocabulary Crosswalk Stage 1 · v323

## Release result
**COMPLETE STATUS INVENTORY · DIRECT OFFICIAL SOURCE EVIDENCE ATTACHED · RE-AUDITED**

This release completes the crosswalk stage for the full existing app vocabulary bank. It preserves every learning record and clearly distinguishes official headword/word-group/phrase matches, partial preposition-headword matches, supplementary/pending records, vocational bakery supplements and selected-search misses.

## Official source
Goethe-Zertifikat B1 Wortliste (2016), Goethe-Institut / ÖSD / Universität Freiburg:
https://www.goethe.de/pro/relaunch/prf/de/Goethe-Zertifikat_B1_Wortliste.pdf
The official foreword describes approximately 2,400 lexical units, primarily receptive knowledge, and notes that derivable compounds are not necessarily listed separately.

## Full-bank reconciliation
- 719 lexical learning-bank records retained
- 15 word-family groups retained
- 62 family-member links retained
- 734 total app records accounted for
- 134 exact-confirmed headword / official word-group / complete phrase records
- 9 preposition headwords confirmed while the full case-governed pattern is not separately listed
- 528 supplementary or pending exact confirmation
- 43 vocational bakery supplements
- 5 selected-search misses; not proof of absence

## Verification rules
1. Exact confirmation requires the headword, official word-group form or complete phrase itself to be visible in the official source, or to be documented in the prior item-level audit v272.
2. A term appearing only inside an example sentence is not automatically a standalone headword.
3. A preposition headword match does not prove the full case-governed pattern is an official listed construction.
4. A phrase is confirmed only when the full expression itself is listed; component words are insufficient.
5. Search misses remain explicitly non-conclusive.
6. Bakery and vocational terminology remains supplementary where no exact official entry is documented.

## App changes
- Added `B1-GOETHE-CROSSWALK-COMPLETE-STAGE1-v323.json` with per-record status and evidence.
- Added direct official PDF line ranges to newly promoted records.
- Added separate preposition-headword / pattern status.
- Added phrase-level exact match status.
- Updated B1 Vocabulary Coverage panel to v323.
- Preserved all existing vocabulary and grammar learning content.

## Audit artifacts
- `B1-GOETHE-CROSSWALK-COMPLETE-STAGE1-MANIFEST-v323.json`
- `B1-GOETHE-CROSSWALK-COMPLETE-STAGE1-CORRECTION-LEDGER-v323.json`
- `QA-REPORT-B1-GOETHE-CROSSWALK-COMPLETE-STAGE1-v323.json`

## Limitations
This is a complete evidence-based status inventory of the app's 719 vocabulary records and 15 word-family groups, not a complete reproduction or exhaustive line-by-line match of all approximately 2,400 official units. Physical device acceptance and independent native-speaker certification are not claimed.
