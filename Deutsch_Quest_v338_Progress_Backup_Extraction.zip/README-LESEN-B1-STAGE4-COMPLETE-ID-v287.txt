Deutsch Quest v287 — Lesen B1 Stage 4

Paket ini melengkapi Teil 2–5 dan mempertahankan Teil 1 dari v286. Total: 5 Teil, 30 soal, 65 menit. Konten orisinal untuk latihan, bukan materi ujian resmi Goethe. Tahap ini belum mengintegrasikan UI/runtime.

Baca QA-REPORT-LESEN-B1-STAGE4-COMPLETE-v287.json untuk hasil validasi.
